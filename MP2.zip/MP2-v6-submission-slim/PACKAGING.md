# Slim submission packaging

Final method: `code/submission_v6.py`. Matching checkpoint: the complete `code/runs/final/` directory. Original data must be restored as described in README before use.

The model/configuration files, inference/training/research source bytes, PDF report, and recorded score were not modified. Documentation and packaging inventories were updated. Historical frozen manifests remain as experimental provenance, not current-checkpoint verification targets.

Checks: all current frozen model hashes and retained covered source hashes match; all remaining Python sources parse; saved V6 predictions score 388/467 using the unchanged official scorer and original supplied data. Inference was not rerun here because PyTorch and CatBoost are unavailable. This packaging check does not establish runtime or reference-machine eligibility.

Removed from the preceding full package:

- `CLEANUP.md`
- `COURSE-GUIDE.md`
- `code/COURSE-README.md`
- `code/data/candidates/gsm8k_test.jsonl`
- `code/data/candidates/gsm8k_test.npz`
- `code/data/candidates/gsm8k_train.jsonl`
- `code/data/candidates/gsm8k_train.npz`
- `code/data/candidates/gsm8k_validation.jsonl`
- `code/data/candidates/gsm8k_validation.npz`
- `code/data/gsm8k_test.jsonl`
- `code/data/gsm8k_train.jsonl`
- `code/data/gsm8k_validation.jsonl`
- `code/evaluate.py`
- `code/evaluate_final.py`
- `code/evaluate_v2.py`
- `code/evaluate_v4.py`
- `code/evaluate_v5.py`
- `code/freeze_v4.py`
- `code/refresh_freeze.py`
- `code/v4/v3_oof_scores.npy`
- `code/verify_package.py`
- `code/verify_v4.py`
- `code/verify_v5.py`
- `report_source.py`
- `requirements-report.txt`
