# Frozen V6

See [the release README](../README.md) for the exact V6 method, matching checkpoint and score. [The training guide](../TRAINING.md) documents reproduction. COURSE-README.md retains the original course running instructions.
