import json, numpy as np
from common import load_inputs,parse_answer
from submission import aggregate
b,a=load_inputs('validation');s=np.load('runs/validation_logits.npy');y=np.load('runs/validation_labels.npy');hard=np.array([len(set(x for x in [parse_answer(c['text']) for c in r['candidates']] if x))>=2 for r in b]);cfg=json.load(open('runs/model/config.json'));pr=aggregate(s[:2].mean(0),b,.5);p=pr.argmax(1);v=y[np.arange(len(p)),p];out={'all':float(v.mean()),'hard':float(v[hard].mean()),'hard_n':int(hard.sum()),'ensemble_ablation':{}}
for n in [1,2,3,4,5,6]:
 for alpha in [0,.5,1]:
  pp=aggregate(s[:n].mean(0),b,alpha).argmax(1);vv=y[np.arange(len(pp)),pp];out['ensemble_ablation'][f'n{n}_alpha{alpha}']={'all':float(vv.mean()),'hard':float(vv[hard].mean())}
margin=np.sort(pr,axis=1)[:,-1]-np.sort(pr,axis=1)[:,-2];out['margin_quartiles']=[]
for ids in np.array_split(np.argsort(margin),4):out['margin_quartiles'].append({'n':len(ids),'accuracy':float(v[ids].mean()),'mean_margin':float(margin[ids].mean())})
open('runs/analysis.json','w').write(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
