"""Reproduce validation reliability tables for the frozen V6 checkpoint."""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[k]='4'
import json,math
from pathlib import Path
import numpy as np
from catboost import CatBoostRanker
from common import load_inputs,read_jsonl,DATA,parse_answer
from rich_features import rich_features,hard_mask
from operation_profiles import candidate_profiles
from baseline_features import baseline_features
from scores_v5 import predict as v5_scores
from submission import aggregate
p=Path('runs/final');cfg=json.loads((p/'config.json').read_text())['semantic_residual'];b,a=load_inputs('validation');old=v5_scores(b,a,p);e,f=rich_features(b,a);z=np.load(p/'semantic_residual/pca.npz');projection=(e-e.mean(1,keepdims=True)).reshape(-1,1024)@z['components'].T;projection-=z['mean'][None,:]@z['components'].T;projection=projection.reshape(-1,4,64);x=np.round(np.concatenate([baseline_features(b,old),candidate_profiles(b),f,f-f.mean(1,keepdims=True),projection],-1),4);net=CatBoostRanker();net.load_model(str(p/'semantic_residual'/cfg['model']));lp=net.predict(x.reshape(-1,x.shape[-1]),thread_count=4).reshape(-1,4);new=old+cfg['weight']*aggregate(lp/cfg['scale'],b,.5);saved=Path('runs/v6-validation-predictions.json')
if saved.exists():assert np.array_equal(new.argmax(1),json.loads(saved.read_text())['selected'])
g=read_jsonl(DATA/'gsm8k_validation.jsonl');y=np.array([[parse_answer(c['text'])is not None and parse_answer(c['text'])==parse_answer(q['answer'])for c in r['candidates']]for r,q in zip(b,g)]);h=hard_mask(b);single=h&(y.sum(1)==1);oldcorrect=y[np.arange(len(y)),old.argmax(1)];correct=y[np.arange(len(y)),new.argmax(1)];margins=[]
for row,s in zip(b,new):
 groups={}
 for c,sc in zip(row['candidates'],s):
  answer=parse_answer(c['text'])
  if answer is not None:groups[answer]=max(float(sc),groups.get(answer,-float('inf')))
 vals=sorted(groups.values(),reverse=True);margins.append(vals[0]-vals[1]if len(vals)>1 else float('nan'))
margins=np.array(margins);order=np.where(h)[0][np.argsort(margins[h])];bins=[]
def wilson(k,n):
 z=1.96;v=k/n;den=1+z*z/n;center=(v+z*z/(2*n))/den;radius=z*math.sqrt(v*(1-v)/n+z*z/(4*n*n))/den;return [center-radius,center+radius]
for j,ids in enumerate(np.array_split(order,4)):
 k=int(correct[ids].sum());bins.append(dict(quartile=j+1,n=len(ids),correct=k,accuracy=k/len(ids),margin_min=float(margins[ids].min()),margin_max=float(margins[ids].max()),wilson95=wilson(k,len(ids))))
rng=np.random.default_rng(4300);changes={}
for name,mask in [('hard',h),('singleton',single)]:
 diff=correct[mask].astype(float)-oldcorrect[mask];boot=diff[rng.integers(0,len(diff),(10000,len(diff)))].mean(1);changes[name]=dict(n=int(mask.sum()),old_correct=int(oldcorrect[mask].sum()),new_correct=int(correct[mask].sum()),corrected=int(((~oldcorrect)&correct&mask).sum()),harmed=int((oldcorrect&(~correct)&mask).sum()),delta=float(diff.mean()),bootstrap95=np.quantile(boot,[.025,.975]).tolist())
out=dict(confidence='Distinct valid answer group max-logit margin; not calibrated probability.',hard_margin_quartiles=bins,paired_validation_changes=changes,post_selection_limitation='Intervals condition on selected models and do not correct for extensive validation search.');Path('runs/v6-reliability.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
