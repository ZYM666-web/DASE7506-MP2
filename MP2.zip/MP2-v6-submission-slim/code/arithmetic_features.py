"""Arithmetic feasibility of numeric answers from question quantities."""
import itertools
import numpy as np
from fractions import Fraction
from rich_features import numbers
from common import parse_answer
# Fixed program vocabulary; no learned values, no reference access.
# Programs use question numbers in order and universal unit constants.
def arithmetic_features(bank):
 out=[]
 for row in bank:
  qn=numbers(row['question'])[:6];v=np.array(qn+[2.,100.,60.,7.,12.,24.],dtype=np.float64);mask=np.zeros(12,dtype=bool);mask[:len(qn)]=True;v=np.r_[qn,[0.]*(6-len(qn)),[2.,100.,60.,7.,12.,24.]];mask[6:]=True
  with np.errstate(all='ignore'):
   pair=np.array([v[:,None]+v[None,:],v[:,None]-v[None,:],v[:,None]*v[None,:],v[:,None]/v[None,:]])
   ok=mask[:,None]&mask[None,:]&~np.eye(12,dtype=bool)
   # Every ordered question-number pair with all four binary operations.
   vals=pair[:, :6,:6].reshape(-1);valid=np.broadcast_to(ok[:6,:6],(4,6,6)).reshape(-1)
   # Relation to unit constants, grouped by each question number.
   units=pair[:,:6,6:].reshape(-1);umask=np.broadcast_to(mask[:6,None],(4,6,6)).reshape(-1)
   triples=[];tv=[]
   for op in range(4):
    base=pair[op,:6,:6]
    for op2 in range(4):
     w=v[:6][None,None,:]
     z=[base[:,:,None]+w,base[:,:,None]-w,base[:,:,None]*w,base[:,:,None]/w][op2]
     distinct=(np.arange(6)[:,None,None]!=np.arange(6)[None,None,:])&(np.arange(6)[None,:,None]!=np.arange(6)[None,None,:])
     vm=ok[:6,:6,None]&mask[None,None,:6]&distinct
     triples.append(z);tv.append(vm)
   triple=np.array(triples);tm=np.array(tv)
  fs=[]
  for c in row['candidates']:
   a=parse_answer(c['text']);n=float(Fraction(a)) if a is not None else np.nan;tol=1e-5*(1+abs(n))
   match=lambda z:np.isfinite(z)&(np.abs(z-n)<=tol)
   pa=(match(vals)&valid).astype('float32');un=(match(units)&umask).astype('float32');tr=match(triple)&tm
   # Triple templates retain operator order and all three input positions.
   fs.append(np.r_[pa,un,tr.reshape(-1),tr.sum((1,2,3))/10,float(pa.sum()),float(un.sum())])
  out.append(fs)
 return np.asarray(out,dtype=np.float32)
