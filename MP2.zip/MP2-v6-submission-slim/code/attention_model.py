import torch
from torch import nn
class AttentionNet(nn.Module):
 def __init__(self,d,kind='uniform'):
  super().__init__();self.enc=nn.Linear(d,128);layer=nn.TransformerEncoderLayer(128,4,256,dropout=.3,activation='gelu',batch_first=True,norm_first=True);self.context=nn.TransformerEncoder(layer,2,enable_nested_tensor=False);self.head=nn.Sequential(nn.Linear(384,64),nn.GELU(),nn.Dropout(.25),nn.Linear(64,1))
 def forward(self,x):
  h=self.enc(x);h=self.context(h);m=h.mean(1,keepdim=True).expand_as(h);return self.head(torch.cat([h,h-m,m],-1)).squeeze(-1)
