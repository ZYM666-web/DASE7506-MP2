"""Final selector: training-only OOF rank correction plus arithmetic evidence."""
import json
from pathlib import Path
import numpy as np
from submission import aggregate
from rich_features import rich_features
from verify_arithmetic import arithmetic_evidence

def predict(bank,arrays,checkpoint):
 import torch
 from rich_model import RichNet
 from catboost import CatBoostRanker
 torch.set_num_threads(4)
 p=Path(checkpoint);cfg=json.loads((p/'config.json').read_text());e,f=rich_features(bank,arrays);base=np.concatenate([e,f],-1);delta=np.concatenate([e,e-e.mean(1,keepdims=True),f,f-f.mean(1,keepdims=True)],-1);total=np.zeros((len(bank),4),dtype=np.float32)
 with torch.no_grad():
  for member in cfg['families']:
   z=np.load(p/member['stats']);raw=delta if member['type']=='delta' else base;x=torch.from_numpy(np.clip((raw-z['mean'])/z['std'],-15,15).astype('float32'));logits=np.zeros((len(bank),4),dtype=np.float32)
   for name in member['models']:
    net=RichNet(x.shape[-1]);net.load_state_dict(torch.load(p/name,map_location='cpu',weights_only=True));net.eval();logits+=net(x).numpy()/len(member['models'])
   total+=logits*(member['weight']/member['scale'])
 total=total-total.mean(1,keepdims=True);total=total/total.std(1,keepdims=True).clip(.05);vf=arithmetic_evidence(bank);mx=np.concatenate([total[:,:,None],vf,f,f-f.mean(1,keepdims=True)],-1).reshape(len(bank)*4,-1);mx=np.round(mx,4);residual=np.zeros_like(total,dtype=np.float64)
 for name in cfg['rank_models']:
  ranker=CatBoostRanker();ranker.load_model(str(p/name));residual+=ranker.predict(mx,thread_count=4).reshape(-1,4)/len(cfg['rank_models'])
 score=aggregate(total+cfg['rank_multiplier']*residual,bank,cfg['alpha'])/cfg['rank_scale'];score+=cfg['arithmetic_weight']*(vf[:,:,5]-.5*vf[:,:,6])
 return score


