import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='4'
import json,time
import numpy as np
from sklearn.linear_model import LogisticRegression
from common import load_inputs,read_jsonl,DATA,parse_answer
from submission import features
start=time.time();xs=[];ys=[];banks=[];raw=[]
for split in ['train','validation']:
 b,a=load_inputs(split);banks.append(b);raw.append(features(b,a));g=read_jsonl(DATA/f'gsm8k_{split}.jsonl');ys.append(np.array([[parse_answer(c['text']) is not None and parse_answer(c['text'])==parse_answer(q['answer']) for c in r['candidates']] for r,q in zip(b,g)]))
def acc(p,mask=None):
 v=ys[1][np.arange(len(p)),p];return float(v.mean() if mask is None else v[mask].mean())
hard=np.array([len(set(a for a in [parse_answer(c['text']) for c in r['candidates']] if a))>=2 for r in banks[1]])
r={};p=[]
for row in banks[1]:
 a=[parse_answer(c['text']) for c in row['candidates']];p.append(int(np.argmax([a.count(v) if v else -1 for v in a])))
r['majority']={'all':acc(p),'hard':acc(p,hard)}
for kind in ['text_features','embeddings']:
 xx=[f if kind=='text_features' else e for e,f in raw];m=xx[0].mean((0,1));s=xx[0].std((0,1)).clip(.1)
 for C in [.01,.1,1,10]:
  clf=LogisticRegression(C=C,max_iter=500);clf.fit(((xx[0]-m)/s).reshape(-1,xx[0].shape[-1]),ys[0].flatten());pr=clf.decision_function(((xx[1]-m)/s).reshape(-1,xx[1].shape[-1])).reshape(-1,4);p=pr.argmax(1)
  r[f'{kind}_C{C}']={'all':acc(p),'hard':acc(p,hard)}
r['hard_n']=int(hard.sum());r['seconds']=time.time()-start
open('runs/baselines.json','w').write(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
