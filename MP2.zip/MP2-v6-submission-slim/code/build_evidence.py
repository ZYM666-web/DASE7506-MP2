from pathlib import Path
import numpy as np
from common import load_inputs
from verify_arithmetic import arithmetic_evidence
p=Path('runs/v2');p.mkdir(parents=True,exist_ok=True)
a=[]
for split in ['train','validation']:
 bank,_=load_inputs(split);a.append(arithmetic_evidence(bank))
np.savez(p/'verification_features.npz',train=a[0],validation=a[1])
