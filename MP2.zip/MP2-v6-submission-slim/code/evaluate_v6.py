import os,subprocess,sys,time,json,hashlib
from pathlib import Path
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[k]='4'
p=Path('runs/final');freeze=json.loads(Path('runs/frozen_v6.json').read_text());assert all(hashlib.sha256((p/f).read_bytes()).hexdigest()==v['sha256']for f,v in freeze['files'].items());assert all(hashlib.sha256(Path(f).read_bytes()).hexdigest()==v for f,v in freeze['sources'].items());t=time.perf_counter()
subprocess.run([sys.executable,'predict.py','--method','submission_v6.py','--checkpoint',str(p),'--split','test','--output','runs/v6-test-predictions.json'],check=True)
subprocess.run([sys.executable,'score_predictions.py','--split','test','--predictions','runs/v6-test-predictions.json','--output','runs/v6-test-score.json'],check=True)
r=dict(fresh_prediction_plus_scoring_seconds=time.perf_counter()-t,cpu='Intel Core i7-12700H',threads=4,asset_bytes=freeze['asset_bytes']);Path('runs/v6-resources.json').write_text(json.dumps(r,indent=2));print(r)
