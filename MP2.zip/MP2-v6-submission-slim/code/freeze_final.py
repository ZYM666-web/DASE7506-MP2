import json,shutil,hashlib
from pathlib import Path
p=Path('runs/final');p.mkdir(parents=True,exist_ok=True);old=Path('runs/final_v2');cfg=json.loads((old/'config.json').read_text());search=json.loads(Path('runs/v2/v3_search.json').read_text());chosen=search['results'][0];assert chosen['rank_weight']==1
for member in cfg['families']:
 for name in member['models']+[member['stats']]:shutil.copy2(old/name,p/name)
for seed in [1700,1701]:shutil.copy2(Path('runs/v2')/f'rank{seed}.cbm',p/f'rank{seed}.cbm')
cfg.update(rank_models=['rank1700.cbm','rank1701.cbm'],rank_multiplier=2,rank_scale=search['rank_scale'],arithmetic_weight=chosen['arithmetic_weight'],selection='Frozen v3: hard-validation selection only; v1/v2 aggregate test exposure disclosed.')
(p/'config.json').write_text(json.dumps(cfg,indent=2));files={f.name:dict(sha256=hashlib.sha256(f.read_bytes()).hexdigest(),bytes=f.stat().st_size)for f in p.iterdir()};size=sum(v['bytes']for v in files.values());assert size<16*2**20
source={name:hashlib.sha256(Path(name).read_bytes()).hexdigest()for name in ['submission_final.py','submission.py','rich_features.py','rich_model.py','verify_arithmetic.py']}
Path('runs/frozen_final.json').write_text(json.dumps(dict(files=files,asset_bytes=size,source_hashes=source,selection=chosen,test_exposure='Before this frozen version, aggregate test scores for v1 and v2 were known. No test references, selected test examples or per-example errors were inspected for development. Models and settings selected on train/internal holdout/validation only.'),indent=2));print('FROZEN bytes',size,'MiB',size/2**20)
