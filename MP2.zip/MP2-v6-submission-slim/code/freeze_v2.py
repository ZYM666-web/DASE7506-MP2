import json,shutil,hashlib
from pathlib import Path
import numpy as np
from common import load_inputs
from submission import aggregate
from rich_features import hard_mask
p=Path('runs/v2');out=Path('runs/final_v2');out.mkdir(parents=True,exist_ok=True);search=json.loads((p/'ensemble_search.json').read_text());chosen=search['results'][0];members=[]
for family,w in chosen['weights'].items():
 names=[f'{family}{seed}.pt' for seed in ([400,401,402] if family.startswith('delta') else [300,301,302])];stats='delta_stats.npz' if family.startswith('delta') else 'rich_stats.npz'
 for name in names+[stats]:shutil.copy2(p/name,out/name)
 members.append(dict(type='delta' if family.startswith('delta') else 'rich',stats=stats,models=names,weight=w,scale=search['scales'][family]))
cfg=dict(families=members,alpha=.5,selection='Highest hard-validation accuracy among recorded family combinations; first tie uses only two families.')
(out/'config.json').write_text(json.dumps(cfg,indent=2));files={f.name:dict(sha256=hashlib.sha256(f.read_bytes()).hexdigest(),bytes=f.stat().st_size) for f in out.iterdir()};size=sum(x['bytes'] for x in files.values());assert size<16*2**20
Path('runs/frozen_v2.json').write_text(json.dumps(dict(files=files,asset_bytes=size,configuration=cfg,validation_hard=chosen['hard'],test_exposure='Initial v1 aggregate test accuracy was known; no test references or per-example errors were inspected; v2 selected using hard validation only.'),indent=2));print('FROZEN',size,size/2**20,chosen)
