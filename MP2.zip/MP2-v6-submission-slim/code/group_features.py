import numpy as np
from common import parse_answer
from submission import features

def answer_groups(bank,arrays):
 e,f=features(bank,arrays);x=[];mask=[];mapping=[]
 for j,r in enumerate(bank):
  groups={}
  for i,c in enumerate(r['candidates']):
   a=parse_answer(c['text'])
   if a is not None:groups.setdefault(a,[]).append(i)
  ids=list(groups.values());ge=np.array([e[j,g].mean(0) for g in ids],dtype=np.float32);gf=np.array([np.r_[f[j,g].mean(0),f[j,g].std(0),len(g)/4] for g in ids],dtype=np.float32)
  if len(ids):
   z=np.concatenate([ge,ge-ge.mean(0,keepdims=True),gf],-1)
  else:z=np.zeros((0,2097),dtype=np.float32)
  zz=np.zeros((4,2097),dtype=np.float32);zz[:len(z)]=z;x.append(zz);mask.append([i<len(z) for i in range(4)]);mapping.append(ids)
 return np.asarray(x),np.asarray(mask),mapping
