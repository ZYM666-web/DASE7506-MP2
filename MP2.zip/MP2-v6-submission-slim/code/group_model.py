import torch
from torch import nn
class GroupNet(nn.Module):
 def __init__(self,d=2097):
  super().__init__();self.enc=nn.Sequential(nn.Linear(d,128),nn.GELU(),nn.Dropout(.4));self.head=nn.Sequential(nn.Linear(384,64),nn.GELU(),nn.Dropout(.3),nn.Linear(64,1))
 def forward(self,x,mask):
  h=self.enc(x);m=(h*mask[:,:,None]).sum(1,keepdim=True)/mask.sum(1)[:,None,None].clamp(min=1);m=m.expand_as(h);s=self.head(torch.cat([h,h-m,m],-1)).squeeze(-1)
  return s.masked_fill(~mask,-1e4)
