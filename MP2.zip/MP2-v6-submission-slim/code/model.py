import torch
from torch import nn
class Net(nn.Module):
    def __init__(self,d):
        super().__init__()
        self.enc=nn.Sequential(nn.Linear(d,128),nn.ReLU(),nn.Dropout(.25))
        self.head=nn.Sequential(nn.Linear(128*3,64),nn.ReLU(),nn.Dropout(.2),nn.Linear(64,1))
    def forward(self,x):
        h=self.enc(x); m=h.mean(1,keepdim=True).expand_as(h)
        return self.head(torch.cat([h,h-m,m],-1)).squeeze(-1)
