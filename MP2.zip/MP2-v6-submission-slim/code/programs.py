"""Train-reference-derived arithmetic programs; no IDs or answer tables."""
import ast,json,re,math
from fractions import Fraction
import numpy as np
NUMBER=re.compile(r'(?<![\w.])[-+]?(?:\d[\d,]*(?:\.\d+)?|\.\d+)(?:/\d+(?:\.\d+)?)?')
WORDNUM={'zero':'0','one':'1','two':'2','three':'3','four':'4','five':'5','six':'6','seven':'7','eight':'8','nine':'9','ten':'10','eleven':'11','twelve':'12','dozen':'12','twenty':'20','thirty':'30','hundred':'100'}
CONSTANTS={0.,.01,.1,.25,.5,.75,1.,2.,3.,4.,5.,6.,7.,10.,12.,20.,24.,30.,50.,60.,100.,1000.,365.}
def question_values(text):
 t=re.sub(r'\b('+'|'.join(WORDNUM)+r')\b',lambda m:WORDNUM[m[0]],text.lower());values=[]
 def sub(m):
  try:v=float(Fraction(m[0].replace(',','')))
  except (ValueError,ZeroDivisionError):v=0.
  idx=len(values);values.append(v);return ' num'+str(idx)+' '
 t=NUMBER.sub(sub,t)
 return values[:12],t

def serial(t):return json.dumps(t,separators=(',',':'))
def canonical(op,a,b):
 if op in ['+','*']:
  if serial(a)>serial(b):a,b=b,a
 if op=='+' and a==('c',0.):return b
 if op=='+' and b==('c',0.):return a
 if op=='-' and a==b:return ('c',0.)
 if op=='*' and a==('c',1.):return b
 if op=='*' and b==('c',1.):return a
 if op=='/' and b==('c',1.):return a
 return (op,a,b)

def size(p):return 1 if p[0]in ['q','c']else 1+size(p[1])+size(p[2])
def scalar_eval(p,values):
 try:
  if p[0]=='q':return values[p[1]]
  if p[0]=='c':return p[1]
  a,b=scalar_eval(p[1],values),scalar_eval(p[2],values)
  if p[0]=='+':v=a+b
  elif p[0]=='-':v=a-b
  elif p[0]=='*':v=a*b
  elif p[0]=='/':v=a/b
  else:raise ValueError()
  if not math.isfinite(v)or abs(v)>1e15:raise ValueError()
  return v
 except (ZeroDivisionError,IndexError,OverflowError):raise ValueError()

def reference_programs(question,answer,gold):
 values,_=question_values(question);found=set()
 for prefer_history in [False,True]:
  history={}
  for eq in re.findall(r'<<([^<>]+)>>',answer):
   if '='not in eq:continue
   left,right=eq.rsplit('=',1)
   try:result=float(Fraction(right.replace(',','').strip()));tree=ast.parse(left.replace(',','').replace('^','**').strip(),mode='eval')
   except (ValueError,SyntaxError,ZeroDivisionError):continue
   def build(node):
    if isinstance(node,ast.Expression):return build(node.body)
    if isinstance(node,ast.Constant)and type(node.value)in[int,float]:
     v=float(node.value);matches=[i for i,n in enumerate(values)if abs(n-v)<1e-7*(1+abs(v))]
     if prefer_history and v in history:return history[v]
     if matches:return ('q',matches[0])
     if v in history:return history[v]
     if v in CONSTANTS:return ('c',v)
     raise ValueError()
    if isinstance(node,ast.UnaryOp)and isinstance(node.op,ast.USub):return canonical('-',('c',0.),build(node.operand))
    if isinstance(node,ast.BinOp):
     op={ast.Add:'+',ast.Sub:'-',ast.Mult:'*',ast.Div:'/'}[type(node.op)];return canonical(op,build(node.left),build(node.right))
    raise ValueError()
   try:
    program=build(tree)
    if size(program)>39:continue
    value=scalar_eval(program,values)
    if abs(value-result)>1e-5*(1+abs(result)):continue
    history[result]=program
    if abs(value-gold)<1e-5*(1+abs(gold)):found.add(serial(program))
   except (ValueError,KeyError,TypeError,RecursionError):continue
 return found

def evaluate_bank(programs,bank):
 vals=[question_values(r['question'])[0]for r in bank];q=np.full((len(bank),12),np.nan,dtype=np.float64)
 for i,v in enumerate(vals):q[i,:len(v)]=v
 def ev(p):
  if p[0]=='q':return q[:,p[1]]
  if p[0]=='c':return np.full(len(bank),p[1])
  a,b=ev(p[1]),ev(p[2])
  with np.errstate(all='ignore'):
   if p[0]=='+':return a+b
   if p[0]=='-':return a-b
   if p[0]=='*':return a*b
   if p[0]=='/':return a/b
  raise ValueError()
 return np.stack([ev(p)for p in programs],1)
