import torch
from torch import nn

class RelationalVerifier(nn.Module):
 def __init__(self,features,hidden=64):
  super().__init__();self.enc=nn.Sequential(nn.Linear(features,hidden),nn.LayerNorm(hidden),nn.GELU(),nn.Dropout(.4));self.pair=nn.Sequential(nn.Linear(hidden*4,hidden),nn.GELU(),nn.Dropout(.4),nn.Linear(hidden,1));self.direct=nn.Linear(hidden,1)
 def pair_scores(self,x):
  h=self.enc(x);n,c,d=h.shape;a=h[:,:,None,:].expand(-1,-1,c,-1);b=h[:,None,:,:].expand(-1,c,-1,-1);r=self.pair(torch.cat([a,b,a-b,a*b],-1)).squeeze(-1);r=(r-r.transpose(1,2))*.5;return r+.1*(self.direct(h)-self.direct(h).transpose(1,2))
 def forward(self,x,valid):
  r=self.pair_scores(x);mask=valid[:,None,:].to(x.dtype);return (r*mask).sum(2)/mask.sum(2).clamp(min=1)
