"""Input-only numeric and surface features. Never execute candidate text."""
import ast,re,math
from fractions import Fraction
import numpy as np
from common import parse_answer
from submission import features
WORDS=['total','remaining','left','each','per','more','less','twice','half','percent','original','discount','profit','cost','paid','rate','average','difference','together','first','second','third','day','week','hour','minute','year','month','distance','speed','how many','how much','at least','at most','integer','round','approximately','assume','assuming','however','wait','mistake','incorrect','correct','check','verify','alternative','but','therefore','thus','actually','seems','not','cannot','impossible','remainder','ratio','fraction','double','triple','sold','buy','earned','spend','save','increase','decrease','subtract','multiply','divide','add','sum']
NUM=r'(?<![a-zA-Z])[-+]?\d[\d,]*(?:\.\d+)?'
def numbers(t):
 out=[]
 for s in re.findall(NUM,t):
  try:
   n=float(s.replace(',',''));out.append(n if abs(n)<1e15 else 0.)
  except ValueError:pass
 return out

def calc(s):
 try:
  tree=ast.parse(s.strip(),mode='eval')
  def ev(n):
   if isinstance(n,ast.Expression):return ev(n.body)
   if isinstance(n,ast.Constant) and type(n.value) in [float,int]:return float(n.value)
   if isinstance(n,ast.UnaryOp) and isinstance(n.op,(ast.UAdd,ast.USub)):return ev(n.operand)*(1 if isinstance(n.op,ast.UAdd) else -1)
   if isinstance(n,ast.BinOp):
    l,r=ev(n.left),ev(n.right)
    if isinstance(n.op,ast.Add):return l+r
    if isinstance(n.op,ast.Sub):return l-r
    if isinstance(n.op,ast.Mult):return l*r
    if isinstance(n.op,ast.Div):return l/r
   raise ValueError()
  v=ev(tree);return v if math.isfinite(v) else None
 except (ValueError,SyntaxError,TypeError,ZeroDivisionError,OverflowError):return None

def equations(t):
 t=t.replace(',','').replace('\\times','*').replace('\\cdot','*').replace('×','*').replace('÷','/').replace('\\div','/')
 for _ in range(3):t=re.sub(r'\\(?:d?frac)\{([^{}]+)\}\{([^{}]+)\}',r'((\1)/(\2))',t)
 good=bad=0;errs=[]
 for m in re.finditer(r'([\d.() +*/\-]{3,})\s*=\s*([-+]?\d+(?:\.\d+)?)',t):
  lhs=m[1].strip();v=calc(lhs)
  if v is None or not any(c in lhs for c in '+-*/'):continue
  rhs=float(m[2]);err=abs(v-rhs)/(1+abs(rhs));errs.append(min(err,10))
  good+=err<1e-4;bad+=err>=1e-4
 return [good/10,bad/10,max(errs,default=0),sum(errs)/(1+len(errs))]

def rich_features(bank,arrays):
 e,f=features(bank,arrays);allf=[]
 for row in bank:
  q=row['question'].lower();qn=numbers(q);cq=[];aset=[parse_answer(c['text']) for c in row['candidates']]
  ns=[float(Fraction(a)) if a is not None else 0. for a in aset]
  for i,c in enumerate(row['candidates']):
   t=c['text'].lower();n=ns[i];nt=numbers(t);valid=[v for v,a in zip(ns,aset) if a is not None];lg=lambda v:np.sign(v)*np.log1p(abs(v))/10
   z=[len(q)/1000,len(qn)/10,len(nt)/50,lg(n),lg(min(valid,default=0)),lg(max(valid,default=0)),lg(n-np.median(valid)) if valid else 0,n==min(valid,default=0),n==max(valid,default=0),sum(abs(v-n)<1e-5 for v in nt)/10,sum(abs(v-n)<1e-5 for v in qn)/5,len(set(nt))/50]
   if qn:
    z += [lg(sum(qn)),lg(max(qn)),lg(min(qn)),lg(n/(1+abs(sum(qn)))),lg(n/(1+abs(max(qn))))]
   else:z += [0]*5
   z+=equations(t)
   z += [t.count(w)/10 for w in WORDS]+[q.count(w)/3 for w in WORDS]
   z += [t.count(ch)/30 for ch in ['\\','*','$','#',':','?','!','%','/','(',')','-','+']]
   z += [len(t.rsplit('\\boxed',1)[-1])/1000 if '\\boxed' in t else 1, t.count('\\frac')/10, lg(sum(nt)),len(t.split('\n'))/50]
   cq.append(z)
  allf.append(cq)
 r=np.concatenate([f,np.array(allf,dtype=np.float32)],-1);r=np.nan_to_num(r,posinf=1e6,neginf=-1e6).clip(-1e6,1e6)
 return e,r

def hard_mask(bank):return np.array([len(set(a for a in [parse_answer(c['text']) for c in r['candidates']] if a is not None))>=2 for r in bank])
