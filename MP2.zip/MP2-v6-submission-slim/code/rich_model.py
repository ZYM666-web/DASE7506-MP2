import torch
from torch import nn
class RichNet(nn.Module):
 def __init__(self,d):
  super().__init__();self.enc=nn.Sequential(nn.Linear(d,192),nn.LayerNorm(192),nn.GELU(),nn.Dropout(.3));self.head=nn.Sequential(nn.Linear(576,96),nn.GELU(),nn.Dropout(.25),nn.Linear(96,1));self.linear=nn.Linear(d,1)
 def forward(self,x):
  h=self.enc(x);m=h.mean(1,keepdim=True).expand_as(h)
  return self.head(torch.cat([h,h-m,m],-1)).squeeze(-1)+.1*self.linear(x).squeeze(-1)
