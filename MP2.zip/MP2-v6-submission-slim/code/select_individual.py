import json,itertools
from pathlib import Path
import numpy as np
from common import load_inputs,parse_answer
from rich_features import hard_mask
from submission import aggregate
p=Path('runs/v2');b,_=load_inputs('validation');y=np.load('runs/validation_labels.npy');h=hard_mask(b);pool={};sources={};old=np.load('runs/validation_logits.npy');valid=np.array([[parse_answer(c['text'])is not None for c in r['candidates']]for r in b]);
for i in range(6):pool[f'old{i}']=old[i];sources[f'old{i}']=dict(kind='old',path=f'runs/model/model{i}.pt',bytes=Path(f'runs/model/model{i}.pt').stat().st_size)
for prefix,kind in [('bce','rich'),('pair','rich'),('mass','rich'),('delta_','delta'),('hard','hard'),('group','group'),('attention_','attention')]:
 for f in p.glob(f'{prefix}*_validation.npy'):
  name=f.name.replace('_validation.npy','');mp=p/f'{name}.pt'
  if mp.exists() and name not in pool:pool[name]=np.load(f);sources[name]=dict(kind=kind,path=str(mp),bytes=mp.stat().st_size)
scales={};A={}
for name,s in pool.items():
 ss=[row[v].std()for row,v,hard in zip(s,valid,h)if hard];scale=max(float(np.mean(ss)),.001);scales[name]=scale;A[name]=aggregate(s/scale,b,.5)
def score(s,mask=h):
 pp=s.argmax(1);v=y[np.arange(len(pp)),pp];return float(v[mask].mean())+1e-6*float(v.mean())
names=list(A);first=max(names,key=lambda n:score(A[n]));weights={first:1.};current=A[first];history=[]
for step in range(7):
 best=score(current);chosen=None
 for name in names:
  if name not in weights and sum(sources[k]['bytes']for k in weights)+sources[name]['bytes']>15*2**20:continue
  for w in [.1,.2,.3,.4,.5,.6,.7,.8,.9]:
   s=(1-w)*current+w*A[name];acc=score(s)
   if acc>best+1e-9:best=acc;chosen=(name,w,s)
 if chosen is None:break
 name,w,current=chosen;weights={k:v*(1-w)for k,v in weights.items()};weights[name]=weights.get(name,0)+w;history.append(dict(step=step,model=name,weight=w,hard=best,weights=weights.copy()));print(history[-1],flush=True)
pp=current.argmax(1);v=y[np.arange(len(pp)),pp];out=dict(weights=weights,scales=scales,sources=sources,history=history,hard=float(v[h].mean()),all=float(v.mean()),asset_bytes=sum(sources[k]['bytes']for k in weights));(p/'individual_search.json').write_text(json.dumps(out,indent=2));np.save(p/'individual_validation_scores.npy',current);print('FINAL',out['hard'],out['all'],out['asset_bytes'],weights)
