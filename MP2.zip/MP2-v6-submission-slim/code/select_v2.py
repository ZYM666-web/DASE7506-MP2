import json,itertools
from pathlib import Path
import numpy as np
from common import load_inputs
from rich_features import hard_mask
from submission import aggregate
p=Path('runs/v2');b,_=load_inputs('validation');y=np.load('runs/validation_labels.npy');h=hard_mask(b);models={};assets={}
old=np.load('runs/validation_logits.npy')
for n in [2,6]:models[f'old{n}']=old[:n].mean(0);assets[f'old{n}']=[f'old:model{i}.pt' for i in range(n)]
for prefix,seeds in [('bce',[300,301,302]),('pair',[300,301,302]),('mass',[300,301,302]),('delta_uniform',[400,401,402]),('delta_bce',[400,401,402]),('delta_mass',[400,401,402]),('hard',[710,711,712,713])]:
 names=[f'{prefix}{s}' for s in seeds];fs=[p/f'{name}_validation.npy' for name in names]
 if all(f.exists() for f in fs):models[prefix]=np.mean([np.load(f) for f in fs],0);assets[prefix]=[f'v2:{n}.pt' for n in names]
for name,ext in [('cat200','cbm'),('cat201','cbm'),('arith500','cbm'),('arith501','cbm'),('svm32_1_0.01','npz')]:
 f=p/f'{name}_validation.npy'
 if f.exists():models[name]=np.load(f);assets[name]=[f'v2:{name}.{ext}']
# Scale each member by its mean within-question logit standard deviation on hard validation inputs.
scales={k:float(v[h].std(axis=1).mean()) for k,v in models.items()};models={k:v/scales[k] for k,v in models.items()}
A={k:aggregate(v,b,.5) for k,v in models.items()}
def metric(s,ids=None):
 pp=s.argmax(1);v=y[np.arange(len(pp)),pp];return float(v[h].mean() if ids is None else v[ids].mean())
for k,v in A.items():print(k,metric(v),flush=True)
# Greedy three-family convex averaging. Keep all tested settings in the record.
names=list(A);results=[]
for k in names:results.append((metric(A[k]),{k:1.}))
for k,l in itertools.combinations(names,2):
 for w in [.25,.5,.75]:results.append((metric(w*A[k]+(1-w)*A[l]),{k:w,l:1-w}))
for k,l,m in itertools.combinations(names,3):
 for ww in [(1/3,1/3,1/3),(.5,.25,.25),(.25,.5,.25),(.25,.25,.5)]:results.append((metric(ww[0]*A[k]+ww[1]*A[l]+ww[2]*A[m]),dict(zip([k,l,m],ww))))
results.sort(key=lambda v:v[0],reverse=True)
for r in results[:12]:print('TOP',r,flush=True)
out=dict(scales=scales,assets=assets,results=[dict(hard=a,weights=w) for a,w in results]);(p/'ensemble_search.json').write_text(json.dumps(out,indent=2))
