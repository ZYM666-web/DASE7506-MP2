import json,itertools
from pathlib import Path
import numpy as np
from common import load_inputs
from rich_features import hard_mask
from submission import aggregate
p=Path('runs/v2');b,_=load_inputs('validation');y=np.load('runs/validation_labels.npy');h=hard_mask(b);vf=np.load(p/'verification_features.npz')['validation'];individual=np.load(p/'individual_validation_scores.npy');prior=np.load(p/'finalval_raw.npy');prior-=prior.mean(1,keepdims=True);prior/=prior.std(1,keepdims=True).clip(.05);rank=np.mean([np.load(p/f'rank{s}_validation.npy')for s in [1700,1701]],0);rank=aggregate(prior+2*rank,b,.5)
# Scale complete components by input-derived dispersion; invalid sentinels excluded.
from common import parse_answer
valid=np.array([[parse_answer(c['text'])is not None for c in r['candidates']]for r in b]);scale=lambda s:float(np.mean([row[v].std()for row,v,hard in zip(s,valid,h)if hard]));si=scale(individual);sr=scale(rank);results=[]
for w in [0,.25,.5,.75,1]:
 for ar in [0,.1,.25,.5,1]:
  sc=(1-w)*individual/si+w*rank/sr+ar*(vf[:,:,5]-.5*vf[:,:,6]);pp=sc.argmax(1);v=y[np.arange(len(pp)),pp];results.append(dict(rank_weight=w,arithmetic_weight=ar,hard=float(v[h].mean()),all=float(v.mean())))
results.sort(key=lambda z:(z['hard'],z['all']),reverse=True);out=dict(results=results,individual_scale=si,rank_scale=sr);(p/'v3_search.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
