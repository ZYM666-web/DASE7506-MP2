import re
import numpy as np
from common import parse_answer

def features(bank, arrays):
    out=[]
    for row in bank:
        cs=row['candidates']; ans=[parse_answer(c['text']) for c in cs]; fs=[]
        for i,c in enumerate(cs):
            t=c['text']; a=ans[i]; n=float(a.split('/')[0])/float(a.split('/')[1]) if a and '/' in a else float(a) if a else 0
            fs.append([a is not None,sum(x==a for x in ans) if a else 0,len(t)/1000,len(t.split())/200,t.count('\n')/30,t.count('=')/10,t.count('\\boxed'),t.count('####'),len(re.findall(r'\d+',t))/50,np.sign(n)*np.log1p(abs(n))/10,n<0,n==0,n==int(n),len(set(x for x in ans if x))/4]+[t.lower().count(w)/5 for w in ['wait','however','alternatively','mistake','therefore','check','but','so,','thus','approximately']])
        out.append(fs)
    f=np.asarray(out,dtype=np.float32); e=arrays['embeddings'].astype(np.float32)
    return e,f

def aggregate(scores, bank, alpha):
    s=scores.copy()
    for j,row in enumerate(bank):
        a=[parse_answer(c['text']) for c in row['candidates']]
        for i in range(4):
            if a[i] is None: s[j,i]=-1e9
            else:
                idx=[k for k in range(4) if a[k]==a[i]]
                s[j,i]=(1-alpha)*scores[j,i]+alpha*np.mean(scores[j,idx])
    return s

def predict(bank,arrays,checkpoint):
    import json
    from pathlib import Path
    import torch
    from model import Net
    torch.set_num_threads(4)
    p=Path(checkpoint); cfg=json.loads((p/'config.json').read_text()); z=np.load(p/'stats.npz')
    e,f=features(bank,arrays); x=np.concatenate([(e-z['em'])/z['es'],(f-z['fm'])/z['fs']],axis=-1)
    result=0
    with torch.no_grad():
        for name in cfg['models']:
            state=torch.load(p/name,map_location='cpu',weights_only=True); net=Net(x.shape[-1]); net.load_state_dict(state); net.eval()
            result=result+net(torch.from_numpy(x)).numpy()/len(cfg['models'])
    return aggregate(result,bank,cfg['alpha']).argmax(1).tolist()
