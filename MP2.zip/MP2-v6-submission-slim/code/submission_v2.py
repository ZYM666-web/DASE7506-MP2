"""Frozen second-round selector; evaluation reads no references."""
import json
from pathlib import Path
import numpy as np
from submission import aggregate
from rich_features import rich_features

def predict(bank,arrays,checkpoint):
 import torch
 from rich_model import RichNet
 torch.set_num_threads(4)
 p=Path(checkpoint);cfg=json.loads((p/'config.json').read_text());e,f=rich_features(bank,arrays);base=np.concatenate([e,f],-1);delta=np.concatenate([e,e-e.mean(1,keepdims=True),f,f-f.mean(1,keepdims=True)],-1);total=np.zeros((len(bank),4),dtype=np.float32)
 with torch.no_grad():
  for member in cfg['families']:
   z=np.load(p/member['stats']);raw=delta if member['type']=='delta' else base;x=np.clip((raw-z['mean'])/z['std'],-15,15).astype('float32');x=torch.from_numpy(x);logits=np.zeros((len(bank),4),dtype=np.float32)
   for name in member['models']:
    net=RichNet(x.shape[-1]);net.load_state_dict(torch.load(p/name,map_location='cpu',weights_only=True));net.eval();logits+=net(x).numpy()/len(member['models'])
   total+=logits*(member['weight']/member['scale'])
 return aggregate(total,bank,cfg['alpha']).argmax(1).tolist()
