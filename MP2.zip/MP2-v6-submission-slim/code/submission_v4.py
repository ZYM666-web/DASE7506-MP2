"""Question/solution alignment extension to the frozen V3.1 selector."""
import json
from pathlib import Path
import numpy as np
from submission import features,aggregate
from programs import question_values
from operation_profiles import candidate_profiles
from base_scores_v4 import predict as base_scores

def predict(bank,arrays,checkpoint):
 import torch
 from sklearn.feature_extraction.text import TfidfVectorizer
 from alignment_model import AlignmentNet
 torch.set_num_threads(4)
 p=Path(checkpoint);cfg=json.loads((p/'config.json').read_text());base=base_scores(bank,arrays,p);a=p/'alignment';z=np.load(a/'stats.npz');vocab=json.loads((a/'vocabulary.json').read_text());vec=TfidfVectorizer(vocabulary=vocab,ngram_range=(1,2),sublinear_tf=True);vec.idf_=z['idf'];q=torch.tensor(vec.transform([question_values(r['question'])[1]for r in bank]).toarray()*5,dtype=torch.float32);cp=candidate_profiles(bank);e,f=features(bank,arrays);raw=np.concatenate([e,f,cp],-1);x=torch.from_numpy(np.clip((raw-z['mean'])/z['std'],-15,15).astype('float32'));c=torch.from_numpy(cp);score=np.zeros((len(bank),4),dtype=np.float32)
 with torch.no_grad():
  for name,scale in zip(cfg['alignment']['models'],cfg['alignment']['scales']):
   net=AlignmentNet(len(vocab),x.shape[-1]);net.load_state_dict(torch.load(a/name,map_location='cpu',weights_only=True));net.eval();score+=net(x,q,c)[0].numpy()/scale/len(cfg['alignment']['models'])
 return (base+cfg['alignment']['weight']*aggregate(score,bank,.5)).argmax(1).tolist()
