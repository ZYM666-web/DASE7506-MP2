"""V5: fixed V4 prior plus train-only singleton pairwise verifier."""
import json
from pathlib import Path
import numpy as np
from submission import aggregate
from scores_v4 import predict as base_scores
from quality_features import prepare,transform

def predict(bank,arrays,checkpoint):
 import torch
 from relational_model import RelationalVerifier
 torch.set_num_threads(4)
 p=Path(checkpoint);cfg=json.loads((p/'config.json').read_text());base=base_scores(bank,arrays,p);r=cfg['pairwise'];a=p/'pairwise';z=np.load(a/'stats.npz');raw=prepare(bank,arrays);x=torch.tensor(transform(raw,z));valid=torch.tensor(raw[-1]);net=RelationalVerifier(x.shape[-1],r['hidden']);net.load_state_dict(torch.load(a/r['model'],map_location='cpu',weights_only=True));net.eval()
 with torch.no_grad():lp=net(x,valid).numpy()
 assert np.isfinite(lp).all()
 return (base+r['weight']*aggregate(lp/r['scale'],bank,.5)).argmax(1).tolist()
