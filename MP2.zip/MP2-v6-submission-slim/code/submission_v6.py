"""V6: validation-selected low-rank semantic ranking correction."""
import json
from pathlib import Path
import numpy as np
from submission import aggregate
from rich_features import rich_features
from operation_profiles import candidate_profiles
from baseline_features import baseline_features
from scores_v5 import predict as base_scores

def predict(bank,arrays,checkpoint):
 from sklearn.decomposition import PCA
 from catboost import CatBoostRanker
 p=Path(checkpoint);cfg=json.loads((p/'config.json').read_text())['semantic_residual'];base=base_scores(bank,arrays,p);e,f=rich_features(bank,arrays);r=p/'semantic_residual';z=np.load(r/'pca.npz');projection=(e-e.mean(1,keepdims=True)).reshape(-1,1024)@z['components'].T;projection-=z['mean'][None,:]@z['components'].T;projection=projection.reshape(-1,4,64);bf=baseline_features(bank,base);cp=candidate_profiles(bank);x=np.round(np.concatenate([bf,cp,f,f-f.mean(1,keepdims=True),projection],-1),4);net=CatBoostRanker();net.load_model(str(r/cfg['model']));lp=net.predict(x.reshape(-1,x.shape[-1]),thread_count=4).reshape(-1,4);return (base+cfg['weight']*aggregate(lp/cfg['scale'],bank,.5)).argmax(1).tolist()
