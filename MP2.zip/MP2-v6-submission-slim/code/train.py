import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']: os.environ[k]='4'
import json,time,random
from pathlib import Path
import numpy as np
import torch
from common import load_inputs,read_jsonl,DATA,parse_answer
from submission import features,aggregate
from model import Net

torch.set_num_threads(4)
p=Path('runs/model'); p.mkdir(parents=True,exist_ok=True)
banks=[]; X=[]; Y=[]; raw=[]
for split in ['train','validation']:
 b,a=load_inputs(split); e,f=features(b,a); banks.append(b);raw.append((e,f))
 gold=read_jsonl(DATA/f'gsm8k_{split}.jsonl'); Y.append(np.array([[parse_answer(c['text']) is not None and parse_answer(c['text'])==parse_answer(g['answer']) for c in r['candidates']] for r,g in zip(b,gold)],dtype=np.float32))
e,f=raw[0]; em=e.mean((0,1));es=e.std((0,1)).clip(.1);fm=f.mean((0,1));fs=f.std((0,1)).clip(.1)
np.savez(p/'stats.npz',em=em,es=es,fm=fm,fs=fs)
for e,f in raw:X.append(torch.from_numpy(np.concatenate([(e-em)/es,(f-fm)/fs],-1)))
y=torch.from_numpy(Y[0]); records=[]; bests=[]; start=time.time()
for seed in range(6):
 torch.manual_seed(100+seed); np.random.seed(100+seed)
 net=Net(X[0].shape[-1]); opt=torch.optim.AdamW(net.parameters(),lr=.0007,weight_decay=.01)
 best=-1; bestpred=None
 for epoch in range(45):
  net.train(); ix=torch.randperm(len(y))
  for ids in ix.split(128):
   s=net(X[0][ids]); target=y[ids]; loss=-(torch.log_softmax(s,1)*target/target.sum(1,keepdim=True)).sum(1).mean()+.3*torch.nn.functional.binary_cross_entropy_with_logits(s,target)
   opt.zero_grad();loss.backward();opt.step()
  net.eval()
  with torch.no_grad(): pred=net(X[1]).numpy()
  acc=Y[1][np.arange(len(pred)),aggregate(pred,banks[1],.5).argmax(1)].mean()
  if acc>best:
   best=float(acc);bestpred=pred.copy();torch.save(net.state_dict(),p/f'model{seed}.pt');be=epoch
  if epoch%10==0: print(seed,epoch,round(float(acc),5),flush=True)
 bests.append(bestpred); records.append(dict(seed=100+seed,epoch=be,validation=best));print('BEST',records[-1],flush=True)
np.save('runs/validation_logits.npy',np.array(bests));np.save('runs/validation_labels.npy',Y[1])
best=-1
for count in range(1,7):
 for alpha in [0,.5,1]:
  pred=aggregate(np.mean(bests[:count],0),banks[1],alpha).argmax(1);acc=float(Y[1][np.arange(len(pred)),pred].mean())
  if acc>best:best=acc;cfg=dict(models=[f'model{i}.pt' for i in range(count)],alpha=alpha)
(p/'config.json').write_text(json.dumps(cfg,indent=2));Path('runs/training.json').write_text(json.dumps(dict(records=records,chosen=cfg,validation=best,seconds=time.time()-start),indent=2));print('FINAL',best,cfg,flush=True)
