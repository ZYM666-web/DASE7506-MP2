$ErrorActionPreference='Stop'
$env:OMP_NUM_THREADS='4'
$env:OPENBLAS_NUM_THREADS='4'
$env:MKL_NUM_THREADS='4'
$env:NUMEXPR_NUM_THREADS='4'
$steps=@('check_data.py','train.py','baselines.py','analyze.py','train_cat.py','train_rich.py','train_delta.py','train_text.py','train_svm.py','train_hard.py','train_arith.py','train_group.py','train_attention.py','train_contrast.py','select_v2.py','freeze_v2.py','build_evidence.py','train_verify.py','train_stack.py','train_rank.py','select_individual.py','select_v3.py','freeze_final.py')
foreach($step in $steps){
 Write-Host "Running $step"
 python $step
 if($LASTEXITCODE -ne 0){throw "Training stopped at $step"}
}
Write-Host 'Training and validation selection complete. Run the official evaluator separately.'
