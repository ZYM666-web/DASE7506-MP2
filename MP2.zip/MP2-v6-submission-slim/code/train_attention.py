import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='4'
import time,json
from pathlib import Path
import numpy as np,torch
from common import load_inputs,read_jsonl,DATA,parse_answer
from submission import features,aggregate
from rich_features import hard_mask
from attention_model import AttentionNet
p=Path('runs/v2');torch.set_num_threads(4);start=time.time();bs=[];ys=[];xs=[];hs=[]
for split in ['train','validation']:
 b,a=load_inputs(split);bs.append(b);hs.append(hard_mask(b));e,f=features(b,a);xs.append(np.concatenate([e,e-e.mean(1,keepdims=True),f,f-f.mean(1,keepdims=True)],-1));g=read_jsonl(DATA/f'gsm8k_{split}.jsonl');ys.append(np.array([[parse_answer(c['text']) is not None and parse_answer(c['text'])==parse_answer(q['answer'])for c in r['candidates']]for r,q in zip(b,g)],dtype=np.float32))
m=xs[0].mean((0,1));std=xs[0].std((0,1)).clip(.05);np.savez(p/'attention_stats.npz',mean=m,std=std);xs=[torch.tensor(np.clip((x-m)/std,-15,15))for x in xs];y=torch.tensor(ys[0]);w=torch.tensor(np.where(hs[0],3.,.5),dtype=torch.float32);records=[]
for kind in ['uniform','pair']:
 for seed in [1400,1401,1402]:
  torch.manual_seed(seed);net=AttentionNet(xs[0].shape[-1]);opt=torch.optim.AdamW(net.parameters(),lr=.00025,weight_decay=.04);best=-1;name=f'attention_{kind}{seed}'
  for ep in range(45):
   net.train();ix=torch.randperm(len(y))
   for ids in ix.split(128):
    s=net(xs[0][ids]);t=y[ids];bce=torch.nn.functional.binary_cross_entropy_with_logits(s,t,reduction='none').mean(1)
    if kind=='uniform':loss=-(torch.log_softmax(s,1)*t/t.sum(1,keepdim=True)).sum(1)+.3*bce
    else:
     mask=t[:,:,None]*(1-t[:,None,:]);delta=s[:,:,None]-s[:,None,:];loss=(torch.nn.functional.softplus(1-delta)*mask).sum((1,2))/mask.sum((1,2)).clamp(min=1)+.2*bce
    loss=(loss*w[ids]).mean();opt.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(net.parameters(),5);opt.step()
   net.eval()
   with torch.no_grad():lp=net(xs[1]).numpy()
   pp=aggregate(lp,bs[1],.5).argmax(1);v=ys[1][np.arange(len(pp)),pp];acc=float(v[hs[1]].mean())
   if acc>best:best=acc;be=ep;state={k:v.clone()for k,v in net.state_dict().items()};bp=lp.copy();allacc=float(v.mean())
   if ep%15==0:print(name,ep,acc,flush=True)
  torch.save(state,p/f'{name}.pt');np.save(p/f'{name}_validation.npy',bp);r=dict(name=name,epoch=be,hard=best,all=allacc);records.append(r);print('BEST',r,flush=True);(p/'attention_records.json').write_text(json.dumps(dict(records=records,seconds=time.time()-start),indent=2))
