import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='4'
import time,json
from pathlib import Path
import numpy as np
from catboost import CatBoostClassifier
from common import load_inputs,read_jsonl,DATA,parse_answer
from rich_features import rich_features,hard_mask
from submission import aggregate
p=Path('runs/v2');p.mkdir(parents=True,exist_ok=True);start=time.time();bs=[];ys=[];xx=[];hs=[]
for split in ['train','validation']:
 b,a=load_inputs(split);bs.append(b);hs.append(hard_mask(b));e,f=rich_features(b,a);xx.append(np.concatenate([e,e-e.mean(1,keepdims=True),f,f-f.mean(1,keepdims=True)],-1).reshape(len(b)*4,-1));g=read_jsonl(DATA/f'gsm8k_{split}.jsonl');ys.append(np.array([[parse_answer(c['text']) is not None and parse_answer(c['text'])==parse_answer(q['answer']) for c in r['candidates']] for r,q in zip(b,g)],dtype=np.float32))
np.savez('runs/v2/devdata.npz',x0=xx[0],x1=xx[1],y0=ys[0],y1=ys[1],h0=hs[0],h1=hs[1]);print('features ready',xx[0].shape,'hard',hs[0].sum(),flush=True)
records=[]
for seed,depth in [(200,5),(201,6)]:
 model=CatBoostClassifier(iterations=1600,depth=depth,learning_rate=.04,l2_leaf_reg=8,thread_count=4,random_seed=seed,border_count=32,rsm=.35,loss_function='Logloss',allow_writing_files=False)
 model.fit(xx[0],ys[0].flatten(),sample_weight=np.repeat(np.where(hs[0],3.,1.),4),eval_set=(xx[1],ys[1].flatten()),verbose=200,early_stopping_rounds=250)
 best=-1;bestiter=0
 for nt in range(100,model.tree_count_+1,50):
  logits=model.predict(xx[1],prediction_type='RawFormulaVal',ntree_end=nt).reshape(-1,4)
  for alpha in [0,.5,1]:
   pred=aggregate(logits,bs[1],alpha).argmax(1);v=ys[1][np.arange(len(pred)),pred];score=float(v[hs[1]].mean())
   if score>best:best=score;bestiter=nt;ba=alpha;bp=logits;allacc=float(v.mean())
 model.shrink(bestiter);model.save_model(str(p/f'cat{seed}.cbm'));np.save(p/f'cat{seed}_validation.npy',bp)
 record=dict(seed=seed,depth=depth,trees=bestiter,alpha=ba,hard=best,all=allacc);records.append(record);print('BEST',record,flush=True)
(p/'cat_records.json').write_text(json.dumps({'records':records,'seconds':time.time()-start},indent=2))
