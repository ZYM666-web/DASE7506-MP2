import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='4'
import json,time
from pathlib import Path
import numpy as np
from sklearn.decomposition import PCA
from sklearn.svm import SVC
from common import load_inputs,read_jsonl,DATA,parse_answer
from submission import features,aggregate
from rich_features import hard_mask
p=Path('runs/v2');start=time.time();bs=[];ys=[];raw=[];hs=[]
for split in ['train','validation']:
 b,a=load_inputs(split);bs.append(b);hs.append(hard_mask(b));raw.append(features(b,a));g=read_jsonl(DATA/f'gsm8k_{split}.jsonl');ys.append(np.array([[parse_answer(c['text']) is not None and parse_answer(c['text'])==parse_answer(q['answer'])for c in r['candidates']]for r,q in zip(b,g)],dtype=np.float32))
e,f=raw[0];pc=PCA(64,random_state=1600).fit((e-e.mean(1,keepdims=True)).reshape(-1,1024));np.savez(p/'contrast_pca.npz',mean=pc.mean_,components=pc.components_);xx=[]
for e,f in raw:
 d=pc.transform((e-e.mean(1,keepdims=True)).reshape(-1,1024)).reshape(len(e),4,64);topic=pc.transform(e.reshape(-1,1024)).reshape(len(e),4,64);xx.append(np.concatenate([d,topic[:,:,:16],f],-1))
m=xx[0][hs[0]].mean((0,1));std=xx[0][hs[0]].std((0,1)).clip(.05);xx=[np.clip((x-m)/std,-10,10).reshape(len(x)*4,-1)for x in xx];tr=np.repeat(hs[0],4);records=[]
for kernel in ['poly','rbf']:
 for C in [.1,1,10,100]:
  name=f'contrast_{kernel}{C}';clf=SVC(C=C,kernel=kernel,degree=2,gamma=.01,coef0=1,cache_size=1000);clf.fit(xx[0][tr],ys[0].flatten()[tr]);lp=clf.decision_function(xx[1]).reshape(-1,4);best=-1
  for alpha in [0,.5,1]:
   pp=aggregate(lp,bs[1],alpha).argmax(1);v=ys[1][np.arange(len(pp)),pp];acc=float(v[hs[1]].mean())
   if acc>best:best=acc;ba=alpha;allacc=float(v.mean())
  np.savez(p/f'{name}.npz',support=clf.support_vectors_.astype('float32'),dual=clf.dual_coef_.astype('float32'),intercept=clf.intercept_.astype('float32'),mean=m,std=std);np.save(p/f'{name}_validation.npy',lp);r=dict(name=name,hard=best,all=allacc,alpha=ba,supports=len(clf.support_));records.append(r);print(r,flush=True);(p/'contrast_records.json').write_text(json.dumps(dict(records=records,seconds=time.time()-start),indent=2))
