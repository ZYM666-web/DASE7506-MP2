import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='4'
import json,time
from pathlib import Path
import numpy as np,torch
from common import load_inputs,read_jsonl,DATA,parse_answer
from group_features import answer_groups
from group_model import GroupNet
p=Path('runs/v2');torch.set_num_threads(4);start=time.time();bs=[];ys=[];xx=[];masks=[];maps=[]
for split in ['train','validation']:
 b,a=load_inputs(split);bs.append(b);x,mask,mapping=answer_groups(b,a);xx.append(x);masks.append(mask);maps.append(mapping);g=read_jsonl(DATA/f'gsm8k_{split}.jsonl');ys.append(np.array([[any(parse_answer(b[j]['candidates'][k]['text'])==parse_answer(g[j]['answer']) for k in group) for group in mm]+[False]*(4-len(mm)) for j,mm in enumerate(mapping)],dtype=np.float32))
tr=np.where(masks[0].sum(1)>=2)[0];vh=masks[1].sum(1)>=2;m=xx[0][masks[0]].mean(0);std=xx[0][masks[0]].std(0).clip(.05);np.savez(p/'group_stats.npz',mean=m,std=std);xx=[torch.tensor(np.clip((x-m)/std,-20,20)) for x in xx];mt=[torch.tensor(v) for v in masks];y=torch.tensor(ys[0]);records=[]
for seed in range(900,906):
 torch.manual_seed(seed);net=GroupNet();opt=torch.optim.AdamW(net.parameters(),lr=.0005,weight_decay=.03);best=-1
 for epoch in range(65):
  net.train();ix=torch.tensor(tr)[torch.randperm(len(tr))]
  for ids in ix.split(96):
   s=net(xx[0][ids],mt[0][ids]);target=y[ids];loss=-(torch.log_softmax(s,1)*target/target.sum(1,keepdim=True)).sum(1).mean();opt.zero_grad();loss.backward();opt.step()
  net.eval()
  with torch.no_grad():sg=net(xx[1],mt[1]).numpy()
  pred=sg.argmax(1);v=ys[1][np.arange(len(pred)),pred];score=float(v[vh].mean())
  if score>best:best=score;ep=epoch;state={k:v.clone() for k,v in net.state_dict().items()};bp=sg.copy();allacc=float(v.mean())
  if epoch%20==0:print('group',seed,epoch,score,flush=True)
 torch.save(state,p/f'group{seed}.pt');candidate=np.full((len(bs[1]),4),-1e4,dtype=np.float32)
 for j,mm in enumerate(maps[1]):
  for i,g in enumerate(mm):candidate[j,g]=bp[j,i]
 np.save(p/f'group{seed}_validation.npy',candidate);records.append(dict(seed=seed,epoch=ep,hard=best,all=allacc));print('BEST',records[-1],flush=True);(p/'group_records.json').write_text(json.dumps(dict(records=records,seconds=time.time()-start),indent=2))
