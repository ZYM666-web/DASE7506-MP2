import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='4'
import json,time
from pathlib import Path
import numpy as np,torch
from common import load_inputs,read_jsonl,DATA,parse_answer
from rich_features import hard_mask
from submission import features,aggregate
from model import Net
p=Path('runs/v2');torch.set_num_threads(4);start=time.time();bs=[];ys=[];xs=[];hs=[]
for split in ['train','validation']:
 b,a=load_inputs(split);bs.append(b);hs.append(hard_mask(b));e,f=features(b,a);xs.append(np.concatenate([e,f],-1));g=read_jsonl(DATA/f'gsm8k_{split}.jsonl');ys.append(np.array([[parse_answer(c['text']) is not None and parse_answer(c['text'])==parse_answer(q['answer']) for c in r['candidates']] for r,q in zip(b,g)],dtype=np.float32))
idx=np.where(hs[0])[0];rng=np.random.default_rng(700);rng.shuffle(idx);cut=int(len(idx)*.8);tr,ho=idx[:cut],idx[cut:];hb=[bs[0][i] for i in ho];m=xs[0][tr].mean((0,1));std=xs[0][tr].std((0,1)).clip(.1);xx=[torch.tensor((x-m)/std) for x in xs];y=torch.tensor(ys[0]);history=[]
def fit(seed,indices,epochs,monitor=None):
 torch.manual_seed(seed);net=Net(xx[0].shape[-1]);opt=torch.optim.AdamW(net.parameters(),lr=.0005,weight_decay=.025);best=-1
 for ep in range(epochs):
  net.train();ix=torch.tensor(indices)[torch.randperm(len(indices))]
  for ids in ix.split(96):
   s=net(xx[0][ids]);target=y[ids];loss=-(torch.log_softmax(s,1)*target/target.sum(1,keepdim=True)).sum(1).mean()+.3*torch.nn.functional.binary_cross_entropy_with_logits(s,target);opt.zero_grad();loss.backward();opt.step()
  if monitor is not None:
   net.eval()
   with torch.no_grad():s=net(xx[0][ho]).numpy()
   pred=aggregate(s,hb,.5).argmax(1);acc=float(ys[0][ho][np.arange(len(ho)),pred].mean());monitor.append(acc)
 return net
for seed in [700,701]:
 h=[];fit(seed,tr,65,h);history.append(h);print('internal seed',seed,'best',max(h),'epoch',np.argmax(h),flush=True)
epoch=int(np.argmax(np.mean(history,0)))+1;print('internal chosen epoch',epoch,flush=True)
m=xs[0][idx].mean((0,1));std=xs[0][idx].std((0,1)).clip(.1);np.savez(p/'hard_stats.npz',mean=m,std=std);xx=[torch.tensor((x-m)/std) for x in xs];records=[]
for seed in [710,711,712,713]:
 net=fit(seed,idx,epoch);net.eval()
 with torch.no_grad():s=net(xx[1]).numpy()
 pred=aggregate(s,bs[1],.5).argmax(1);v=ys[1][np.arange(len(pred)),pred];r=dict(seed=seed,epoch=epoch,hard=float(v[hs[1]].mean()),all=float(v.mean()));records.append(r);torch.save(net.state_dict(),p/f'hard{seed}.pt');np.save(p/f'hard{seed}_validation.npy',s);print(r,flush=True)
(p/'hard_records.json').write_text(json.dumps(dict(records=records,internal_history=history,internal_holdout_indices=ho.tolist(),epochs=epoch,seconds=time.time()-start),indent=2))
