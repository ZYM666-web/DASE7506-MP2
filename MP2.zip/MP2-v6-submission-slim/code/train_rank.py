import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='4'
import time,json
from pathlib import Path
import numpy as np
from catboost import CatBoostRanker,Pool
from common import load_inputs,read_jsonl,DATA,parse_answer
from rich_features import rich_features,hard_mask
from submission import aggregate
p=Path('runs/v2');start=time.time();bs=[];ys=[];xs=[];hs=[];prior=[];vf=np.load(p/'verification_features.npz')
for j,split in enumerate(['train','validation']):
 b,a=load_inputs(split);bs.append(b);hs.append(hard_mask(b));e,f=rich_features(b,a);s=np.load(p/('oof_stack_train.npy' if j==0 else 'finalval_raw.npy'));s=s-s.mean(1,keepdims=True);s=s/s.std(1,keepdims=True).clip(.05);prior.append(s);v=vf['train' if j==0 else 'validation'];xs.append(np.concatenate([s[:,:,None],v,f,f-f.mean(1,keepdims=True)],-1));g=read_jsonl(DATA/f'gsm8k_{split}.jsonl');ys.append(np.array([[parse_answer(c['text']) is not None and parse_answer(c['text'])==parse_answer(q['answer'])for c in r['candidates']]for r,q in zip(b,g)],dtype=np.float32))
print('features ready',flush=True);tr=hs[0];train=Pool(thread_count=4,data=xs[0][tr].reshape(-1,xs[0].shape[-1]),label=ys[0][tr].flatten(),group_id=np.repeat(np.arange(tr.sum()),4));print('train pool ready',flush=True);val=Pool(thread_count=4,data=xs[1].reshape(-1,xs[1].shape[-1]),label=ys[1].flatten(),group_id=np.repeat(np.arange(len(ys[1])),4));records=[];print('pools ready',flush=True)
for seed,depth in [(1700,4),(1701,5)]:
 model=CatBoostRanker(iterations=1600,depth=depth,learning_rate=.025,l2_leaf_reg=20,thread_count=4,random_seed=seed,border_count=32,loss_function='YetiRank',eval_metric='NDCG:top=1',allow_writing_files=False)
 model.fit(train,eval_set=val,verbose=300,use_best_model=False)
 best=-1
 for nt in range(50,model.tree_count_+1,25):
  lp=model.predict(xs[1].reshape(-1,xs[1].shape[-1]),ntree_end=nt).reshape(-1,4)
  for weight in [.25,.5,1,2]:
   z=prior[1]+weight*lp;pp=aggregate(z,bs[1],.5).argmax(1);v=ys[1][np.arange(len(pp)),pp];acc=float(v[hs[1]].mean())
   if acc>best:best=acc;bp=lp.copy();bn=nt;bw=weight;allacc=float(v.mean())
 model.shrink(bn);model.save_model(str(p/f'rank{seed}.cbm'));np.save(p/f'rank{seed}_validation.npy',bp);r=dict(seed=seed,trees=bn,weight=bw,hard=best,all=allacc);records.append(r);print('BEST',r,flush=True);(p/'rank_records.json').write_text(json.dumps(dict(records=records,seconds=time.time()-start),indent=2))



