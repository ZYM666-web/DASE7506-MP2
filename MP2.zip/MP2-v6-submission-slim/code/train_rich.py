import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='4'
import json,time
from pathlib import Path
import numpy as np,torch
from common import load_inputs,read_jsonl,DATA,parse_answer
from rich_features import rich_features,hard_mask
from rich_model import RichNet
from submission import aggregate
p=Path('runs/v2');p.mkdir(exist_ok=True,parents=True);torch.set_num_threads(4);start=time.time();bs=[];ys=[];xx=[];hs=[]
for split in ['train','validation']:
 b,a=load_inputs(split);bs.append(b);hs.append(hard_mask(b));e,f=rich_features(b,a);xx.append(np.concatenate([e,f],-1));g=read_jsonl(DATA/f'gsm8k_{split}.jsonl');ys.append(np.array([[parse_answer(c['text']) is not None and parse_answer(c['text'])==parse_answer(q['answer']) for c in r['candidates']] for r,q in zip(b,g)],dtype=np.float32))
m=xx[0].mean((0,1));std=xx[0].std((0,1)).clip(.1);np.savez(p/'rich_stats.npz',mean=m,std=std);xx=[torch.tensor(np.clip((x-m)/std,-15,15)) for x in xx];y=torch.tensor(ys[0]);weight=torch.tensor(np.where(hs[0],3.,1.),dtype=torch.float32);records=[]
for kind in ['bce','pair','mass']:
 for seed in [300,301,302]:
  torch.manual_seed(seed);net=RichNet(xx[0].shape[-1]);opt=torch.optim.AdamW(net.parameters(),lr=.0004,weight_decay=.025);best=-1;name=f'{kind}{seed}';beststate=None
  for epoch in range(65):
   net.train();ix=torch.randperm(len(y))
   for ids in ix.split(128):
    s=net(xx[0][ids]);target=y[ids];bce=torch.nn.functional.binary_cross_entropy_with_logits(s,target,reduction='none').mean(1)
    if kind=='bce':loss=bce
    elif kind=='mass':
     mass=torch.logsumexp(s,1)-torch.logsumexp(s.masked_fill(target==0,-1e4),1);loss=mass+.25*bce
    else:
     delta=s[:,:,None]-s[:,None,:];mask=target[:,:,None]*(1-target[:,None,:]);rank=(torch.nn.functional.softplus(1-delta)*mask).sum((1,2))/mask.sum((1,2)).clamp(min=1);loss=rank+.2*bce
    loss=(loss*weight[ids]).mean();opt.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(net.parameters(),5);opt.step()
   net.eval()
   with torch.no_grad():pred=net(xx[1]).numpy()
   pp=aggregate(pred,bs[1],.5).argmax(1);v=ys[1][np.arange(len(pp)),pp];acc=float(v[hs[1]].mean())
   if acc>best:best=acc;bestepoch=epoch;beststate={k:v.clone() for k,v in net.state_dict().items()};bp=pred.copy();allacc=float(v.mean())
   if epoch%15==0:print(name,epoch,round(acc,5),flush=True)
  torch.save(beststate,p/f'{name}.pt');np.save(p/f'{name}_validation.npy',bp);record=dict(name=name,kind=kind,seed=seed,epoch=bestepoch,hard=best,all=allacc);records.append(record);print('BEST',record,flush=True)
  (p/'rich_records.json').write_text(json.dumps({'records':records,'seconds':time.time()-start},indent=2))
