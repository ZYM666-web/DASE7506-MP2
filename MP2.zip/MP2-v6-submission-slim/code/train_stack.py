import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='4'
import json,time
from pathlib import Path
import numpy as np,torch
from sklearn.model_selection import KFold
from catboost import CatBoostClassifier
from common import load_inputs,read_jsonl,DATA,parse_answer
from rich_features import rich_features,hard_mask
from rich_model import RichNet
from submission import aggregate
from verify_arithmetic import arithmetic_evidence
p=Path('runs/v2');start=time.time();torch.set_num_threads(4);bs=[];ys=[];raw=[];hs=[]
for split in ['train','validation']:
 b,a=load_inputs(split);bs.append(b);hs.append(hard_mask(b));raw.append(rich_features(b,a));g=read_jsonl(DATA/f'gsm8k_{split}.jsonl');ys.append(np.array([[parse_answer(c['text']) is not None and parse_answer(c['text'])==parse_answer(q['answer'])for c in r['candidates']]for r,q in zip(b,g)],dtype=np.float32))
xs=[]
for e,f in raw:xs.append([np.concatenate([e,f],-1),np.concatenate([e,e-e.mean(1,keepdims=True),f,f-f.mean(1,keepdims=True)],-1)])
y=torch.tensor(ys[0]);w=torch.tensor(np.where(hs[0],3.,1.),dtype=torch.float32);oof=np.zeros((len(y),4),dtype=np.float32);fullval=np.zeros((len(bs[1]),4),dtype=np.float32)
for fold,(tr,ho) in enumerate(KFold(4,shuffle=True,random_state=1000).split(np.arange(len(y)))):
 for kind in [0,1]:
  m=xs[0][kind][tr].mean((0,1));std=xs[0][kind][tr].std((0,1)).clip(.1 if kind==0 else .03);x=torch.tensor(np.clip((xs[0][kind]-m)/std,-15,15));vx=torch.tensor(np.clip((xs[1][kind]-m)/std,-15,15));torch.manual_seed(1000+fold+kind*10);net=RichNet(x.shape[-1]);opt=torch.optim.AdamW(net.parameters(),lr=.0004 if kind==0 else .0003,weight_decay=.025 if kind==0 else .04)
  for ep in range(24):
   net.train();ix=torch.tensor(tr)[torch.randperm(len(tr))]
   for ids in ix.split(128):
    s=net(x[ids]);t=y[ids];loss=torch.logsumexp(s,1)-torch.logsumexp(s.masked_fill(t==0,-1e4),1)+.25*torch.nn.functional.binary_cross_entropy_with_logits(s,t,reduction='none').mean(1);loss=(loss*w[ids]).mean();opt.zero_grad();loss.backward();opt.step()
  net.eval()
  with torch.no_grad():hp=net(x[ho]).numpy();vp=net(vx).numpy()
  scale=max(float(hp.std(1).mean()),.01);oof[ho]+=hp/scale*(.25 if kind==0 else .75);fullval+=vp/scale*(.25 if kind==0 else .75)/4
  print('OOF done',fold,kind,flush=True)
np.save(p/'oof_stack_train.npy',oof);np.save(p/'oof_stack_validation.npy',fullval)
# Matching final frozen v2 prediction scores for validation meta-evaluation.
config=json.loads(Path('runs/final_v2/config.json').read_text());finalval=0
for member in config['families']:
 names=[Path(name).stem for name in member['models']];finalval=finalval+np.mean([np.load(p/f'{n}_validation.npy')for n in names],0)*member['weight']/member['scale']
np.save(p/'finalval_raw.npy',finalval)
vr=np.load(p/'verification_features.npz');sf=[vr['train'],vr['validation']];mx=[]
for split,(e,f) in enumerate(raw):
 score=oof if split==0 else finalval;score=score-score.mean(1,keepdims=True);score=score/score.std(1,keepdims=True).clip(.05)
 z=np.concatenate([score[:,:,None],sf[split],f,f-f.mean(1,keepdims=True)],-1);mx.append(z.reshape(len(bs[split])*4,-1))
records=[]
for seed in [1200,1201,1202]:
 model=CatBoostClassifier(iterations=1400,depth=4,learning_rate=.025,l2_leaf_reg=12,thread_count=4,random_seed=seed,border_count=32,loss_function='Logloss',allow_writing_files=False)
 model.fit(mx[0],ys[0].flatten(),sample_weight=np.repeat(np.where(hs[0],3.,1.),4),eval_set=(mx[1],ys[1].flatten()),verbose=300,early_stopping_rounds=250)
 best=-1
 for nt in range(50,model.tree_count_+1,25):
  lp=model.predict(mx[1],prediction_type='RawFormulaVal',ntree_end=nt).reshape(-1,4)
  for blend in [0,.25,.5,.75,1]:
   prior=mx[1][:,0].reshape(-1,4);z=blend*lp+(1-blend)*prior;pp=aggregate(z,bs[1],.5).argmax(1);v=ys[1][np.arange(len(pp)),pp];acc=float(v[hs[1]].mean())
   if acc>best:best=acc;bp=lp.copy();bn=nt;bb=blend;allacc=float(v.mean())
 model.shrink(bn);model.save_model(str(p/f'stack{seed}.cbm'));np.save(p/f'stack{seed}_validation.npy',bp);r=dict(seed=seed,trees=bn,blend=bb,hard=best,all=allacc);records.append(r);print('BEST',r,flush=True);(p/'stack_records.json').write_text(json.dumps(dict(records=records,seconds=time.time()-start),indent=2))
