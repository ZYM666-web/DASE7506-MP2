import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='4'
import time,json
from pathlib import Path
import numpy as np
from sklearn.decomposition import PCA
from sklearn.svm import SVC
from common import load_inputs,read_jsonl,DATA,parse_answer
from rich_features import hard_mask
from submission import features,aggregate
p=Path('runs/v2');start=time.time();bs=[];ys=[];raw=[];hs=[]
for split in ['train','validation']:
 b,a=load_inputs(split);bs.append(b);hs.append(hard_mask(b));raw.append(features(b,a));g=read_jsonl(DATA/f'gsm8k_{split}.jsonl');ys.append(np.array([[parse_answer(c['text']) is not None and parse_answer(c['text'])==parse_answer(q['answer']) for c in r['candidates']] for r,q in zip(b,g)],dtype=np.float32))
pca=PCA(n_components=128,random_state=600);pca.fit(raw[0][0].reshape(-1,1024));np.savez(p/'svm_pca.npz',mean=pca.mean_,components=pca.components_);records=[]
for d in [32,64,128]:
 xx=[]
 for e,f in raw:
  z=pca.transform(e.reshape(-1,1024)).reshape(len(e),4,128)[:,:,:d];xx.append(np.concatenate([z,z-z.mean(1,keepdims=True),f],-1))
 m=xx[0].mean((0,1));std=xx[0].std((0,1)).clip(.1);xx=[np.clip((x-m)/std,-10,10).reshape(len(x)*4,-1) for x in xx]
 for C,gamma in [(1,.01),(10,.01),(10,.003),(100,.003)]:
  name=f'svm{d}_{C}_{gamma}';clf=SVC(C=C,gamma=gamma,cache_size=800);clf.fit(xx[0],ys[0].flatten(),sample_weight=np.repeat(np.where(hs[0],3.,1.),4));lp=clf.decision_function(xx[1]).reshape(-1,4);best=-1
  for alpha in [0,.5,1]:
   pp=aggregate(lp,bs[1],alpha).argmax(1);v=ys[1][np.arange(len(pp)),pp];acc=float(v[hs[1]].mean())
   if acc>best:best=acc;ba=alpha;allacc=float(v.mean())
  np.savez(p/f'{name}.npz',support=clf.support_vectors_.astype('float32'),dual=clf.dual_coef_.astype('float32'),intercept=clf.intercept_.astype('float32'),mean=m,std=std,gamma=np.float32(gamma),dim=np.int32(d));np.save(p/f'{name}_validation.npy',lp);r=dict(name=name,hard=best,all=allacc,alpha=ba,supports=len(clf.support_));records.append(r);print(r,flush=True);(p/'svm_records.json').write_text(json.dumps(dict(records=records,seconds=time.time()-start),indent=2))
