import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='4'
import json,time
from pathlib import Path
import numpy as np
from scipy.sparse import hstack
from sklearn.feature_extraction.text import HashingVectorizer,TfidfTransformer
from sklearn.linear_model import LogisticRegression
from common import load_inputs,read_jsonl,DATA,parse_answer
from rich_features import hard_mask
from submission import aggregate
p=Path('runs/v2');bs=[];ys=[];xx=[];hs=[];start=time.time()
for split in ['train','validation']:
 b,_=load_inputs(split);bs.append(b);hs.append(hard_mask(b));g=read_jsonl(DATA/f'gsm8k_{split}.jsonl');ys.append(np.array([[parse_answer(c['text']) is not None and parse_answer(c['text'])==parse_answer(q['answer']) for c in r['candidates']] for r,q in zip(b,g)],dtype=np.float32));texts=[c['text'] for r in b for c in r['candidates']]
 v1=HashingVectorizer(n_features=2**16,ngram_range=(1,2),alternate_sign=False,norm=None);v2=HashingVectorizer(n_features=2**16,analyzer='char',ngram_range=(3,5),alternate_sign=False,norm=None)
 xx.append(hstack([v1.transform(texts),v2.transform(texts)]).tocsr());print('vectorized',split,flush=True)
tf=TfidfTransformer(sublinear_tf=True);xx[0]=tf.fit_transform(xx[0]);xx[1]=tf.transform(xx[1]);records=[]
for C in [.1,1,10]:
 clf=LogisticRegression(C=C,max_iter=250,solver='liblinear');clf.fit(xx[0],ys[0].flatten(),sample_weight=np.repeat(np.where(hs[0],3.,1.),4));logits=clf.decision_function(xx[1]).reshape(-1,4);best=-1
 for alpha in [0,.5,1]:
  pp=aggregate(logits,bs[1],alpha).argmax(1);v=ys[1][np.arange(len(pp)),pp];acc=float(v[hs[1]].mean())
  if acc>best:best=acc;ba=alpha;allacc=float(v.mean())
 np.savez(p/f'text{C}.npz',coef=clf.coef_.astype('float32'),intercept=clf.intercept_.astype('float32'),idf=tf.idf_.astype('float32'));np.save(p/f'text{C}_validation.npy',logits);records.append(dict(C=C,hard=best,all=allacc,alpha=ba));print(records[-1],flush=True)
(p/'text_records.json').write_text(json.dumps(dict(records=records,seconds=time.time()-start),indent=2))
