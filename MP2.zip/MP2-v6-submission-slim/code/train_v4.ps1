$ErrorActionPreference='Stop'
$env:OMP_NUM_THREADS='4';$env:OPENBLAS_NUM_THREADS='4';$env:MKL_NUM_THREADS='4';$env:NUMEXPR_NUM_THREADS='4'
Push-Location (Join-Path $PSScriptRoot 'v4')
try{
 foreach($step in @('build_alignment_inputs.py','train_alignment.py','select_alignment.py','freeze_alignment.py')){
  python $step
  if($LASTEXITCODE -ne 0){throw "Stopped at $step"}
 }
}finally{Pop-Location}
