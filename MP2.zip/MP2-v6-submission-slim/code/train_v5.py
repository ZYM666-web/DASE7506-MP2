"""Retrain the selected V5 extension; baseline checkpoint remains frozen.
CPU is supported. The released checkpoint was trained on CUDA; retraining
on another device/version may give different weights. No test data is read.
"""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[k]='4'
import argparse,json,time,shutil
from pathlib import Path
import numpy as np,torch
from common import load_inputs,read_jsonl,DATA,parse_answer
from rich_features import hard_mask
from quality_features import prepare,fit_transform,transform
from relational_model import RelationalVerifier
parser=argparse.ArgumentParser();parser.add_argument('--device',choices=['cpu','cuda'],default='cpu');parser.add_argument('--baseline',type=Path,default=Path('runs/final'));parser.add_argument('--output',type=Path,default=Path('runs/retrained_v5'));args=parser.parse_args();assert not args.output.exists(),'Use a fresh output directory';torch.set_num_threads(4);start=time.time();b,a=load_inputs('train');g=read_jsonl(DATA/'gsm8k_train.jsonl');y=np.array([[parse_answer(c['text'])is not None and parse_answer(c['text'])==parse_answer(q['answer'])for c in row['candidates']]for row,q in zip(b,g)],dtype='float32');hard=hard_mask(b);raw=prepare(b,a);z=fit_transform(raw,np.where(hard)[0],False);x=torch.tensor(transform(raw,z),device=args.device);valid=torch.tensor(raw[-1],device=args.device);target=torch.tensor(y,device=args.device);indices=np.where(hard&(y.sum(1)==1))[0];torch.manual_seed(3906);net=RelationalVerifier(x.shape[-1],64).to(args.device);opt=torch.optim.AdamW(net.parameters(),lr=.0004,weight_decay=.1)
for epoch in range(7):
 net.train();ids=torch.tensor(indices,device=args.device);ids=ids[torch.randperm(len(ids),device=args.device)]
 for ii in ids.split(96):
  t=target[ii];r=net.pair_scores(x[ii]);mask=t[:,:,None]*(1-t[:,None,:])*valid[ii,None,:];loss=((torch.nn.functional.softplus(1-r)*mask).sum((1,2))/mask.sum((1,2)).clamp(min=1)).mean();opt.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(net.parameters(),3);opt.step()
 print('epoch',epoch,'complete',flush=True)
net.eval();vb,va=load_inputs('validation');vr=prepare(vb,va)
with torch.no_grad():lp=net(torch.tensor(transform(vr,z),device=args.device),torch.tensor(vr[-1],device=args.device)).cpu().numpy()
vh=hard_mask(vb);scale=max(float(np.mean([s[v].std()for s,v,h in zip(lp,vr[-1],vh)if h])),.01);p=args.output;p.mkdir(parents=True)
for f in args.baseline.iterdir():
 if f.name=='pairwise':continue
 if f.is_dir():shutil.copytree(f,p/f.name)
 else:shutil.copy2(f,p/f.name)
pair=p/'pairwise';pair.mkdir();np.savez(pair/'stats.npz',**z);torch.save({k:v.detach().cpu()for k,v in net.state_dict().items()},pair/'pair.pt');cfg=json.loads((p/'config.json').read_text());cfg['pairwise']=dict(model='pair.pt',hidden=64,weight=.25,scale=scale);(p/'config.json').write_text(json.dumps(cfg,indent=2));(p.parent/(p.name+'-training.json')).write_text(json.dumps(dict(seed=3906,epochs=7,training_questions=len(indices),device=args.device,seconds=time.time()-start,scale=scale),indent=2));print('Saved',p)
