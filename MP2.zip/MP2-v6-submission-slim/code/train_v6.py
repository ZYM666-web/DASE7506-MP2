"""Retrain the selected semantic ranker, retaining frozen V5 components.
No test inputs or references are read. CPU is supported; the released ranker
used one RTX 3060 Laptop GPU. Cross-device retraining can differ.
"""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[k]='4'
import argparse,json,time,subprocess,sys,shutil
from pathlib import Path
import numpy as np
from sklearn.decomposition import PCA
from catboost import CatBoostRanker,Pool
from common import load_inputs,read_jsonl,DATA,parse_answer
from rich_features import rich_features,hard_mask
from operation_profiles import candidate_profiles
from baseline_features import baseline_features
from scores_v5 import predict as base_scores
parser=argparse.ArgumentParser();parser.add_argument('--device',choices=['CPU','GPU'],default='CPU');parser.add_argument('--baseline',type=Path,default=Path('runs/final'));parser.add_argument('--output',type=Path,default=Path('runs/retrained_v6'));args=parser.parse_args();assert not args.output.exists(),'Use a fresh output directory';start=time.time()
oof=Path('v4/v3_oof_scores.npy')
if not oof.exists():subprocess.run([sys.executable,'build_v3_oof.py'],cwd='v4',check=True)
b,a=load_inputs('train');e,f=rich_features(b,a);hard=hard_mask(b);g=read_jsonl(DATA/'gsm8k_train.jsonl');y=np.array([[parse_answer(c['text'])is not None and parse_answer(c['text'])==parse_answer(q['answer'])for c in row['candidates']]for row,q in zip(b,g)],dtype='float32');pca=PCA(64,random_state=4100).fit((e-e.mean(1,keepdims=True)).reshape(-1,1024))
def design(bank,e,f,base):
 pc=pca.transform((e-e.mean(1,keepdims=True)).reshape(-1,1024)).reshape(-1,4,64);return np.round(np.concatenate([baseline_features(bank,base),candidate_profiles(bank),f,f-f.mean(1,keepdims=True),pc],-1),4)
x=design(b,e,f,np.load(oof));weights=np.where(y[hard].sum(1)==1,3.,1.);pool=Pool(data=x[hard].reshape(-1,x.shape[-1]),label=y[hard].flatten(),baseline=np.zeros(hard.sum()*4),group_id=np.repeat(np.arange(hard.sum()),4),group_weight=np.repeat(weights,4),thread_count=4);kwargs=dict(iterations=800,depth=5,learning_rate=.025,l2_leaf_reg=30,thread_count=4,random_seed=4103,border_count=32,loss_function='PairLogit',allow_writing_files=False,task_type=args.device)
if args.device=='GPU':kwargs['devices']='0'
model=CatBoostRanker(**kwargs);model.fit(pool,verbose=200);model.shrink(125);vb,va=load_inputs('validation');ve,vf=rich_features(vb,va);vx=design(vb,ve,vf,base_scores(vb,va,args.baseline));lp=model.predict(vx.reshape(-1,vx.shape[-1]),thread_count=4).reshape(-1,4);valid=np.array([[parse_answer(c['text'])is not None for c in row['candidates']]for row in vb]);vh=hard_mask(vb);scale=max(float(np.mean([s[v].std()for s,v,h in zip(lp,valid,vh)if h])),.01);p=args.output;p.mkdir(parents=True)
for item in args.baseline.iterdir():
 if item.name=='semantic_residual':continue
 if item.is_dir():shutil.copytree(item,p/item.name)
 else:shutil.copy2(item,p/item.name)
r=p/'semantic_residual';r.mkdir();np.savez(r/'pca.npz',mean=pca.mean_,components=pca.components_);model.save_model(str(r/'semantic_residual4103.cbm'));cfg=json.loads((p/'config.json').read_text());cfg['semantic_residual']=dict(model='semantic_residual4103.cbm',weight=.25,scale=scale);(p/'config.json').write_text(json.dumps(cfg,indent=2));(p.parent/(p.name+'-training.json')).write_text(json.dumps(dict(seed=4103,trees=125,device=args.device,seconds=time.time()-start,scale=scale),indent=2));print('Saved',p)
