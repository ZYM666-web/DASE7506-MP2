import json,time
from pathlib import Path
import numpy as np
from common import load_inputs,read_jsonl,DATA,parse_answer
from rich_features import hard_mask
from submission import aggregate
from verify_arithmetic import arithmetic_evidence
p=Path('runs/v2');start=time.time();bs=[];ys=[];hs=[];ff=[]
for split in ['train','validation']:
 b,_=load_inputs(split);bs.append(b);hs.append(hard_mask(b));ff.append(arithmetic_evidence(b));g=read_jsonl(DATA/f'gsm8k_{split}.jsonl');ys.append(np.array([[parse_answer(c['text']) is not None and parse_answer(c['text'])==parse_answer(q['answer'])for c in r['candidates']]for r,q in zip(b,g)]));print('ready',split,flush=True)
np.savez(p/'verification_features.npz',train=ff[0],validation=ff[1]);
# Inspect numerical repair precision on training, before choosing development settings.
for col in [5,7]:
 triggered=(ff[0][:,:,col]>0).any(1)&hs[0];pp=ff[0][:,:,col].argmax(1);v=ys[0][np.arange(len(pp)),pp];print('TRAIN REPAIR',col,'n',triggered.sum(),'precision',v[triggered].mean(),flush=True)
search=json.loads((p/'ensemble_search.json').read_text());chosen=search['results'][0];base=0
for family,w in chosen['weights'].items():
 seeds=[400,401,402] if family.startswith('delta') else [300,301,302];base=base+w*np.mean([np.load(p/f'{family}{s}_validation.npy')for s in seeds],0)/search['scales'][family]
base=aggregate(base,bs[1],.5);results=[]
for penalty in [0,.1,.25,.5,1,2]:
 for support in [0,.25,.5,1,2,4]:
  evidence=-penalty*ff[1][:,:,1]+support*(ff[1][:,:,5]-.5*ff[1][:,:,6]);sc=aggregate(base+evidence,bs[1],.5);pp=sc.argmax(1);v=ys[1][np.arange(len(pp)),pp];results.append(dict(penalty=penalty,support=support,hard=float(v[hs[1]].mean()),all=float(v.mean())))
results.sort(key=lambda x:x['hard'],reverse=True);print('TOP',results[:10]);(p/'verification_search.json').write_text(json.dumps(dict(results=results,seconds=time.time()-start),indent=2))
