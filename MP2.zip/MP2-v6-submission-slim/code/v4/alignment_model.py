import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import torch
from torch import nn
class AlignmentNet(nn.Module):
 def __init__(self,words,features):
  super().__init__();self.question=nn.Sequential(nn.Linear(words,64),nn.LayerNorm(64),nn.GELU(),nn.Dropout(.35));self.operation=nn.Linear(64,32);self.encoder=nn.Sequential(nn.Linear(features,128),nn.GELU(),nn.Dropout(.3));self.cross=nn.Linear(64,64);self.head=nn.Sequential(nn.Linear(576,96),nn.GELU(),nn.Dropout(.3),nn.Linear(96,1))
 def forward(self,x,q,cprofile):
  h=self.encoder(x);m=h.double().mean(1,keepdim=True).float().expand_as(h);qq=self.question(q);op=self.operation(qq);q4=qq[:,None,:].expand(-1,4,-1);op4=op[:,None,:].expand(-1,4,-1);interaction=h[:,:,:64]*self.cross(q4);z=torch.cat([h,h-m,m,q4,interaction,cprofile*op4,cprofile-op4],-1);return self.head(z).squeeze(-1),op
