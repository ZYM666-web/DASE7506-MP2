import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import numpy as np,json
from pathlib import Path
from common import load_inputs,read_jsonl,DATA,parse_answer
from rich_features import hard_mask
out={}
for split in ['train','validation']:
 b,_=load_inputs(split);g=read_jsonl(DATA/f'gsm8k_{split}.jsonl');v=np.array([[parse_answer(c['text'])is not None for c in r['candidates']]for r in b]);y=np.array([[parse_answer(c['text'])is not None and parse_answer(c['text'])==parse_answer(q['answer'])for c in r['candidates']]for r,q in zip(b,g)]);h=hard_mask(b);single=h&(y.sum(1)==1);out[split]=dict(correct_rate=y.mean(0).tolist(),valid_rate=v.mean(0).tolist(),unique_correct_position=y[single].mean(0).tolist(),single_n=int(single.sum()))
print(json.dumps(out,indent=2));Path('position_analysis.json').write_text(json.dumps(out,indent=2))
