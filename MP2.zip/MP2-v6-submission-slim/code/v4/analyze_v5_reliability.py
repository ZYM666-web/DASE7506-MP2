import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import json,math
from pathlib import Path
import numpy as np
from common import load_inputs,read_jsonl,DATA,parse_answer
from rich_features import hard_mask
b,_=load_inputs('validation');g=read_jsonl(DATA/'gsm8k_validation.jsonl');y=np.array([[parse_answer(c['text'])is not None and parse_answer(c['text'])==parse_answer(q['answer'])for c in r['candidates']]for r,q in zip(b,g)]);h=hard_mask(b);single=h&(y.sum(1)==1);old=np.load('alignment_selected_validation_scores.npy');new=np.load('complementary_validation_scores.npy');oldcorrect=y[np.arange(len(y)),old.argmax(1)];correct=y[np.arange(len(y)),new.argmax(1)];margins=[]
for row,s in zip(b,new):
 groups={}
 for c,sc in zip(row['candidates'],s):
  answer=parse_answer(c['text'])
  if answer is not None:groups[answer]=max(float(sc),groups.get(answer,-float('inf')))
 vals=sorted(groups.values(),reverse=True);margins.append(vals[0]-vals[1]if len(vals)>1 else float('nan'))
margins=np.array(margins);order=np.where(h)[0][np.argsort(margins[h])];bins=[]
def wilson(k,n):
 z=1.96;p=k/n;den=1+z*z/n;center=(p+z*z/(2*n))/den;radius=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/den;return [center-radius,center+radius]
for j,ids in enumerate(np.array_split(order,4)):
 k=int(correct[ids].sum());bins.append(dict(quartile=j+1,n=len(ids),correct=k,accuracy=k/len(ids),margin_min=float(margins[ids].min()),margin_max=float(margins[ids].max()),wilson95=wilson(k,len(ids))))
rng=np.random.default_rng(4300);comparisons={}
for name,mask in [('hard',h),('singleton',single)]:
 diff=correct[mask].astype(float)-oldcorrect[mask];boots=diff[rng.integers(0,len(diff),(10000,len(diff)))].mean(1);comparisons[name]=dict(n=int(mask.sum()),old_correct=int(oldcorrect[mask].sum()),new_correct=int(correct[mask].sum()),corrected=int(((~oldcorrect)&correct&mask).sum()),harmed=int((oldcorrect&(~correct)&mask).sum()),delta=float(diff.mean()),bootstrap95=np.quantile(boots,[.025,.975]).tolist())
out=dict(confidence='Distinct valid answer group max-logit margin; descriptive, not calibrated probability.',hard_margin_quartiles=bins,paired_validation_changes=comparisons,post_selection_limitation='Intervals condition on the selected models and do not correct for extensive validation search.');Path('reliability_v5.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
