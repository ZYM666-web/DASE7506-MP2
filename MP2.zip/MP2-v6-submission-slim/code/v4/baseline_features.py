import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import numpy as np
from common import parse_answer

def baseline_features(bank,scores):
 out=np.zeros((*scores.shape,2),dtype=np.float32)
 for j,r in enumerate(bank):
  values=[parse_answer(c['text'])for c in r['candidates']];valid=np.array([v is not None for v in values]);s=scores[j,valid];out[j,:,0]=-5
  if len(s):out[j,valid,0]=(s-s.mean())/max(float(s.std()),.05)
  groups={}
  for value,score in zip(values,scores[j]):
   if value is not None:groups[value]=max(float(score),groups.get(value,-1e9))
  ranked=sorted(groups.values(),reverse=True);gap=min(ranked[0]-ranked[1],20)if len(ranked)>1 else 0.;out[j,:,1]=gap
 return out
