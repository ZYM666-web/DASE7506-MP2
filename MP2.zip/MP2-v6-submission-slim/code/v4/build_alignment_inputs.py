import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import numpy as np
from common import load_inputs,read_jsonl,DATA
from operation_profiles import candidate_profiles,reference_profiles
from base_scores_v4 import predict as base_scores
c=[]
for split in ['train','validation']:
 b,a=load_inputs(split);c.append(candidate_profiles(b))
 if split=='validation':np.save('base_validation_scores.npy',base_scores(b,a,Path('../runs/final')))
y,valid=reference_profiles(read_jsonl(DATA/'gsm8k_train.jsonl'));np.savez('gold_profiles.npz',profiles=y,valid=valid);np.savez('candidate_profiles.npz',train=c[0],validation=c[1])
