import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import json,re
from pathlib import Path
from fractions import Fraction
import numpy as np
from common import load_inputs,read_jsonl,DATA,parse_answer
from programs import question_values,NUMBER,WORDNUM,reference_programs,size
from sequence_data import prefix
b,a=load_inputs('train');g=read_jsonl(DATA/'gsm8k_train.jsonl');data=np.load('sequence_data.npz');wv=json.loads(Path('sequence_bundle/vocabulary.json').read_text());pv=json.loads(Path('sequence_bundle/program_vocabulary.json').read_text());joined=dict(wv);mapping=[]
for token,i in sorted(pv.items(),key=lambda z:z[1]):
 if token=='<pad>':idx=0
 elif token.startswith('q')and token[1:].isdigit():idx=wv.get('num'+token[1:],1)
 else:
  name='PROGRAM:'+token
  if name not in joined:joined[name]=len(joined)
  idx=joined[name]
 mapping.append(idx)
extra=len(joined);joined['INTERMEDIATE_NUMBER']=extra;mask_id=len(joined);joined['MASK_WORD']=mask_id;mapping=np.array(mapping,dtype=np.int64);word_pattern=re.compile(r"num\d+|intermediate_number|[a-z]+(?:'[a-z]+)?|[%$+*/-]")
def encode_body(text,question):
 values,_=question_values(question);t=text.lower().replace('\\times','*').replace('\\cdot','*').replace('×','*').replace('÷','/').replace('**','');t=re.sub(r'^\s*[-*]\s+','',t,flags=re.M);t=re.sub(r'\b('+'|'.join(WORDNUM)+r')\b',lambda m:WORDNUM[m[0]],t)
 def num(m):
  try:v=float(Fraction(m[0].replace(',','')))
  except(ValueError,ZeroDivisionError):return ' intermediate_number '
  for i,n in enumerate(values):
   if abs(n-v)<1e-7*(1+abs(v)):return ' num'+str(i)+' '
  return ' intermediate_number '
 t=NUMBER.sub(num,t);out=[]
 for word in word_pattern.findall(t):
  if word=='intermediate_number':idx=extra
  elif word in ['+','-','*','/']:idx=joined.get('PROGRAM:'+word,1)
  else:idx=wv.get(word,1)
  out.append(idx)
 return out
rows=[];progs=[];target_idx=[];targets=[]
for j,(row,ref)in enumerate(zip(b,g)):
 q=row['question'];ys=[parse_answer(c['text'])is not None and parse_answer(c['text'])==parse_answer(ref['answer'])for c in row['candidates']]
 docs=[(c['text'],data['train_programs'][j,k],a['embeddings'][j,k])for k,c in enumerate(row['candidates'])]
 ps=reference_programs(q,ref['answer'],float(Fraction(parse_answer(ref['answer']))));tree=max((json.loads(s)for s in ps),key=size,default=None);gp=[1]+[pv.get(t,3)for t in prefix(tree)]+[2]if tree is not None else[];gp=np.array(gp[:42]+[0]*max(0,42-len(gp)),dtype=np.int64);docs.append((ref['answer'],gp,a['embeddings'][j,ys].mean(0)))
 for body,prog,target in docs:
  ids=encode_body(q+' '+body,q);starts=[0]
  if len(ids)>128:starts.append(max(0,len(ids)-128))
  if len(ids)>300:starts.append((len(ids)-128)//2)
  ti=len(targets);targets.append(target)
  for lo in starts:
   chunk=ids[lo:lo+128]
   if not chunk:continue
   rows.append(chunk+[0]*(128-len(chunk)));progs.append(mapping[prog]);target_idx.append(ti)
 if j%1000==0:print('CORPUS',j,flush=True)
targets=np.array(targets,dtype=np.float32);mean=targets.mean(0);std=targets.std(0).clip(.1);np.savez('mlm_data.npz',words=np.array(rows,dtype=np.int32),programs=np.array(progs,dtype=np.int32),target_idx=np.array(target_idx,dtype=np.int32),targets=(targets-mean)/std);p=Path('mlm_bundle');p.mkdir(exist_ok=True);np.savez(p/'teacher_stats.npz',mean=mean,std=std);(p/'vocabulary.json').write_text(json.dumps(wv));(p/'program_vocabulary.json').write_text(json.dumps(pv));(p/'joined.json').write_text(json.dumps(joined));(p/'size.json').write_text(json.dumps(dict(words=len(joined),mask_id=mask_id,extra_id=extra,program_mapping=mapping.tolist(),segments=len(rows),documents=len(targets))));print('CORPUS COMPLETE',len(rows),'segments',len(targets),'docs',flush=True)
