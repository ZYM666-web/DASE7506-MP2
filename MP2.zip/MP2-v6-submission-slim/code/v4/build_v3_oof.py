import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='4'
import json,time
from pathlib import Path
import numpy as np
from sklearn.model_selection import KFold
from catboost import CatBoostRanker,Pool
from common import load_inputs,read_jsonl,DATA,parse_answer
from rich_features import rich_features,hard_mask
from submission import aggregate
from verify_arithmetic import arithmetic_evidence
b,a=load_inputs('train');e,f=rich_features(b,a);p=np.load('../runs/v2/oof_stack_train.npy');p-=p.mean(1,keepdims=True);p/=p.std(1,keepdims=True).clip(.05);vf=arithmetic_evidence(b);x=np.round(np.concatenate([p[:,:,None],vf,f,f-f.mean(1,keepdims=True)],-1),4);g=read_jsonl(DATA/'gsm8k_train.jsonl');y=np.array([[parse_answer(c['text'])is not None and parse_answer(c['text'])==parse_answer(q['answer'])for c in r['candidates']]for r,q in zip(b,g)],dtype=np.float32);h=hard_mask(b);out=np.zeros_like(p,dtype=np.float64);start=time.time()
for fold,(tr,ho)in enumerate(KFold(4,shuffle=True,random_state=3200).split(np.arange(len(b)))):
 tr=tr[h[tr]];pool=Pool(data=x[tr].reshape(-1,x.shape[-1]),label=y[tr].flatten(),group_id=np.repeat(np.arange(len(tr)),4),thread_count=4);res=np.zeros((len(ho),4))
 for seed,depth,trees in [(1700,4,200),(1701,5,175)]:
  m=CatBoostRanker(iterations=trees,depth=depth,learning_rate=.025,l2_leaf_reg=20,thread_count=4,random_seed=seed,border_count=32,loss_function='YetiRank',allow_writing_files=False);m.fit(pool,verbose=False);res+=m.predict(x[ho].reshape(-1,x.shape[-1]),thread_count=4).reshape(-1,4)/2
 rows=[b[i]for i in ho];out[ho]=aggregate(p[ho]+2*res,rows,.5)/2.58425206355757+.5*(vf[ho,:,5]-.5*vf[ho,:,6]);print('OOF V3 fold',fold,flush=True)
np.save('v3_oof_scores.npy',out);pred=out.argmax(1);v=y[np.arange(len(pred)),pred];Path('v3_oof_records.json').write_text(json.dumps(dict(seed=3200,folds=4,hard=float(v[h].mean()),all=float(v.mean()),seconds=time.time()-start),indent=2));print('OOF done',float(v[h].mean()))
