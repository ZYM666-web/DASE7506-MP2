import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import json
from pathlib import Path
import numpy as np
from common import load_inputs,read_jsonl,DATA,parse_answer
from rich_features import hard_mask
from submission import aggregate
b,_=load_inputs('validation');g=read_jsonl(DATA/'gsm8k_validation.jsonl');y=np.array([[parse_answer(c['text'])is not None and parse_answer(c['text'])==parse_answer(q['answer'])for c in r['candidates']]for r,q in zip(b,g)]);h=hard_mask(b);single=h&(y.sum(1)==1);valid=np.array([[parse_answer(c['text'])is not None for c in r['candidates']]for r in b]);base=np.load('complementary_validation_scores.npy');p=Path('../runs/v2');results=[]
families={'richpair':['pair'+str(s)for s in [300,301,302]],'richbce':['bce'+str(s)for s in [300,301,302]],'deltauniform':['delta_uniform'+str(s)for s in [400,401]],'deltabce':['delta_bce'+str(s)for s in [400,401]],'attentionpair':['attention_pair'+str(s)for s in [1400,1401]],'attentionuniform':['attention_uniform'+str(s)for s in [1400,1401]]}
for family,names in families.items():
 if not all((p/(n+'_validation.npy')).exists()for n in names):continue
 lp=np.mean([np.load(p/(n+'_validation.npy'))for n in names],0);scale=max(float(np.mean([s[v].std()for s,v,hh in zip(lp,valid,h)if hh])),.01);sc=aggregate(lp/scale,b,.5);rs=[]
 for w in [0,.1,.25,.5,1,2]:
  v=y[np.arange(len(y)),(base+w*sc).argmax(1)];rs.append(dict(weight=w,hard=float(v[h].mean()),singleton=float(v[single].mean()),all=float(v.mean())))
 best=max([r for r in rs if r['hard']>=319/355-1e-6],key=lambda r:(r['singleton'],r['hard'],r['all'],-r['weight']));results.append(dict(family=family,names=names,scale=scale,**best));print(results[-1],flush=True)
Path('legacy_complements.json').write_text(json.dumps(results,indent=2))
