import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import torch
from torch import nn
class CompositionalNet(nn.Module):
 def __init__(self,words,program_features):
  super().__init__();self.text=nn.Sequential(nn.Linear(words,96),nn.GELU(),nn.Dropout(.3));self.embed=nn.Sequential(nn.Linear(1024,64),nn.GELU(),nn.Dropout(.3));self.question=nn.Sequential(nn.Linear(160,64),nn.GELU(),nn.Linear(64,64));self.program=nn.Linear(program_features,64,bias=False);self.bias=nn.Linear(program_features,1,bias=False);self.other=nn.Linear(64,1)
 def forward(self,q,e,pf,prior):
  h=self.question(torch.cat([self.text(q),self.embed(e)],-1));p=self.program(pf);score=h@p.T/8+self.bias(pf).T+.3*prior
  return torch.cat([score,self.other(h)],1)
