import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import torch
from torch import nn
class CrossProgramVerifier(nn.Module):
 def __init__(self,words,features):
  super().__init__();self.word=nn.Embedding(words,64,padding_idx=0);self.position=nn.Embedding(171,64);self.kind=nn.Embedding(3,64);self.cls=nn.Linear(features,64);layer=nn.TransformerEncoderLayer(64,4,128,dropout=.3,activation='gelu',batch_first=True,norm_first=True);self.context=nn.TransformerEncoder(layer,2,enable_nested_tensor=False);self.scalar=nn.Sequential(nn.Linear(features,128),nn.GELU(),nn.Dropout(.35));self.head=nn.Sequential(nn.Linear(480,64),nn.GELU(),nn.Dropout(.3),nn.Linear(64,1));self.aux=nn.Linear(64,32)
 def forward(self,x,q,programs,profiles):
  n=x.shape[0];xx=x.reshape(-1,x.shape[-1]);qq=q[:,None,:].expand(-1,4,-1).reshape(n*4,-1);pp=programs.reshape(n*4,-1);ids=torch.cat([qq,pp],1);h=torch.cat([self.cls(xx)[:,None,:],self.word(ids)],1);positions=torch.arange(h.shape[1],device=x.device);types=torch.cat([torch.full((1,),2,dtype=torch.long,device=x.device),torch.zeros(128,dtype=torch.long,device=x.device),torch.ones(42,dtype=torch.long,device=x.device)]);h=h+self.position(positions)[None]+self.kind(types)[None];mask=torch.cat([torch.zeros((n*4,1),dtype=torch.bool,device=x.device),ids==0],1);cls=self.context(h,src_key_padding_mask=mask)[:,0].reshape(n,4,64);scalar=self.scalar(x);mean=scalar.double().mean(1,keepdim=True).float().expand_as(scalar);z=torch.cat([scalar,scalar-mean,mean,cls,profiles],-1);return self.head(z).squeeze(-1),self.aux(cls).mean(1)
