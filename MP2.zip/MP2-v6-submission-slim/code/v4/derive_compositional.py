import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import json
from collections import Counter
from pathlib import Path
import numpy as np
from programs import evaluate_bank,serial
from common import load_inputs
rows=json.loads(Path('reference_program_targets.json').read_text());counts=Counter(s for row in rows for s in row);items=[(s,n)for s,n in counts.most_common()if json.loads(s)[0]not in['q','c']];programs=[json.loads(s)for s,n in items];counts=np.array([n for s,n in items],dtype=np.float32);vocab={};rows=[]
def feats(pr):
 out=Counter()
 def walk(p,path):
  token=p[0]if p[0]not in['q','c']else p[0]+str(p[1]);out['count:'+token]+=1;out['path:'+path+':'+token]+=1
  if p[0]not in['q','c']:
   walk(p[1],(path+'L')[-4:]);walk(p[2],(path+'R')[-4:])
 walk(pr,'ROOT');return out
features=[feats(pr)for pr in programs]
for f in features:
 for k in f:
  if k not in vocab:vocab[k]=len(vocab)
pf=np.zeros((len(programs),len(vocab)),dtype=np.float32)
for i,f in enumerate(features):
 for k,v in f.items():pf[i,vocab[k]]=np.log1p(v)
pf/=np.linalg.norm(pf,axis=1,keepdims=True);Path('all_programs.json').write_text(json.dumps(programs,separators=(',',':')));np.savez('program_features.npz',features=pf,counts=counts);Path('program_feature_names.json').write_text(json.dumps(vocab));print('programs',len(programs),'feature dims',len(vocab))
for split in ['train','validation']:
 b,_=load_inputs(split);np.save(f'{split}_allprogram_values.npy',evaluate_bank(programs,b))
