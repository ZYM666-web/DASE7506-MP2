import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import json
from collections import Counter
from pathlib import Path
from fractions import Fraction
from common import read_jsonl,DATA,parse_answer,load_inputs
from programs import reference_programs,evaluate_bank
import numpy as np
train=read_jsonl(DATA/'gsm8k_train.jsonl');targets=[reference_programs(r['question'],r['answer'],float(Fraction(parse_answer(r['answer']))))for r in train];count=Counter(p for row in targets for p in row);programs=[json.loads(p)for p,n in count.most_common()if n>=3 and p.startswith('[\"q\"')is False and p.startswith('[\"c\"')is False];Path('programs.json').write_text(json.dumps(programs,separators=(',',':')));Path('reference_program_targets.json').write_text(json.dumps([list(t)for t in targets]));print('DERIVED',sum(bool(t)for t in targets),len(count),'VOCAB',len(programs),'retained targets',sum(any(count[p]>=3 for p in t)for t in targets));print('TOP',count.most_common(15));
for split in ['train','validation']:
 b,_=load_inputs(split);v=evaluate_bank(programs,b);g=read_jsonl(DATA/f'gsm8k_{split}.jsonl');gold=np.array([float(Fraction(parse_answer(q['answer'])))for q in g]);match=(abs(v-gold[:,None])<1e-5*(1+abs(gold[:,None])))&np.isfinite(v);print(split,'coverage',match.any(1).mean(),'n',len(b));np.save(f'{split}_program_values.npy',v)
