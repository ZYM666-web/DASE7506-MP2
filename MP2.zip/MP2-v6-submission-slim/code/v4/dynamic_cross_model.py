import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import torch
from torch import nn
class DynamicCrossVerifier(nn.Module):
 def __init__(self,words,features,dimension=96):
  super().__init__();d=dimension;self.word=nn.Embedding(words,d,padding_idx=0);self.position=nn.Embedding(171,d);self.kind=nn.Embedding(3,d);self.cls=nn.Linear(features,d);layer=nn.TransformerEncoderLayer(d,4,d*2,dropout=.3,activation='gelu',batch_first=True,norm_first=True);self.context=nn.TransformerEncoder(layer,2,enable_nested_tensor=False);self.scalar=nn.Sequential(nn.Linear(features,128),nn.GELU(),nn.Dropout(.35));self.head=nn.Sequential(nn.Linear(384+d+32,64),nn.GELU(),nn.Dropout(.3),nn.Linear(64,1));self.aux=nn.Linear(d,32)
 def forward(self,x,q,programs,profiles):
  n=x.shape[0];qlen=max(1,int((q!=0).sum(1).max().item()));plen=max(1,int((programs!=0).sum(2).max().item()));xx=x.reshape(-1,x.shape[-1]);qq=q[:,:qlen,None].squeeze(-1)[:,None,:].expand(-1,4,-1).reshape(n*4,-1);pp=programs[:,:,:plen].reshape(n*4,-1);ids=torch.cat([qq,pp],1);h=torch.cat([self.cls(xx)[:,None,:],self.word(ids)],1);pos=torch.cat([torch.zeros(1,dtype=torch.long,device=x.device),torch.arange(1,qlen+1,device=x.device),torch.arange(129,129+plen,device=x.device)]);types=torch.cat([torch.full((1,),2,dtype=torch.long,device=x.device),torch.zeros(qlen,dtype=torch.long,device=x.device),torch.ones(plen,dtype=torch.long,device=x.device)]);h=h+self.position(pos)[None]+self.kind(types)[None];mask=torch.cat([torch.zeros((n*4,1),dtype=torch.bool,device=x.device),ids==0],1);cls=self.context(h,src_key_padding_mask=mask)[:,0].reshape(n,4,-1);scalar=self.scalar(x);mean=scalar.double().mean(1,keepdim=True).float().expand_as(scalar);z=torch.cat([scalar,scalar-mean,mean,cls,profiles],-1);return self.head(z).squeeze(-1),self.aux(cls).mean(1)
