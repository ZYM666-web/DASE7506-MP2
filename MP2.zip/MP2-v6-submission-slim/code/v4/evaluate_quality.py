import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import json
from pathlib import Path
import numpy as np
from common import load_inputs,read_jsonl,DATA,parse_answer
from rich_features import hard_mask
from submission import aggregate
b,_=load_inputs('validation');g=read_jsonl(DATA/'gsm8k_validation.jsonl');y=np.array([[parse_answer(c['text'])is not None and parse_answer(c['text'])==parse_answer(q['answer'])for c in r['candidates']]for r,q in zip(b,g)]);h=hard_mask(b);single=h&(y.sum(1)==1);valid=np.array([[parse_answer(c['text'])is not None for c in r['candidates']]for r in b]);base=np.load('alignment_selected_validation_scores.npy');lp=np.mean([np.load(f'quality{s}_validation.npy')for s in [3500,3501,3502,3503]],0);scale=float(np.mean([row[v].std()for row,v,hard in zip(lp,valid,h)if hard]));quality=aggregate(lp/max(scale,.01),b,.5);alone=y[np.arange(len(y)),quality.argmax(1)];print('QUALITY ALONE',float(alone[h].mean()),float(alone[single].mean()),flush=True);results=[];floor=320/355-1/355-1e-6
for w in [0,.1,.25,.5,1,2,4]:
 pp=(base+w*quality).argmax(1);v=y[np.arange(len(y)),pp];results.append(dict(weight=w,hard=float(v[h].mean()),singleton=float(v[single].mean()),all=float(v.mean()),eligible=float(v[h].mean())>=floor))
print('QUALITY FUSION',json.dumps(results,indent=2));best=max([r for r in results if r['eligible']],key=lambda r:(r['singleton'],r['hard'],r['all']));out=dict(results=results,scale=scale,best=best,standalone_hard=float(alone[h].mean()),standalone_singleton=float(alone[single].mean()));Path('quality_validation.json').write_text(json.dumps(out,indent=2));np.save('quality_ensemble_validation.npy',quality)
