import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import json,time
from pathlib import Path
import numpy as np
from common import load_inputs,read_jsonl,DATA,parse_answer
from rich_features import hard_mask
from semantic_checks import semantic_warnings
from submission import aggregate
start=time.time();bs=[];ys=[];xx=[];hs=[]
for split in ['train','validation']:
 b,_=load_inputs(split);bs.append(b);hs.append(hard_mask(b));x=semantic_warnings(b);xx.append(x);g=read_jsonl(DATA/f'gsm8k_{split}.jsonl');ys.append(np.array([[parse_answer(c['text'])is not None and parse_answer(c['text'])==parse_answer(q['answer'])for c in r['candidates']]for r,q in zip(b,g)]));print('semantic ready',split,flush=True)
valid=np.array([[parse_answer(c['text'])is not None for c in r['candidates']]for r in bs[0]]);prior=float((~ys[0])[hs[0]][valid[hs[0]]].mean());stats=[];coef=[]
for k in range(5):
 mask=(xx[0][:,:,k]>0)&valid&hs[0][:,None];n=int(mask.sum());wrong=int((~ys[0])[mask].sum());prob=(wrong+1)/(n+2);ll=np.log(prob/(1-prob))-np.log(prior/(1-prior));weight=float(max(0,ll))if n>=20 and prob>=.75 else 0.;coef.append(weight);stats.append(dict(feature=k,n=n,wrong=wrong,probability_wrong=prob,coefficient=weight))
coef=np.array(coef);evidence=xx[1]@coef;base=np.load('alignment_selected_validation_scores.npy');single=hs[1]&(ys[1].sum(1)==1);floor=319/355-1e-6;results=[]
for pooling in [0,.5,1]:
 pooled=aggregate(evidence,bs[1],pooling);pooled[pooled<-1e8]=0
 for weight in [0,.1,.25,.5,1,2,4]:
  pp=(base-weight*pooled).argmax(1);v=ys[1][np.arange(len(pp)),pp];results.append(dict(pooling=pooling,weight=weight,hard=float(v[hs[1]].mean()),singleton=float(v[single].mean()),all=float(v.mean()),eligible=float(v[hs[1]].mean())>=floor))
best=max([r for r in results if r['eligible']],key=lambda r:(r['singleton'],r['hard'],r['all']));print('TRAIN',stats);print('BEST',best);Path('semantic_records.json').write_text(json.dumps(dict(statistics=stats,coefficient=coef.tolist(),results=results,best=best,seconds=time.time()-start),indent=2));np.savez('semantic_features.npz',train=xx[0],validation=xx[1])
