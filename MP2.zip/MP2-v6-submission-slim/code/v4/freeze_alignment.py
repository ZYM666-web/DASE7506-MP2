import argparse,json,shutil,hashlib
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=Path('../runs/retrained_v4'));args=parser.parse_args();p=args.output;p.mkdir(parents=True,exist_ok=False)
base=Path('../runs/final');cfg=json.loads((base/'config.json').read_text());record=json.loads(Path('alignment_search.json').read_text());chosen=record['results'][0]
for f in base.iterdir():
 if f.is_file()and f.name!='config.json':shutil.copy2(f,p/f.name)
a=p/'alignment';a.mkdir()
for name in ['stats.npz','vocabulary.json']+[n+'.pt'for n in chosen['models']]:shutil.copy2(Path('alignment_bundle')/name,a/name)
cfg['alignment']=dict(models=[n+'.pt'for n in chosen['models']],scales=[record['scales'][n]for n in chosen['models']],weight=chosen['weight']);(p/'config.json').write_text(json.dumps(cfg,indent=2));files={f.relative_to(p).as_posix():dict(bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest())for f in p.rglob('*')if f.is_file()};size=sum(v['bytes']for v in files.values());assert size<16*2**20;(p.parent/(p.name+'-freeze.json')).write_text(json.dumps(dict(files=files,asset_bytes=size,validation=chosen),indent=2));print(p)
