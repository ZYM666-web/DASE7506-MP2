import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
"""Reference-supervised operation profiles, not answer lookup tables."""
import json,ast
from fractions import Fraction
import numpy as np
from common import parse_answer
from programs import reference_programs,question_values,size
from verify_arithmetic import eqs
OPS=['+','-','*','/'];CONSTS=[.5,1.,2.,3.,7.,12.,60.,100.]
def profile(program):
 p=np.zeros(32,dtype=np.float32)
 def visit(node):
  if node[0]=='q':p[4+node[1]]=1
  elif node[0]=='c':
   if node[1]in CONSTS:p[16+CONSTS.index(node[1])]=1
  else:p[OPS.index(node[0])]+=.2;visit(node[1]);visit(node[2])
 visit(program)
 if program[0]in OPS:p[24+OPS.index(program[0])]=1
 p[28]=min(size(program)/20,3);p[29]=1;p[30]=sum(p[4:16])/12;p[31]=sum(p[:4])
 return p

def reference_profiles(train):
 out=[];valid=[]
 for row in train:
  a=parse_answer(row['answer']);ps=reference_programs(row['question'],row['answer'],float(Fraction(a)));trees=[json.loads(s)for s in ps]
  if trees:out.append(np.mean([profile(t)for t in trees],0));valid.append(True)
  else:out.append(np.zeros(32,dtype=np.float32));valid.append(False)
 return np.array(out),np.array(valid)

def candidate_profiles(bank):
 out=[]
 for row in bank:
  fs=[]
  for c in row['candidates']:
   a=parse_answer(c['text']);pairs=eqs(c['text']);pseudo='\n'.join('<<'+left+'='+str(value)+'>>'for left,right,_,value in pairs);trees=[]
   if a is not None:
    trees=[json.loads(s)for s in reference_programs(row['question'],pseudo,float(Fraction(a)))]
   if trees:p=np.mean([profile(t)for t in trees],0)
   else:
    p=np.zeros(32,dtype=np.float32)
    # A locally visible final operation is useful even if its earlier provenance
    # cannot be reconstructed; mark this as partial evidence.
    if a is not None:
     target=float(Fraction(a));qvalues,_=question_values(row['question'])
     for left,right,value,result in reversed(pairs):
      if abs(result-target)>1e-5*(1+abs(target)):continue
      try:
       node=ast.parse(left,mode='eval').body
       def walk(n):
        if isinstance(n,ast.BinOp):
         op={ast.Add:'+',ast.Sub:'-',ast.Mult:'*',ast.Div:'/'}[type(n.op)]
         p[OPS.index(op)]+=.2;walk(n.left);walk(n.right)
        elif isinstance(n,ast.Constant)and type(n.value)in[int,float]:
         v=float(n.value)
         for j,qv in enumerate(qvalues):
          if abs(qv-v)<1e-7*(1+abs(v)):p[4+j]=1;break
         if v in CONSTS:p[16+CONSTS.index(v)]=1
       walk(node)
       if isinstance(node,ast.BinOp):
        op={ast.Add:'+',ast.Sub:'-',ast.Mult:'*',ast.Div:'/'}[type(node.op)]
        p[24+OPS.index(op)]=1;p[29]=.5;p[30]=sum(p[4:16])/12;p[31]=sum(p[:4])
        break
      except (ValueError,SyntaxError,KeyError):continue
   fs.append(p)
  out.append(fs)
 return np.array(out)

def meta_features(expected,candidates):
 pred=np.broadcast_to(expected[:,None,:],candidates.shape);diff=candidates-pred;root=(pred[:,:,24:28]*candidates[:,:,24:28]).sum(-1,keepdims=True);qoverlap=(pred[:,:,4:16]*candidates[:,:,4:16]).sum(-1,keepdims=True)
 return np.concatenate([pred,candidates,diff,abs(diff),root,qoverlap],-1).astype(np.float32)

