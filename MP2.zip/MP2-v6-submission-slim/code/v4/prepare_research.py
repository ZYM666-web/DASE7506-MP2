"""Recreate training/development caches from the frozen V6 components."""
import sys,os
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[k]='4'
import numpy as np
from common import load_inputs,read_jsonl,DATA
from operation_profiles import candidate_profiles,reference_profiles
from base_scores_v4 import predict as v3
from scores_v4 import predict as v4
from scores_v5 import predict as v5
cp={}
for split in ['train','validation']:
 b,a=load_inputs(split);cp[split]=candidate_profiles(b)
 if split=='validation':
  for name,method in [('base_validation_scores.npy',v3),('alignment_selected_validation_scores.npy',v4),('complementary_validation_scores.npy',v5)]:np.save(name,method(b,a,Path('../runs/final')))
np.savez('candidate_profiles.npz',**cp);gold,valid=reference_profiles(read_jsonl(DATA/'gsm8k_train.jsonl'));np.savez('gold_profiles.npz',profiles=gold,valid=valid);print('Rebuilt train/validation research inputs; no test data read.')
