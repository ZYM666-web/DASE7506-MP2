import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import numpy as np,json
from pathlib import Path
from common import load_inputs
from submission import aggregate
b,_=load_inputs('validation');base=np.load('base_validation_scores.npy');s=json.loads(Path('alignment_search.json').read_text());best=s['results'][0];a=np.mean([np.load(n+'_validation.npy')/s['scales'][n]for n in best['models']],0);np.save('alignment_selected_validation_scores.npy',base+best['weight']*aggregate(a,b,.5))
