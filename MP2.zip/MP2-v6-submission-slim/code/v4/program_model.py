import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import torch
from torch import nn
class ProgramNet(nn.Module):
 def __init__(self,words,classes,use_embeddings=True):
  super().__init__();self.use_embeddings=use_embeddings;self.text=nn.Sequential(nn.Linear(words,64),nn.GELU(),nn.Dropout(.25));self.embed=nn.Sequential(nn.Linear(1024,64),nn.GELU(),nn.Dropout(.3));self.head=nn.Sequential(nn.Linear(128 if use_embeddings else 64,64),nn.GELU(),nn.Dropout(.25),nn.Linear(64,classes))
 def forward(self,q,e):
  h=self.text(q)
  if self.use_embeddings:h=torch.cat([h,self.embed(e)],-1)
  return self.head(h)
