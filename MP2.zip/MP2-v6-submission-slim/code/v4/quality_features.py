import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import numpy as np
from submission import features
from common import parse_answer

def prepare(bank,arrays):
 e,f=features(bank,arrays);valid=np.array([[parse_answer(c['text'])is not None for c in r['candidates']]for r in bank]);f=f.copy();f[:,:,1]=0;f[:,:,13]=0;center=(e.astype('float64')*valid[:,:,None]).sum(1,keepdims=True)/valid.sum(1)[:,None,None].clip(1);delta=e-center.astype('float32');return e,delta,f,valid

def fit_transform(raw,ids,quadratic):
 e,d,f,v=raw;z={}
 for name,a,floor in [('e',e,.1),('d',d,.02),('f',f,.1)]:z[name+'m']=a[ids][v[ids]].mean(0);z[name+'s']=a[ids][v[ids]].std(0).clip(floor)
 z['quadratic']=np.int32(quadratic);return z

def transform(raw,z):
 e,d,f,v=raw;ee=np.clip((e-z['em'])/z['es'],-10,10);dd=np.clip((d-z['dm'])/z['ds'],-10,10);ff=np.clip((f-z['fm'])/z['fs'],-10,10);parts=[ee,dd]
 if bool(z['quadratic']):parts += [ee*dd,dd*dd]
 return np.clip(np.concatenate(parts+[ff],-1),-10,10).astype('float32')
