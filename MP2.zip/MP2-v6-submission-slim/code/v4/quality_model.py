import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import torch
from torch import nn
class QualityNet(nn.Module):
 def __init__(self,features,hidden):
  super().__init__();self.enc=nn.Sequential(nn.Linear(features,hidden),nn.ReLU(),nn.Dropout(.4));self.head=nn.Sequential(nn.Linear(hidden*3,hidden),nn.ReLU(),nn.Dropout(.3),nn.Linear(hidden,1))
 def forward(self,x,valid):
  h=self.enc(x);m=(h.double()*valid[:,:,None]).sum(1,keepdim=True)/valid.sum(1)[:,None,None].clamp(min=1);m=m.float().expand_as(h);return self.head(torch.cat([h,h-m,m],-1)).squeeze(-1)
