import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import json
import numpy as np
from pathlib import Path
from common import load_inputs
from operation_profiles import candidate_profiles
out=[]
for split in ['train','validation']:
 b,_=load_inputs(split);out.append(candidate_profiles(b));print(split,'any',float((out[-1][:,:,29]>0).mean()),'full',float((out[-1][:,:,29]==1).mean()),flush=True)
np.savez('candidate_profiles.npz',train=out[0],validation=out[1]);Path('candidate_profile_records.json').write_text(json.dumps(dict(coverage=[float((v[:,:,29]>0).mean())for v in out],full_coverage=[float((v[:,:,29]==1).mean())for v in out]),indent=2))
