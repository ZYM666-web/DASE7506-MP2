import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
"""Permutation-symmetric geometry and lexical coverage; input-only."""
import re
import numpy as np
from common import parse_answer
from rich_features import numbers
STOP=set('a an the of to and or is are was were be been being it its he she his her they their them this that these those for from with in on at by as how what which who when where why much many does do did will would could should can has have had if then than more less each per total there so'.split())
def tokens(s):return {w[:-1]if len(w)>4 and w.endswith('s')else w for w in re.findall('[a-z]+',s.lower())if w not in STOP and len(w)>2}
def coverage(a,b):return len(a&b)/max(len(a),1)
def relational_evidence(bank,arrays,prior):
 e=np.asarray(arrays['embeddings'],dtype='float64');out=[]
 for row,h,score in zip(bank,e,prior):
  ans=[parse_answer(c['text'])for c in row['candidates']];valid=np.array([a is not None for a in ans]);norm=np.linalg.norm(h,axis=1).clip(1e-10);unit=h/norm[:,None];cos=unit@unit.T;center=h[valid].mean(0)if valid.any()else h.mean(0);q=row['question'];qt=tokens(q);tail=re.split(r'\b(?:how|what|which)\b',q.lower())[-1];goal=tokens(tail);qn=set(numbers(q));zz=[]
  for i,c in enumerate(row['candidates']):
   same=np.array([j!=i and a==ans[i]and a is not None for j,a in enumerate(ans)]);other=valid.copy();other[i]=False;different=other&~same;values=cos[i,other];sv=cos[i,same];dv=cos[i,different];order=sorted(np.where(other)[0],key=lambda j:(-score[j],float(cos[i,j])));cn=norm[other];text=c['text'];tt=tokens(text);sent=re.split(r'[.!?\n]',text);last=tokens(' '.join(sent[-4:]));tn=set(numbers(text));distance=np.linalg.norm(h-center,axis=1);z=[norm[i],norm[i]-norm[valid].mean()if valid.any()else 0,float(unit[i]@(center/max(np.linalg.norm(center),1e-10))),float(distance[i]),float(distance[i]/max(distance.mean(),1e-10)),float(values.min())if len(values)else 0,float(values.mean())if len(values)else 0,float(values.max())if len(values)else 0,float(values.std())if len(values)else 0,float(sv.mean())if len(sv)else 0,float(dv.mean())if len(dv)else 0,float(sv.mean()-dv.mean())if len(sv)and len(dv)else 0,float(cn.mean())if len(cn)else 0]
   z += [float(cos[i,order[k]])if len(order)>k else 0 for k in range(3)]
   z += [coverage(qt,tt),coverage(goal,tt),coverage(goal,last),coverage(qn,tn),len(qt&tt)/max(len(tt),1),len(goal),len(qn-tn),len(tn-qn)/max(len(tn),1),len(qn&tn),len(qt-tt)/max(len(qt),1)]
   for phrase in ['remaining','left','profit','discount','after','before','at least','at most','not','except']:
    z.append(float(phrase in q.lower())*float(phrase in text.lower()))
   zz.append(z)
  out.append(zz)
 return np.asarray(out,dtype='float32')
