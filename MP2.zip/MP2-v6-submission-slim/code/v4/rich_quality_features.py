import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from quality_features import prepare as basic_prepare,fit_transform,transform
from rich_features import rich_features

def prepare(bank,arrays):
 e,d,_,valid=basic_prepare(bank,arrays);_,f=rich_features(bank,arrays);f=f.copy();f[:,:,1]=0;f[:,:,13]=0;return e,d,f,valid
