import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import itertools,json
from pathlib import Path
import numpy as np
from common import load_inputs,read_jsonl,DATA,parse_answer
from rich_features import hard_mask
from submission import aggregate
b,_=load_inputs('validation');g=read_jsonl(DATA/'gsm8k_validation.jsonl');y=np.array([[parse_answer(c['text'])is not None and parse_answer(c['text'])==parse_answer(q['answer'])for c in r['candidates']]for r,q in zip(b,g)]);h=hard_mask(b);valid=np.array([[parse_answer(c['text'])is not None for c in r['candidates']]for r in b]);base=np.load('base_validation_scores.npy');records=json.loads(Path('alignment_records.json').read_text());members={r['name']:r for r in records['records']};scaled={k:aggregate(np.load(k+'_validation.npy')/v['scale'],b,.5)for k,v in members.items()};results=[]
for n in range(1,min(3,len(members))+1):
 for names in itertools.combinations(members,n):
  z=np.mean([scaled[k]for k in names],0)
  for w in [.1,.25,.5,1,2]:
   pp=(base+w*z).argmax(1);v=y[np.arange(len(pp)),pp];results.append(dict(models=list(names),weight=w,hard=float(v[h].mean()),all=float(v.mean())))
results.sort(key=lambda r:(r['hard'],r['all'],-len(r['models'])),reverse=True);out=dict(results=results,scales={k:v['scale']for k,v in members.items()});Path('alignment_search.json').write_text(json.dumps(out,indent=2));print('TOP',json.dumps(results[:10],indent=2))
