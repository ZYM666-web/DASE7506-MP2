import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import json,itertools
from pathlib import Path
import numpy as np
from common import load_inputs,read_jsonl,DATA,parse_answer
from rich_features import hard_mask
from submission import aggregate
b,_=load_inputs('validation');g=read_jsonl(DATA/'gsm8k_validation.jsonl');y=np.array([[parse_answer(c['text'])is not None and parse_answer(c['text'])==parse_answer(q['answer'])for c in r['candidates']]for r,q in zip(b,g)]);h=hard_mask(b);single=h&(y.sum(1)==1);base=np.load('alignment_selected_validation_scores.npy');branches=[]
for recordfile,folder in [('dynamic_gpu_records.json','dynamic_gpu_bundle'),('relational_records.json','relational_bundle'),('direct_pair_records.json','direct_pair_bundle')]:
 records=json.loads(Path(recordfile).read_text())['records'];best=max(records,key=lambda r:(r['singleton'],r['hard'],-Path(folder,f"{r['name']}.pt").stat().st_size));r=dict(best);r['folder']=folder;lp=np.load(r['name']+'_validation.npy');branches.append((r,aggregate(lp/r['scale'],b,.5)))
assetbase=sum(f.stat().st_size for f in Path('../runs/final').rglob('*')if f.is_file());results=[]
for weights in itertools.product([0,.1,.25,.5],repeat=len(branches)):
 size=assetbase;score=base.copy()
 for w,(r,sc)in zip(weights,branches):
  if w:
   score+=w*sc;size+=Path(r['folder'],r['name']+'.pt').stat().st_size
   size+=sum(f.stat().st_size for f in Path(r['folder']).glob('*')if f.suffix!='.pt')
 if size>16*1024*1024:continue
 v=y[np.arange(len(y)),score.argmax(1)];results.append(dict(weights=weights,hard=float(v[h].mean()),singleton=float(v[single].mean()),all=float(v.mean()),assetbytes=size))
eligible=[r for r in results if r['hard']>=319/355-1e-6];best=max(eligible,key=lambda r:(r['singleton'],r['hard'],r['all'],-sum(w!=0 for w in r['weights']),-r['assetbytes'],-sum(r['weights'])));out=dict(criterion='Singleton accuracy, hard >=319/355, then hard/all accuracy, fewer members/bytes/weight. Defined before this test.',branches=[r for r,sc in branches],best=best,results=results);Path('complementary_selection.json').write_text(json.dumps(out,indent=2));np.save('complementary_validation_scores.npy',base+sum(w*sc for w,(r,sc)in zip(best['weights'],branches)));print(json.dumps(dict(branches=out['branches'],best=best),indent=2))
