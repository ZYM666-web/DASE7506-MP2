import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import json
from pathlib import Path
import numpy as np
from common import load_inputs,read_jsonl,DATA,parse_answer
from rich_features import hard_mask
from submission import aggregate
b,_=load_inputs('validation');g=read_jsonl(DATA/'gsm8k_validation.jsonl');y=np.array([[parse_answer(c['text'])is not None and parse_answer(c['text'])==parse_answer(q['answer'])for c in r['candidates']]for r,q in zip(b,g)]);h=hard_mask(b);single=h&(y.sum(1)==1);base=np.load('complementary_validation_scores.npy');new=json.loads(Path('semantic_ensemble_records.json').read_text())['records'];original=json.loads(Path('semantic_residual_records.json').read_text())['records'][-1];original['dimension']=64;original['folder']='semantic_residual_bundle';original['projection']='original';records=[original]+[{**r,'folder':'semantic_ensemble_bundle','projection':'wide'}for r in new];sets=[[0],[0,1,2],[3,4],[5,6],list(range(7))];results=[]
for ids in sets:
 sc=aggregate(np.mean([np.load(records[i]['name']+'_validation.npy')/records[i]['scale']for i in ids],0),b,.5);size=sum(Path(records[i]['folder'],records[i]['name']+'.cbm').stat().st_size for i in ids)+sum(Path(records[i]['folder'],'pca.npz').stat().st_size for i in {next(k for k in ids if records[k]['projection']==tag)for tag in {records[j]['projection']for j in ids}})
 for w in [0,.1,.25,.5,1,2]:
  v=y[np.arange(len(y)),(base+w*sc).argmax(1)];results.append(dict(ids=ids,weight=w,hard=float(v[h].mean()),singleton=float(v[single].mean()),all=float(v.mean()),branch_assetbytes=size))
best=max([r for r in results if r['hard']>=319/355-1e-6],key=lambda r:(r['singleton'],r['hard'],r['all'],-r['branch_assetbytes'],-r['weight']));Path('semantic_ensemble_selection.json').write_text(json.dumps(dict(records=records,results=results,best=best),indent=2));print('BEST ENSEMBLE',best)
