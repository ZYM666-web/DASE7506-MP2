import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
"""Conservative quantity typing and monotonicity checks on supplied proofs."""
import json,re
from fractions import Fraction
import numpy as np
from programs import question_values,reference_programs,scalar_eval
from verify_arithmetic import eqs
from common import parse_answer
STOP=set('of those these the a an that which it them more fewer less each apiece per at for to and than is are was were costs cost costing buys buy bought sells sell sold has had have with as in on into from by his her their its my your our worth'.split())
NEG=set('lost lose loses used uses use ate eat eats sold sells sell spent spends spend removed removes remove donated donates donate'.split())
POS=set('has have had owns owned start starts started received receives receive got gets get earned earns earn found finds find bought buys buy added adds add collected collects collect'.split())
def stem(w):
 w={'children':'child','people':'person','feet':'foot','men':'man','women':'woman'}.get(w,w)
 if w.endswith('ies'):return w[:-3]+'y'
 if w in ['boxes','glasses','dresses','buses']:return w[:-2]
 return w[:-1]if w.endswith('s')and len(w)>3 else w

def metadata(question):
 values,q=question_values(question);matches=list(re.finditer(r'\bnum(\d+)\b',q));units={i:{}for i in range(len(values))};roles={};nouns={};priced=set();price_items={};wordspans={};money=set()
 for j,m in enumerate(matches):
  i=int(m[1])
  if i>=len(values):continue
  end=matches[j+1].start()if j+1<len(matches)else len(q);post=q[m.end():end];before=q[max(0,m.start()-80):m.start()];wordspans[i]=(before,post)
  words=re.findall(r'[a-z]+',post);noun=next((stem(w)for w in words if w not in STOP and w not in ['million','thousand']),None);nouns[i]=noun
  if re.search(r'\$\s*$',before)or re.match(r'\s*(?:million\s+|thousand\s+)?(?:dollars?|bucks?)\b',post):
   units[i]={'M':1};money.add(i)
   if re.match(r'\s*(?:million\s+|thousand\s+)?(?:dollars?\s+)?(?:per|each|a|an)\s+(hour|minute|second|day|week|month|year)',post):units[i]['T']=-1
   elif re.match(r'\s*(?:dollars?\s+)?per\s+(mile|foot|feet|meter|kilometer)',post):units[i]['L']=-1
   elif re.match(r'\s*(?:dollars?\s+)?per\s+(gallon|liter|litre)',post):units[i]['V']=-1
   rolewords=re.findall(r'\b(?:buys?|bought|purchases?|purchased|costs?|pay|paid|spent|spends?|sells?|sold|earns?|earned|charges?|charged)\b',before)
   if rolewords:roles[i]='sell'if rolewords[-1]in ['sell','sells','sold','earn','earns','earned','charge','charges','charged']else'buy'
  elif re.match(r'\s*(?:miles?|mph|kilometers?|meters?|feet|foot|inches?)\b',post):
   units[i]={'L':1}
   if re.search(r'per\s+(?:hour|minute|second)|/\s*(?:hour|minute|second)|mph',post[:35]):units[i]['T']=-1
  elif re.match(r'\s*square\s+(?:feet|foot|meters?|miles?)',post):
   units[i]={'L':2}
   if re.search(r'per\s+gallon',post[:45]):units[i]['V']=-1
  elif re.match(r'\s*(?:hours?|minutes?|seconds?|days?|weeks?|months?|years?)\b',post):units[i]={'T':1}
  elif re.match(r'\s*(?:gallons?|liters?|litres?)\b',post):units[i]={'V':1}
 # Item rates explicitly marked each/apiece and paired with the previous quantity.
 for j,m in enumerate(matches):
  price=int(m[1])
  if price not in money or units[price]!={'M':1}:continue
  post=wordspans[price][1]
  if not re.match(r'\s*(?:million\s+|thousand\s+)?(?:dollars?\s+)?(?:each|apiece)\b',post):continue
  if j==0:continue
  count=int(matches[j-1][1]);between=q[matches[j-1].end():m.start()];words=re.findall(r'[a-z]+',between);noun=next((stem(w)for w in words if w not in STOP and w not in ['million','thousand']),None)
  if noun is None and len(priced)==1:noun=next(iter(priced))
  if noun is None or noun in ['hour','minute','second','day','week','month','year','mile','foot','meter','gallon','liter']:continue
  priced.add(noun);price_items[price]=noun;units[price]={'M':1,'C:'+noun:-1}
  if count<len(values)and count not in money:units[count]={'C:'+noun:1}
 for i,noun in nouns.items():
  if noun in priced and i not in money and not units[i]:units[i]={'C:'+noun:1}
 starts=list(re.finditer(r'\b(?:how|what)\b',q));tail=q[starts[-1].start():]if starts else q;percentage=bool(re.search(r'percent|percentage|%|ratio|margin',tail));profit='profit'in tail and not percentage;balance=bool(re.search(r'left|remain|balance|still have',tail))and bool(re.search(r'money|dollars?|cash|balance|register|account',q));cost=bool(re.search(r'pay|paid|spend|spent|total cost|total price',tail));money_goal=(profit or balance or bool(re.search(r'money|dollars?|cash|total cost',tail)))and not percentage
 expected={}
 for i,role in roles.items():
  if role=='sell'and(profit or balance):expected[i]=1
  if role=='buy'and balance:expected[i]=-1
  elif role=='buy'and profit and not re.search(r'doubl|twice|value|worth|increase',q):expected[i]=-1
  elif role=='buy'and cost:expected[i]=1
 # Inventory conservation, only with an explicit requested item and a remaining-stock goal.
 target=re.search(r'how many\s+(?:(?:more|fewer|total|additional)\s+)?([a-z]+)',tail)
 flow={}
 if target and re.search(r'left|remain|still|have now|has now',tail):
  noun=stem(target[1])
  for i,(before,post)in wordspans.items():
   if noun not in [stem(w)for w in re.findall(r'[a-z]+',post[:45])]:continue
   words=re.findall(r'[a-z]+',re.split(r'[.;!?]',before)[-1]);actions=[w for w in words if w in NEG or w in POS]
   if actions:flow[i]=-1 if actions[-1]in NEG else 1
 return values,units,expected,flow,profit,money_goal,roles

def combine(a,b,sign):
 out=dict(a)
 for k,v in b.items():out[k]=out.get(k,0)+sign*v
 return {k:v for k,v in out.items()if v}

def tree_warnings(tree,meta):
 values,units,expected,flow,profit,money_goal,roles=meta;errors=0;monetary_sub=False;used=set()
 def walk(p):
  nonlocal errors,monetary_sub
  if p[0]=='q':used.add(p[1]);return units.get(p[1])
  if p[0]=='c':return {}
  a,b=walk(p[1]),walk(p[2])
  if a is None or b is None:return None
  if p[0]in ['+','-']:
   if a!=b:errors+=1;return None
   if p[0]=='-'and a.get('M',0)==1:monetary_sub=True
   return a
  return combine(a,b,1 if p[0]=='*'else-1)
 unit=walk(tree);final_error=int(money_goal and unit is not None and unit!={'M':1});mono=inventory=0
 try:
  original=scalar_eval(tree,values)
  for index,sign in expected.items():
   if index not in used:continue
   changed=list(values);changed[index]+=.0001*(1+abs(values[index]));effect=scalar_eval(tree,changed)-original
   if sign*effect<-1e-6*(1+abs(original)):mono+=1
  for index,sign in flow.items():
   if index not in used:continue
   changed=list(values);changed[index]+=.0001*(1+abs(values[index]));effect=scalar_eval(tree,changed)-original
   if sign*effect<-1e-6*(1+abs(original)):inventory+=1
 except(ValueError,KeyError,IndexError):pass
 missing=int(profit and'sell'in roles.values()and'buy'in roles.values()and not monetary_sub)
 return [min(errors,3),final_error,min(mono,3),missing,min(inventory,3)]

def semantic_warnings(bank):
 out=[]
 for row in bank:
  meta=metadata(row['question']);values=meta[0];duplicate=any(abs(a-b)<1e-7*(1+abs(a))for j,a in enumerate(values)for b in values[:j]);fs=[]
  for candidate in row['candidates']:
   answer=parse_answer(candidate['text']);trees=[]
   if not duplicate and answer is not None:
    pairs=eqs(candidate['text']);pseudo='\n'.join('<<'+left+'='+str(result)+'>>'for left,right,_,result in pairs);trees=[json.loads(s)for s in reference_programs(row['question'],pseudo,float(Fraction(answer)))]
   if trees:fs.append(np.min([tree_warnings(t,meta)for t in trees],axis=0))
   else:fs.append([0]*5)
  out.append(fs)
 return np.asarray(out,dtype=np.float32)
