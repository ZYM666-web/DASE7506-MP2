import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
"""Conservative semantic arithmetic experts. These are general rules, not IDs."""
import re,math
from fractions import Fraction
import numpy as np
from common import parse_answer
N=r'(\d[\d,]*(?:\.\d+)?|\.\d+)'
def val(s):return float(s.replace(',',''))
def nums(q):return [val(v)for v in re.findall(N,q)]
def regex(pattern,q):return re.search(pattern,q,re.I)
def experts(question):
 q=question.lower();out={};ns=nums(q)
 def put(name,v):
  if math.isfinite(v)and abs(v)<1e12:out[name]=v
 # Standard purchase-discount questions with just one price and one rate.
 perc=re.findall(N+r'\s*%',q);money=re.findall(r'\$\s*'+N,q)
 if 'discount'in q and len(perc)==1 and len(money)==1 and len(ns)==2:
  r=val(perc[0])/100;c=val(money[0])
  if 0<r<1:
   if regex(r'discount[^.?!]{0,45}(?:is|was|of|received)\s*\$|discount[^.?!]{0,25}received\s+is',q):
    if regex(r'original|before.*discount|without.*discount',q):put('discount_amount_to_original',c/r)
    elif regex(r'pay|paid|spend|spent|in total',q):put('discount_amount_to_paid',c/r-c)
   elif regex(r'sav(?:e|ed|ing)|how much.*discount',q):put('discount_saving',c*r)
   elif regex(r'pay|paid|cost|price|spend|spent',q):put('discount_price',c*(1-r))
 # Explicit two-speed catch-up problem, consistent units required.
 if regex(r'catch(?:es)? up|catch the|catch a|caught up',q):
  speeds=re.findall(N+r'\s*(?:miles?|feet|meters?|kilometers?|km)\s*(?:per|/)\s*(hour|second|minute)',q)
  speeds += [(v,'hour')for v in re.findall(N+r'\s*mph',q)]
  gap=regex(r'(?:head start(?: of)?|ahead(?: by)?)\s*(?:of\s*)?'+N,q)
  if gap is None:gap=regex(N+r'\s*(?:miles?|feet|meters?|kilometers?|km)(?:\s+|-)head start',q)
  if len(speeds)==2 and speeds[0][1]==speeds[1][1]and gap:
   a,b=[val(v)for v,u in speeds];d=val(gap[1]);u=speeds[0][1]
   if a!=b:
    t=d/abs(a-b)
    target=regex(r'how (?:many|long)[^.?!]{0,12}(minutes?|seconds?|hours?)',q)
    if target:
     unit=target[1].rstrip('s');factor={'second':1,'minute':60,'hour':3600};put('relative_speed_catchup',t*factor[u]/factor[unit])
 # Constant-increment or constant-ratio daily sequences.
 first=regex(r'(?:first day[^.?!]{0,50}|day one[^.?!]{0,25})\b'+N,q)
 duration=regex(r'(?:for|over|in)\s+'+N+r'\s+days',q)
 inc=regex(N+r'\s+more[^.?!]{0,45}(?:day before|previous day|each day|every day)',q)
 if first and duration and inc and regex(r'in all|in total|total|altogether',q):
  a,d,n=val(first[1]),val(inc[1]),val(duration[1]);put('arithmetic_daily_total',n*(2*a+(n-1)*d)/2)
 if first and regex(r'twice as (?:many|much)[^.?!]{0,45}(?:day before|previous day)',q)and regex(r'in all|in total|total|altogether',q):
  duration=duration or regex(r'(?:after|on)\s+(?:the\s+)?'+N+r'(?:st|nd|rd|th)\s+day',q)
  if duration:
   a,n=val(first[1]),val(duration[1])
   if n<=20:put('geometric_daily_total',a*(2**n-1))
 # All the stated males and females pair one-to-one.
 if regex(r'partner|pair up',q)and regex(r'opposite gender|male.*female|boy.*girl',q):
  male=[val(v)for v in re.findall(N+r'\s+(?:males?|boys?)\b',q)];female=[val(v)for v in re.findall(N+r'\s+(?:females?|girls?)\b',q)]
  if male and female and len(male)==len(female)and regex(r'unable|cannot|unpaired|left over',q):put('opposite_gender_unpaired',abs(sum(male)-sum(female)))
 # Explicit rectangular dimensions and no additional quantity.
 if len(ns)==2 and regex(r'rectang(?:le|ular)',q)and regex(r'length|long',q)and regex(r'width|wide',q):
  if 'perimeter'in q:put('rectangle_perimeter',2*sum(ns))
  elif 'area'in q:put('rectangle_area',ns[0]*ns[1])
 # Jobs done independently, then completed together. Exactly two times.
 if len(ns)==2 and regex(r'together|both.*same time',q)and regex(r'complete|finish|fill|paint|mow',q):
  units=re.findall(N+r'\s+(hours?|minutes?|days?)',q)
  if len(units)==2 and units[0][1].rstrip('s')==units[1][1].rstrip('s')and all(n>0 for n in ns):put('combined_work_rates',ns[0]*ns[1]/sum(ns))
 # Purchase and resale at per-item prices. Require explicit quantities/prices.
 buy=regex(r'(?:buys?|bought|purchases?|purchased)\s+'+N+r'\s+[^.?!]{0,70}?(?:for|at|costs?|costing)\s*\$'+N+r'\s*(?:each|apiece|per\b)',q)
 sell=regex(r'(?:sells?|sold)\s+'+N+r'\s+[^.?!]{0,60}?(?:for|at)\s*\$'+N+r'\s*(?:each|apiece|per\b)',q)
 if buy and 'profit'in q:
  count,cost=val(buy[1]),val(buy[2])
  if sell:
   sold,price=val(sell[1]),val(sell[2]);remaining=count-sold
   if remaining>=0 and regex(r'(?:rest|remain)[^.?!]{0,60}(?:doubl|twice)',q):put('resale_remaining_double',sold*price+remaining*cost*2-count*cost)
   elif remaining==0:put('resale_all_explicit',count*(price-cost))
  resale=regex(r'(?:sells?|sold)\s+(?:them|each[^.?!]{0,20}|the[^.?!]{0,25})\s+for\s*\$'+N+r'\s*(?:each|apiece)',q)
  if resale and not sell:put('resale_all_pronoun',count*(val(resale[1])-cost))
 # A balance plus explicitly priced outgoing/incoming item transactions.
 if regex(r'balance|money.*left|left.*(?:account|register)',q):
  initial=regex(r'(?:balance(?: of)?|starts? with|initially has)\s*\$'+N,q)
  if initial:
   incoming=re.findall(r'(?:sells?|sold)\s+'+N+r'\s+[^.?!]{0,40}?(?:for|at)\s*\$'+N+r'\s*(?:million\s+)?each',q)
   outgoing=re.findall(r'(?:buys?|bought)\s+'+N+r'\s+[^.?!]{0,40}?(?:for|at)\s*\$'+N+r'\s*(?:million\s+)?each',q)
   if incoming and outgoing:put('balance_transactions',val(initial[1])+sum(val(n)*val(c)for n,c in incoming)-sum(val(n)*val(c)for n,c in outgoing))
 # Coverage, paint price and total area are each explicit.
 if 'paint'in q and 'gallon'in q:
  price=regex(r'gallon[^.?!]{0,20}costs?\s*\$'+N,q);coverage=regex(r'cover(?:s| up to)?\s*'+N+r'\s+square feet',q);area=regex(r'(?:total area(?: of)?|walls?[^.?!]{0,20}area(?: of)?)\s*'+N+r'\s+square feet',q)
  if price and coverage and area and val(coverage[1])>0:
   coats=2 if regex(r'second coat|two coats',q)else 1;people=2 if regex(r'each of them|split the cost|contribute',q)and regex(r'\b\w+ and \w+\b',q)else 1
   put('paint_coverage_cost',val(price[1])*val(area[1])*coats/(val(coverage[1])*people))
 return out

def predictions(bank):
 names=sorted(set(k for r in bank for k in experts(r['question'])));out=np.zeros((len(bank),4,len(names)),dtype=np.float32);idx={k:i for i,k in enumerate(names)}
 for j,r in enumerate(bank):
  values=[float(Fraction(a))if(a:=parse_answer(c['text']))is not None else None for c in r['candidates']]
  for name,value in experts(r['question']).items():
   for i,v in enumerate(values):
    if v is not None and abs(v-value)<1e-5*(1+abs(value)):out[j,i,idx[name]]=1
 return names,out
