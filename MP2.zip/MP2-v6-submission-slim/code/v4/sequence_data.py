import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import json,re
from collections import Counter
from pathlib import Path
from fractions import Fraction
import numpy as np
from common import load_inputs,read_jsonl,DATA,parse_answer
from programs import reference_programs,question_values,size
from verify_arithmetic import eqs

def tokens(question):return re.findall(r"num\d+|[a-z]+(?:'[a-z]+)?|[%$]",question_values(question)[1])
def prefix(p):
 if p[0]=='q':return ['q'+str(p[1])]
 if p[0]=='c':return ['c'+str(float(p[1]))]
 return [p[0]]+prefix(p[1])+prefix(p[2])
def candidate_tree(q,text):
 a=parse_answer(text)
 if a is None:return None
 pairs=eqs(text);pseudo='\n'.join('<<'+l+'='+str(b)+'>>'for l,r,a,b in pairs);ps=reference_programs(q,pseudo,float(Fraction(a)))
 return max((json.loads(s)for s in ps),key=size,default=None)

if __name__=='__main__':
 root=Path('sequence_bundle');root.mkdir(exist_ok=True);b=[];refs=[];cands=[];labels=[];words=Counter();program_words=set()
 for split in ['train','validation']:
  bank,_=load_inputs(split);g=read_jsonl(DATA/f'gsm8k_{split}.jsonl');b.append(bank);rows=[];yy=[];gold=[]
  for r,q in zip(bank,g):
   if split=='train':
    words.update(tokens(r['question']));ps=reference_programs(r['question'],q['answer'],float(Fraction(parse_answer(q['answer']))));gt=max((json.loads(s)for s in ps),key=size,default=None);gold.append(gt)
   ts=[candidate_tree(r['question'],c['text'])for c in r['candidates']];rows.append(ts);yy.append([parse_answer(c['text'])is not None and parse_answer(c['text'])==parse_answer(q['answer'])for c in r['candidates']])
   if split=='train':
    for t in ts+[gt]:
     if t is not None:program_words.update(prefix(t))
  cands.append(rows);labels.append(yy);refs.append(gold)
  print('trees',split,sum(t is not None for row in rows for t in row)/len(rows)/4,flush=True)
 vocab={'<pad>':0,'<unk>':1};vocab.update({w:i+2 for i,(w,n)in enumerate(words.most_common(3998))});pv={'<pad>':0,'<bos>':1,'<eos>':2,'<unk>':3};pv.update({w:i+4 for i,w in enumerate(sorted(program_words))});(root/'vocabulary.json').write_text(json.dumps(vocab));(root/'program_vocabulary.json').write_text(json.dumps(pv));data={}
 def encq(text):
  ids=[vocab.get(t,1)for t in tokens(text)]
  if len(ids)>128:ids=ids[:96]+ids[-32:]
  return ids+[0]*(128-len(ids))
 def encp(tree):
  if tree is None:return [0]*42
  ids=[1]+[pv.get(t,3)for t in prefix(tree)]+[2];return ids[:42]+[0]*max(0,42-len(ids))
 for j,split in enumerate(['train','validation']):
  data[split+'_q']=np.array([encq(r['question'])for r in b[j]],dtype=np.int64);data[split+'_programs']=np.array([[encp(t)for t in row]for row in cands[j]],dtype=np.int64);data[split+'_labels']=np.array(labels[j],dtype=np.float32)
 data['train_gold']=np.array([encp(t)for t in refs[0]],dtype=np.int64);np.savez('sequence_data.npz',**data);print('vocab',len(vocab),len(pv),'gold',sum(t is not None for t in refs[0]),flush=True)
