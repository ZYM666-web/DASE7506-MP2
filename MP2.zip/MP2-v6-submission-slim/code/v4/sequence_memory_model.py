import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import torch
from torch import nn
from sequence_model import SequenceVerifier
class MemorySequenceVerifier(SequenceVerifier):
 def __init__(self,words,program_words):
  super().__init__(words,program_words);self.candidate=nn.Sequential(nn.Linear(1024,64),nn.LayerNorm(64),nn.GELU())
 def encode(self,q,embeddings):return torch.cat([self.candidate(embeddings),super().encode(q)],1)
 def decode(self,mem,q,prog):
  inp=prog[:,:-1].clone();empty=(inp!=0).sum(1)==0;inp[empty,0]=1;h=self.prog(inp)+self.ppos(torch.arange(inp.shape[1],device=prog.device))[None];mask=torch.triu(torch.ones(inp.shape[1],inp.shape[1],dtype=torch.bool,device=prog.device),diagonal=1);padding=torch.cat([torch.zeros((len(q),4),dtype=torch.bool,device=q.device),q==0],1);h=self.decoder(h,mem,tgt_mask=mask,tgt_key_padding_mask=inp==0,memory_key_padding_mask=padding);return self.output(h)
 def forward(self,q,prog,embeddings):return self.decode(self.encode(q,embeddings),q,prog)
 def scores(self,q,programs,embeddings):
  mem=self.encode(q,embeddings);n=programs.shape[1];pp=programs.reshape(-1,programs.shape[-1]);qq=q.repeat_interleave(n,0);mm=mem.repeat_interleave(n,0);logits=self.decode(mm,qq,pp);target=pp[:,1:];lp=logits.log_softmax(-1).gather(-1,target[:,:,None]).squeeze(-1);mask=target!=0;sc=(lp*mask).sum(1)/mask.sum(1).clamp(min=1);return sc.reshape(len(q),n)
