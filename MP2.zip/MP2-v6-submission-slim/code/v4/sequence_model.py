import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import torch
from torch import nn
class SequenceVerifier(nn.Module):
 def __init__(self,words,program_words):
  super().__init__();self.word=nn.Embedding(words,64,padding_idx=0);self.qpos=nn.Embedding(128,64);self.prog=nn.Embedding(program_words,64,padding_idx=0);self.ppos=nn.Embedding(42,64);enc=nn.TransformerEncoderLayer(64,4,128,dropout=.2,activation='gelu',batch_first=True,norm_first=True);self.encoder=nn.TransformerEncoder(enc,2,enable_nested_tensor=False);dec=nn.TransformerDecoderLayer(64,4,128,dropout=.2,activation='gelu',batch_first=True,norm_first=True);self.decoder=nn.TransformerDecoder(dec,1);self.output=nn.Linear(64,program_words)
 def encode(self,q):return self.encoder(self.word(q)+self.qpos(torch.arange(q.shape[1],device=q.device))[None],src_key_padding_mask=q==0)
 def decode(self,mem,q,prog):
  inp=prog[:,:-1].clone();empty=(inp!=0).sum(1)==0;inp[empty,0]=1;h=self.prog(inp)+self.ppos(torch.arange(inp.shape[1],device=prog.device))[None];mask=torch.triu(torch.ones(inp.shape[1],inp.shape[1],dtype=torch.bool,device=prog.device),diagonal=1);h=self.decoder(h,mem,tgt_mask=mask,tgt_key_padding_mask=inp==0,memory_key_padding_mask=q==0);return self.output(h)
 def forward(self,q,prog):return self.decode(self.encode(q),q,prog)
 def scores(self,q,programs):
  mem=self.encode(q);n=programs.shape[1];pp=programs.reshape(-1,programs.shape[-1]);qq=q.repeat_interleave(n,0);mm=mem.repeat_interleave(n,0);logits=self.decode(mm,qq,pp);target=pp[:,1:];lp=logits.log_softmax(-1).gather(-1,target[:,:,None]).squeeze(-1);mask=target!=0;sc=(lp*mask).sum(1)/mask.sum(1).clamp(min=1);return sc.reshape(len(q),n)
