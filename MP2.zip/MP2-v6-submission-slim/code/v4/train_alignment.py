import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='4'
import json,time
from pathlib import Path
import numpy as np,torch
from sklearn.feature_extraction.text import TfidfVectorizer
from common import load_inputs,read_jsonl,DATA,parse_answer
from submission import features,aggregate
from rich_features import hard_mask
from programs import question_values
from alignment_model import AlignmentNet
p=Path('alignment_bundle');p.mkdir(exist_ok=True);start=time.time();torch.set_num_threads(4);bs=[];yy=[];raw=[];texts=[];hs=[];cp=np.load('candidate_profiles.npz');c=[cp['train'],cp['validation']]
for j,split in enumerate(['train','validation']):
 b,a=load_inputs(split);bs.append(b);e,f=features(b,a);raw.append(np.concatenate([e,f,c[j]],-1));texts.append([question_values(r['question'])[1]for r in b]);hs.append(hard_mask(b));g=read_jsonl(DATA/f'gsm8k_{split}.jsonl');yy.append(np.array([[parse_answer(t['text'])is not None and parse_answer(t['text'])==parse_answer(r['answer'])for t in row['candidates']]for row,r in zip(b,g)],dtype=np.float32))
vec=TfidfVectorizer(max_features=3000,ngram_range=(1,2),sublinear_tf=True);qq=[torch.tensor(vec.fit_transform(texts[0]).toarray()*5,dtype=torch.float32),torch.tensor(vec.transform(texts[1]).toarray()*5,dtype=torch.float32)];mean=raw[0].mean((0,1));std=raw[0].std((0,1)).clip(.1);xx=[torch.tensor(np.clip((x-mean)/std,-15,15))for x in raw];cc=[torch.tensor(z)for z in c];np.savez(p/'stats.npz',mean=mean,std=std,idf=vec.idf_.astype('float32'));(p/'vocabulary.json').write_text(json.dumps({k:int(v)for k,v in vec.vocabulary_.items()}));yp=np.load('gold_profiles.npz');target=torch.tensor(yp['profiles']);mask=torch.tensor(yp['valid']);y=torch.tensor(yy[0]);w=torch.tensor(np.where(hs[0],3.,.5),dtype=torch.float32);base=np.load('base_validation_scores.npy');records=[];valid=np.array([[parse_answer(t['text'])is not None for t in row['candidates']]for row in bs[1]])
for auxiliary in [False,True]:
 for seed in [2500,2501,2502]:
  torch.manual_seed(seed);net=AlignmentNet(qq[0].shape[1],xx[0].shape[-1]);opt=torch.optim.AdamW(net.parameters(),lr=.0005,weight_decay=.03);best=-1;name=f'alignment_{int(auxiliary)}_{seed}'
  for ep in range(65):
   net.train();perm=torch.randperm(len(y))
   for ids in perm.split(128):
    s,op=net(xx[0][ids],qq[0][ids],cc[0][ids]);t=y[ids];loss=torch.logsumexp(s,1)-torch.logsumexp(s.masked_fill(t==0,-1e4),1)+.25*torch.nn.functional.binary_cross_entropy_with_logits(s,t,reduction='none').mean(1);loss=(loss*w[ids]).mean()
    if auxiliary and mask[ids].any():loss+=.2*torch.nn.functional.mse_loss(op[mask[ids]],target[ids][mask[ids]])
    opt.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(net.parameters(),5);opt.step()
   net.eval()
   with torch.no_grad():lp=net(xx[1],qq[1],cc[1])[0].numpy()
   sc=aggregate(lp,bs[1],.5);pp=sc.argmax(1);v=yy[1][np.arange(len(pp)),pp];acc=float(v[hs[1]].mean());scale=max(float(np.mean([row[vm].std()for row,vm,hard in zip(lp,valid,hs[1])if hard])),.01);blend=[]
   for weight in [0,.1,.25,.5,1,2]:
    pr=(base+weight*sc/scale).argmax(1);vv=yy[1][np.arange(len(pr)),pr];blend.append((float(vv[hs[1]].mean()),weight,float(vv.mean())))
   mix=max(blend,key=lambda z:z[0]);criterion=mix[0]+1e-5*acc
   if criterion>best:best=criterion;state={k:v.clone()for k,v in net.state_dict().items()};bp=lp.copy();be=ep;br=dict(hard=mix[0],weight=mix[1],all=mix[2],standalone_hard=acc,scale=scale)
   if ep%20==0:print(name,ep,acc,mix,flush=True)
  torch.save(state,p/f'{name}.pt');np.save(f'{name}_validation.npy',bp);r=dict(name=name,seed=seed,auxiliary=auxiliary,epoch=be,**br);records.append(r);print('BEST',r,flush=True);Path('alignment_records.json').write_text(json.dumps(dict(records=records,seconds=time.time()-start),indent=2))
