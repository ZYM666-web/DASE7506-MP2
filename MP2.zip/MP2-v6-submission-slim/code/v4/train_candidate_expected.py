import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='4'
import json,time
from pathlib import Path
import numpy as np
from scipy.sparse import hstack,csr_matrix
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import Ridge
from sklearn.model_selection import KFold
from common import load_inputs,read_jsonl,DATA,parse_answer
from programs import question_values
start=time.time();p=Path('candidate_profile_bundle');p.mkdir(exist_ok=True);cp=np.load('candidate_profiles.npz');b=[];es=[];texts=[];y=[];valid=[]
for split in ['train','validation']:
 bank,a=load_inputs(split);b.append(bank);es.append(a['embeddings'].mean(1));texts.append([question_values(r['question'])[1]for r in bank])
gold=read_jsonl(DATA/'gsm8k_train.jsonl');good=np.array([[parse_answer(c['text'])is not None and parse_answer(c['text'])==parse_answer(q['answer'])for c in r['candidates']]for r,q in zip(b[0],gold)]);mask=good*(cp['train'][:,:,29]>0);valid=mask.any(1);target=(cp['train']*mask[:,:,None]).sum(1)/mask.sum(1)[:,None].clip(1)
vec=TfidfVectorizer(max_features=3000,ngram_range=(1,2),sublinear_tf=True);q=[vec.fit_transform(texts[0]),vec.transform(texts[1])];m=es[0].mean(0);s=es[0].std(0).clip(.1);xx=[hstack([a*5,csr_matrix((e-m)/s)],format='csr')for a,e in zip(q,es)];oof=np.zeros_like(target)
for fold,(tr,ho)in enumerate(KFold(4,shuffle=True,random_state=2300).split(np.arange(len(target)))):
 model=Ridge(alpha=30,solver='lsqr',max_iter=150,tol=.001);ids=tr[valid[tr]];model.fit(xx[0][ids],target[ids]);oof[ho]=model.predict(xx[0][ho]);print('fold',fold,flush=True)
model=Ridge(alpha=30,solver='lsqr',max_iter=150,tol=.001);model.fit(xx[0][valid],target[valid]);vp=model.predict(xx[1]);np.savez(p/'profile_model.npz',coef=model.coef_.astype('float32'),intercept=model.intercept_.astype('float32'),embedding_mean=m,embedding_std=s,idf=vec.idf_.astype('float32'));(p/'vocabulary.json').write_text(json.dumps({k:int(v)for k,v in vec.vocabulary_.items()}));np.savez('expected_candidate_profiles.npz',train=oof,validation=vp);Path('candidate_expected_records.json').write_text(json.dumps(dict(n_valid=int(valid.sum()),seed=2300,folds=4,alpha=30,seconds=time.time()-start),indent=2))
