import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='4'
import json,time
from pathlib import Path
from fractions import Fraction
import numpy as np,torch
from sklearn.feature_extraction.text import TfidfVectorizer
from common import load_inputs,read_jsonl,DATA,parse_answer
from programs import question_values,serial
from compositional_model import CompositionalNet
from rich_features import hard_mask

torch.set_num_threads(4);start=time.time();p=Path('compositional_bundle');p.mkdir(exist_ok=True);programs=json.loads(Path('all_programs.json').read_text());K=len(programs);pf=np.load('program_features.npz');features=torch.tensor(pf['features']);prior=torch.tensor(np.log(pf['counts']));bs=[];ys=[];gold=[];es=[];hs=[];values=[];matches=[];texts=[]
for split in ['train','validation']:
 b,a=load_inputs(split);bs.append(b);es.append(a['embeddings'].mean(1));hs.append(hard_mask(b));texts.append([question_values(r['question'])[1]for r in b]);g=read_jsonl(DATA/f'gsm8k_{split}.jsonl');gold.append(np.array([float(Fraction(parse_answer(r['answer'])))for r in g]));ys.append(np.array([[parse_answer(c['text'])is not None and parse_answer(c['text'])==parse_answer(q['answer'])for c in r['candidates']]for r,q in zip(b,g)]));v=np.load(f'{split}_allprogram_values.npy');values.append(v);cm=[]
 for j,r in enumerate(b):
  row=[]
  for c in r['candidates']:
   a=parse_answer(c['text']);n=float(Fraction(a))if a is not None else np.nan;row.append(np.isfinite(v[j])&(abs(v[j]-n)<1e-5*(1+abs(n))))
  cm.append(row)
 matches.append(np.array(cm,dtype=np.float32))
vec=TfidfVectorizer(max_features=3000,ngram_range=(1,2),sublinear_tf=True);q=[torch.tensor(vec.fit_transform(texts[0]).toarray(),dtype=torch.float32),torch.tensor(vec.transform(texts[1]).toarray(),dtype=torch.float32)];em=es[0].mean(0);sd=es[0].std(0).clip(.1);ee=[torch.tensor((e-em)/sd,dtype=torch.float32)for e in es];np.savez(p/'stats.npz',embedding_mean=em,embedding_std=sd,idf=vec.idf_.astype('float32'));(p/'vocabulary.json').write_text(json.dumps({k:int(v)for k,v in vec.vocabulary_.items()}));(p/'programs.json').write_text(json.dumps(programs,separators=(',',':')));np.savez(p/'program_features.npz',features=pf['features'],counts=pf['counts'])
valid=[np.concatenate([np.isfinite(v)&(abs(v)<1e12),np.ones((len(v),1),dtype=bool)],1)for v in values];vm=[torch.tensor(v)for v in valid];ref=json.loads(Path('reference_program_targets.json').read_text());ix={serial(pr):i for i,pr in enumerate(programs)};rm=np.zeros((len(ref),K+1),dtype=bool)
for i,row in enumerate(ref):
 for s in row:
  if s in ix:rm[i,ix[s]]=True
rm[~rm.any(1),K]=True;rm=torch.tensor(rm);base=np.load('base_validation_scores.npy');records=[]
cm=torch.tensor(matches[1].transpose(0,2,1));cm0=torch.tensor(matches[0].transpose(0,2,1));yy=torch.tensor(ys[0]);unique=[]
for b in bs:
 um=[]
 for row in b:
  aa=[parse_answer(c['text'])for c in row['candidates']];um.append([a is not None and a not in aa[:i]for i,a in enumerate(aa)])
 unique.append(torch.tensor(um))
def evaluate(lp):
 logits=lp-lp.max(1,keepdims=True);prob=np.exp(logits);prob/=prob.sum(1,keepdims=True);ans=np.einsum('nk,nkc->nc',prob[:,:K],matches[1].transpose(0,2,1));score=np.log(ans+prob[:,K,None]/4+1e-8);best=(-1,None)
 for weight in [0,.05,.1,.25,.5,1,2]:
  z=base+weight*(score-score.mean(1,keepdims=True));pp=z.argmax(1);v=ys[1][np.arange(len(pp)),pp];acc=float(v[hs[1]].mean())
  if acc>best[0]:best=(acc,dict(weight=weight,all=float(v.mean()),hard=acc,solver_alone=float(ys[1][np.arange(len(pp)),score.argmax(1)][hs[1]].mean())))
 return best[1],score
for kind in ['reference','answer']:
 for seed in [1900,1901]:
  torch.manual_seed(seed);net=CompositionalNet(q[0].shape[1],features.shape[1]);opt=torch.optim.AdamW(net.parameters(),lr=.001,weight_decay=.03);best=-1;name=f'compositional_{kind}{seed}'
  for epoch in range(90):
   net.train();perm=torch.randperm(len(q[0]))
   for ids in perm.split(128):
    s=net(q[0][ids],ee[0][ids],features,prior).masked_fill(~vm[0][ids],-1e4);loss=(torch.logsumexp(s,1)-torch.logsumexp(s.masked_fill(~rm[ids],-1e4),1)).mean()
    if kind=='answer':
     prob=torch.softmax(s,1);ans=(prob[:,:K,None]*cm0[ids]).sum(1)+prob[:,K,None]/4;logans=ans.clamp(min=1e-8).log().masked_fill(~unique[0][ids],-1e4);t=yy[ids]*unique[0][ids];aux=-(torch.log_softmax(logans,1)*t/t.sum(1,keepdim=True)).sum(1).mean();loss=.3*loss+aux
    opt.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(net.parameters(),5);opt.step()
   net.eval()
   with torch.no_grad():lp=net(q[1],ee[1],features,prior).masked_fill(~vm[1],-1e4).numpy()
   r,score=evaluate(lp)
   if r['hard']>best:best=r['hard'];br=r;be=epoch;state={k:v.clone()for k,v in net.state_dict().items()};bp=score.copy();bl=lp.copy()
   if epoch%20==0:print(name,epoch,r,flush=True)
  torch.save(state,p/f'{name}.pt');np.save(f'{name}_validation.npy',bp);record=dict(name=name,seed=seed,epoch=be,**br);records.append(record);print('BEST',record,flush=True);Path('compositional_records.json').write_text(json.dumps(dict(records=records,seconds=time.time()-start),indent=2))
