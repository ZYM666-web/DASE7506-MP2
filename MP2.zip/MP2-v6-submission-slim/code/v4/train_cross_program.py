import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='4'
import json,time
from pathlib import Path
import numpy as np,torch
from common import load_inputs,read_jsonl,DATA,parse_answer
from submission import features,aggregate
from rich_features import hard_mask
from cross_program_model import CrossProgramVerifier
p=Path('cross_bundle');p.mkdir(exist_ok=True);torch.set_num_threads(4);start=time.time();data=np.load('sequence_data.npz');q=[torch.tensor(data[s+'_q'])for s in ['train','validation']];pv=json.loads(Path('sequence_bundle/program_vocabulary.json').read_text());wv=json.loads(Path('sequence_bundle/vocabulary.json').read_text());joined=dict(wv);mapping=[]
for token,i in sorted(pv.items(),key=lambda z:z[1]):
 if token=='<pad>':idx=0
 elif token.startswith('q')and token[1:].isdigit():idx=wv.get('num'+token[1:],1)
 else:
  name='PROGRAM:'+token
  if name not in joined:joined[name]=len(joined)
  idx=joined[name]
 mapping.append(idx)
mapping=np.array(mapping,dtype=np.int64);programs=[torch.tensor(mapping[data[s+'_programs']])for s in ['train','validation']];cp=np.load('candidate_profiles.npz');profiles=[torch.tensor(cp[s])for s in ['train','validation']];banks=[];xs=[];hs=[]
for j,split in enumerate(['train','validation']):
 b,a=load_inputs(split);banks.append(b);e,f=features(b,a);xs.append(np.concatenate([e,f,cp[split]],-1));hs.append(hard_mask(b))
mean=xs[0].mean((0,1));std=xs[0].std((0,1)).clip(.1);x=[torch.tensor(np.clip((z-mean)/std,-15,15))for z in xs];np.savez(p/'stats.npz',mean=mean,std=std,program_mapping=mapping);(p/'vocabulary.json').write_text(json.dumps(wv));(p/'program_vocabulary.json').write_text(json.dumps(pv));(p/'size.json').write_text(json.dumps(dict(words=len(joined))));y=torch.tensor(data['train_labels']);vy=data['validation_labels'];base=np.load('alignment_selected_validation_scores.npy');gp=np.load('gold_profiles.npz');target=torch.tensor(gp['profiles']);validref=torch.tensor(gp['valid']);weight=torch.tensor(np.where(hs[0],3.,.5),dtype=torch.float32);valid=np.array([[parse_answer(c['text'])is not None for c in r['candidates']]for r in banks[1]]);records=[]
for seed,auxiliary in [(2900,False),(2900,True),(2901,True)]:
 torch.manual_seed(seed);net=CrossProgramVerifier(len(joined),x[0].shape[-1]);opt=torch.optim.AdamW(net.parameters(),lr=.0003,weight_decay=.04);best=-1;name=f'cross_{int(auxiliary)}_{seed}'
 for epoch in range(40):
  net.train();perm=torch.randperm(len(y));ls=[]
  for ids in perm.split(24):
   score,op=net(x[0][ids],q[0][ids],programs[0][ids],profiles[0][ids]);t=y[ids];loss=torch.logsumexp(score,1)-torch.logsumexp(score.masked_fill(t==0,-1e4),1)+.25*torch.nn.functional.binary_cross_entropy_with_logits(score,t,reduction='none').mean(1);loss=(loss*weight[ids]).mean()
   if auxiliary and validref[ids].any():loss+=.1*torch.nn.functional.mse_loss(op[validref[ids]],target[ids][validref[ids]])
   opt.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(net.parameters(),3);opt.step();ls.append(float(loss))
  net.eval();outs=[]
  with torch.no_grad():
   for ids in torch.arange(len(q[1])).split(24):outs.append(net(x[1][ids],q[1][ids],programs[1][ids],profiles[1][ids])[0].numpy())
  lp=np.concatenate(outs);assert np.isfinite(lp).all();scale=max(float(np.mean([row[v].std()for row,v,hard in zip(lp,valid,hs[1])if hard])),.01);sc=aggregate(lp/scale,banks[1],.5);results=[]
  for w in [0,.1,.25,.5,1,2]:
   pp=(base+w*sc).argmax(1);v=vy[np.arange(len(pp)),pp];results.append(dict(weight=w,hard=float(v[hs[1]].mean()),all=float(v.mean())))
  bestrow=max(results,key=lambda r:r['hard']);alone=vy[np.arange(len(lp)),sc.argmax(1)][hs[1]].mean();criterion=bestrow['hard']+1e-5*alone
  if criterion>best:best=criterion;state={k:v.clone()for k,v in net.state_dict().items()};bp=lp.copy();br=bestrow;be=epoch;bs=scale
  if epoch%5==0:print(name,epoch,'loss',float(np.mean(ls)),'standalone',float(alone),'fusion',bestrow,flush=True)
 torch.save(state,p/f'{name}.pt');np.save(f'{name}_validation.npy',bp);r=dict(name=name,seed=seed,auxiliary=auxiliary,epoch=be,scale=bs,**br);records.append(r);print('BEST',r,flush=True);Path('cross_records.json').write_text(json.dumps(dict(records=records,seconds=time.time()-start),indent=2))
