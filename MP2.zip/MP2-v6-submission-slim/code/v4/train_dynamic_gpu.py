import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='4'
import json,time
from pathlib import Path
import numpy as np,torch
from common import load_inputs,parse_answer
from submission import features,aggregate
from rich_features import hard_mask
from dynamic_cross_model import DynamicCrossVerifier
from baseline_features import baseline_features
assert torch.cuda.is_available();device=torch.device('cuda:0');torch.set_num_threads(4);torch.backends.cuda.matmul.allow_tf32=False;start=time.time();p=Path('dynamic_gpu_bundle');p.mkdir(exist_ok=True);d=np.load('sequence_data.npz');q=[torch.tensor(d[s+'_q'],device=device)for s in ['train','validation']];pv=json.loads(Path('sequence_bundle/program_vocabulary.json').read_text());wv=json.loads(Path('sequence_bundle/vocabulary.json').read_text());joined=dict(wv);mapping=[]
for token,i in sorted(pv.items(),key=lambda z:z[1]):
 if token=='<pad>':idx=0
 elif token.startswith('q')and token[1:].isdigit():idx=wv.get('num'+token[1:],1)
 else:
  name='PROGRAM:'+token
  if name not in joined:joined[name]=len(joined)
  idx=joined[name]
 mapping.append(idx)
mapping=np.array(mapping,dtype=np.int64);programs=[torch.tensor(mapping[d[s+'_programs']],device=device)for s in ['train','validation']];cp=np.load('candidate_profiles.npz');profiles=[torch.tensor(cp[s],device=device)for s in ['train','validation']];base=[np.load('v3_oof_scores.npy').astype('float32'),np.load('alignment_selected_validation_scores.npy').astype('float32')];banks=[];raw=[];hs=[]
for j,split in enumerate(['train','validation']):
 b,a=load_inputs(split);banks.append(b);e,f=features(b,a);raw.append(np.concatenate([e,f,cp[split],baseline_features(b,base[j])],-1));hs.append(hard_mask(b))
mean=raw[0].mean((0,1));std=raw[0].std((0,1)).clip(.1);x=[torch.tensor(np.clip((a-mean)/std,-15,15),device=device)for a in raw];np.savez(p/'stats.npz',mean=mean,std=std,program_mapping=mapping);(p/'vocabulary.json').write_text(json.dumps(wv));(p/'program_vocabulary.json').write_text(json.dumps(pv));(p/'size.json').write_text(json.dumps(dict(words=len(joined))));y=torch.tensor(d['train_labels'],device=device);vy=d['validation_labels'];gp=np.load('gold_profiles.npz');target=torch.tensor(gp['profiles'],device=device);validref=torch.tensor(gp['valid'],device=device);weight=torch.tensor(np.where(hs[0],3.,.5),dtype=torch.float32,device=device);prior=torch.tensor(base[0],device=device);valid=np.array([[parse_answer(c['text'])is not None for c in row['candidates']]for row in banks[1]]);length=(q[0]!=0).sum(1).float()+(programs[0]!=0).sum(2).max(1).values*.5;records=[];print('GPU',torch.cuda.get_device_name(0),'data ready',flush=True)
singleton_mask=hs[1]&(vy.sum(1)==1);baseline_correct=vy[np.arange(len(vy)),base[1].argmax(1)];hard_floor=float(baseline_correct[hs[1]].mean())-1/int(hs[1].sum())-1e-6
configs=[(3100,64,False,False,False),(3101,96,True,False,False),(3102,96,True,True,False),(3103,128,True,True,False),(3104,96,True,True,True)]
for seed,dimension,auxiliary,residual,singleton_focus in configs:
 torch.manual_seed(seed);net=DynamicCrossVerifier(len(joined),x[0].shape[-1],dimension).to(device);opt=torch.optim.AdamW(net.parameters(),lr=.0003,weight_decay=.04);best=-1;sample_weight=weight*torch.where(y.sum(1)==1,4.,1.)if singleton_focus else weight;name=f'dynamic_d{dimension}_a{int(auxiliary)}_r{int(residual)}_s{int(singleton_focus)}_{seed}';print('START',name,'parameter_bytes',sum(t.numel()*t.element_size()for t in net.parameters()),flush=True)
 for epoch in range(45):
  net.train();order=torch.argsort(length+torch.rand(len(y),device=device)*16);batches=list(order.split(32));ls=[]
  for k in torch.randperm(len(batches)).tolist():
   ids=batches[k];delta,op=net(x[0][ids],q[0][ids],programs[0][ids],profiles[0][ids]);score=delta+prior[ids]if residual else delta;t=y[ids];loss=torch.logsumexp(score,1)-torch.logsumexp(score.masked_fill(t==0,-1e4),1)+.25*torch.nn.functional.binary_cross_entropy_with_logits(score,t,reduction='none').mean(1);loss=(loss*sample_weight[ids]).mean()
   if residual:loss+=.01*(delta**2).mean()
   if auxiliary and validref[ids].any():loss+=.1*torch.nn.functional.mse_loss(op[validref[ids]],target[ids][validref[ids]])
   opt.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(net.parameters(),3);opt.step();ls.append(float(loss))
  net.eval();outs=[]
  with torch.no_grad():
   for ids in torch.arange(len(q[1]),device=device).split(24):outs.append(net(x[1][ids],q[1][ids],programs[1][ids],profiles[1][ids])[0].cpu().numpy())
  lp=np.concatenate(outs);assert np.isfinite(lp).all();scale=max(float(np.mean([row[v].std()for row,v,hard in zip(lp,valid,hs[1])if hard])),.01);sc=aggregate(lp/scale,banks[1],.5);results=[]
  for w in [0,.1,.25,.5,1,2]:
   pred=(base[1]+w*sc).argmax(1);v=vy[np.arange(len(pred)),pred];results.append(dict(weight=w,hard=float(v[hs[1]].mean()),all=float(v.mean()),singleton=float(v[singleton_mask].mean())))
  eligible=[r for r in results if r['hard']>=hard_floor];br0=max(eligible,key=lambda a:(a['singleton'],a['hard'],a['all']));alone=float(vy[np.arange(len(lp)),sc.argmax(1)][hs[1]].mean());criterion=br0['singleton']+1e-3*br0['hard']+1e-6*alone
  if criterion>best:best=criterion;state={k:v.detach().cpu().clone()for k,v in net.state_dict().items()};bp=lp.copy();be=epoch;br=br0;bs=scale
  if epoch%5==0:print(name,epoch,'loss',float(np.mean(ls)),'alone',alone,'bestfusion',br0,'seconds',round(time.time()-start,1),flush=True)
 torch.save(state,p/f'{name}.pt');np.save(f'{name}_validation.npy',bp);r=dict(name=name,seed=seed,dimension=dimension,auxiliary=auxiliary,residual=residual,singleton_focus=singleton_focus,epoch=be,scale=bs,**br);records.append(r);print('BEST',r,flush=True);Path('dynamic_gpu_records.json').write_text(json.dumps(dict(records=records,seconds=time.time()-start,training_device=torch.cuda.get_device_name(0),peak_gpu_bytes=torch.cuda.max_memory_allocated(),torch_version=torch.__version__),indent=2))
