import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import json
from pathlib import Path
import numpy as np
from fractions import Fraction
from common import load_inputs,read_jsonl,DATA,parse_answer
from semantic_experts import experts
from rich_features import hard_mask
rows=[];labels=[];banks=[]
for split in ['train','validation']:
 b,_=load_inputs(split);g=read_jsonl(DATA/f'gsm8k_{split}.jsonl');banks.append(b);ys=[];pred=[]
 for r,q in zip(b,g):
  gold=float(Fraction(parse_answer(q['answer'])));av=[float(Fraction(a))if(a:=parse_answer(c['text']))is not None else None for c in r['candidates']];rules=experts(r['question']);pred.append((rules,av,gold));ys.append([a is not None and abs(a-gold)<1e-5*(1+abs(gold))for a in av])
 rows.append(pred);labels.append(np.array(ys))
stats={}
for rules,avs,gold in rows[0]:
 for name,n in rules.items():
  s=stats.setdefault(name,dict(total=0,present=0,correct=0));s['total']+=1
  if any(a is not None and abs(a-n)<1e-5*(1+abs(n))for a in avs):s['present']+=1;s['correct']+=int(abs(n-gold)<1e-5*(1+abs(gold)))
accepted={name:np.log((s['correct']+1)/(s['present']-s['correct']+1))for name,s in stats.items()if s['present']>=3 and(s['correct']+1)/(s['present']+2)>=.75};base=np.load('base_validation_scores.npy');evidence=np.zeros_like(base)
for j,(rules,avs,gold)in enumerate(rows[1]):
 for name,n in rules.items():
  if name not in accepted:continue
  for i,a in enumerate(avs):
   if a is not None and abs(a-n)<1e-5*(1+abs(n)):evidence[j,i]+=accepted[name]
h=hard_mask(banks[1]);results=[]
for w in [0,.1,.25,.5,1,2,4]:
 pp=(base+w*evidence).argmax(1);v=labels[1][np.arange(len(pp)),pp];results.append(dict(weight=w,hard=float(v[h].mean()),all=float(v.mean())))
print('TRAIN',json.dumps(stats,indent=2));print('ACCEPTED',accepted);print('VALIDATION',results);Path('expert_records.json').write_text(json.dumps(dict(training=stats,accepted=accepted,validation=results),indent=2));np.save('expert_validation.npy',evidence)
