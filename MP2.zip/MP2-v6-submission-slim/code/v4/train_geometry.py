import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='4'
import json,time
from pathlib import Path
import numpy as np
from sklearn.decomposition import PCA
from catboost import CatBoostRanker,Pool
from common import load_inputs,read_jsonl,DATA,parse_answer
from rich_features import rich_features,hard_mask
from submission import aggregate
from baseline_features import baseline_features
from relational_evidence import relational_evidence
start=time.time();p=Path('geometry_bundle');p.mkdir(exist_ok=True);banks=[];es=[];fs=[];hs=[];ys=[];base=[np.load('v3_oof_scores.npy'),np.load('complementary_validation_scores.npy')];cp=np.load('candidate_profiles.npz');arrays=[]
for split in ['train','validation']:
 b,a=load_inputs(split);arrays.append(a);banks.append(b);e,f=rich_features(b,a);es.append(e);fs.append(f);hs.append(hard_mask(b));g=read_jsonl(DATA/f'gsm8k_{split}.jsonl');ys.append(np.array([[parse_answer(c['text'])is not None and parse_answer(c['text'])==parse_answer(q['answer'])for c in r['candidates']]for r,q in zip(b,g)],dtype='float32'))
delta=es[0]-es[0].mean(1,keepdims=True);pca=PCA(64,random_state=4100).fit(delta.reshape(-1,1024));np.savez(p/'pca.npz',mean=pca.mean_,components=pca.components_);xx=[];priors=[]
for j in range(2):
 e=es[j];f=fs[j];pc=pca.transform((e-e.mean(1,keepdims=True)).reshape(-1,1024)).reshape(-1,4,64);bf=baseline_features(banks[j],base[j]);xx.append(np.round(np.concatenate([bf,cp[['train','validation'][j]],f,f-f.mean(1,keepdims=True),pc,relational_evidence(banks[j],arrays[j],base[j])],-1),4));priors.append(bf[:,:,0])
fusionbase=base[1]+.25*aggregate(np.load('semantic_residual4103_validation.npy')/1.01424206344237,banks[1],.5);single=hs[1]&(ys[1].sum(1)==1);records=[];valid=np.array([[parse_answer(c['text'])is not None for c in row['candidates']]for row in banks[1]])
for seed,depth,baseline_strength,focus in [(4400,4,0.,3),(4401,5,0.,3),(4402,5,1.,3),(4403,6,0.,3)]:
 mask=hs[0];weight=np.where(ys[0][mask].sum(1)==1,float(focus),1.);train=Pool(data=xx[0][mask].reshape(-1,xx[0].shape[-1]),label=ys[0][mask].flatten(),baseline=(baseline_strength*priors[0][mask]).flatten(),group_id=np.repeat(np.arange(mask.sum()),4),group_weight=np.repeat(weight,4),thread_count=4);model=CatBoostRanker(iterations=250,depth=depth,learning_rate=.025,l2_leaf_reg=30,thread_count=4,random_seed=seed,border_count=32,loss_function='PairLogit',allow_writing_files=False,task_type='GPU',devices='0');model.fit(train,verbose=200);best=(-1,-1);name=f'geometry{seed}'
 for trees in [125,250]:
  lp=model.predict(xx[1].reshape(-1,xx[1].shape[-1]),ntree_end=trees).reshape(-1,4);scale=max(float(np.mean([r[v].std()for r,v,h in zip(lp,valid,hs[1])if h])),.01);sc=aggregate(lp/scale,banks[1],.5)
  for w in [0,.1,.25,.5,1,2]:
   v=ys[1][np.arange(len(base[1])),(fusionbase+w*sc).argmax(1)];hard=float(v[hs[1]].mean());si=float(v[single].mean());criterion=(si,hard)
   if hard>=319/355-1e-6 and criterion>best:best=criterion;bt=trees;bw=w;bs=scale;bp=lp.copy();ba=float(v.mean())
 model.shrink(bt);model.save_model(str(p/(name+'.cbm')));np.save(name+'_validation.npy',bp);r=dict(name=name,seed=seed,depth=depth,baseline_strength=baseline_strength,singleton_focus=focus,trees=bt,weight=bw,scale=bs,singleton=best[0],hard=best[1],all=ba);records.append(r);Path('geometry_records.json').write_text(json.dumps(dict(records=records,seconds=time.time()-start,device='RTX 3060 Laptop GPU'),indent=2));print('BEST',r,flush=True)
