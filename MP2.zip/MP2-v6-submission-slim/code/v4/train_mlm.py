import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='4'
import json,time
from pathlib import Path
import numpy as np,torch
from torch import nn
from dynamic_cross_model import DynamicCrossVerifier
assert torch.cuda.is_available();torch.set_num_threads(4);device=torch.device('cuda:0');torch.manual_seed(3600);start=time.time();p=Path('mlm_bundle');cfg=json.loads((p/'size.json').read_text());d=np.load('mlm_data.npz');q=torch.tensor(d['words'],dtype=torch.long,device=device);programs=torch.tensor(d['programs'],dtype=torch.long,device=device);index=torch.tensor(d['target_idx'],dtype=torch.long,device=device);targets=torch.tensor(d['targets'],device=device);net=DynamicCrossVerifier(cfg['words'],1082,96).to(device);
with torch.no_grad():
 nn.init.normal_(net.word.weight,std=.02);net.word.weight[0].zero_();nn.init.normal_(net.position.weight,std=.02);nn.init.normal_(net.kind.weight,std=.02)
distill=nn.Linear(96,1024).to(device);opt=torch.optim.AdamW(list(net.parameters())+list(distill.parameters()),lr=.001,weight_decay=.01);records=[];length=(q!=0).sum(1).float()+(programs!=0).sum(1)*.5
for epoch in range(8):
 net.train();order=torch.argsort(length+torch.rand(len(q),device=device)*16);batches=list(order.split(96));losses=[]
 for k in torch.randperm(len(batches)).tolist():
  ids=batches[k];qq=q[ids];pp=programs[ids];ql=max(1,int((qq!=0).sum(1).max()));pl=max(1,int((pp!=0).sum(1).max()));qq=qq[:,:ql];pp=pp[:,:pl];original=torch.cat([qq,pp],1);mask=(torch.rand(original.shape,device=device)<.15)&(original!=0)&(original!=1)&(original!=cfg['program_mapping'][1])&(original!=cfg['program_mapping'][2]);masked=original.clone();chance=torch.rand(original.shape,device=device);masked[mask&(chance<.8)]=cfg['mask_id'];randommask=mask&(chance>=.8)&(chance<.9);masked[randommask]=torch.randint(2,4000,(int(randommask.sum()),),device=device);h=torch.cat([net.cls(torch.zeros((len(ids),1082),device=device))[:,None,:],net.word(masked)],1);pos=torch.cat([torch.zeros(1,dtype=torch.long,device=device),torch.arange(1,ql+1,device=device),torch.arange(129,129+pl,device=device)]);kind=torch.cat([torch.full((1,),2,dtype=torch.long,device=device),torch.zeros(ql,dtype=torch.long,device=device),torch.ones(pl,dtype=torch.long,device=device)]);h=h+net.position(pos)[None]+net.kind(kind)[None];padding=torch.cat([torch.zeros((len(ids),1),dtype=torch.bool,device=device),original==0],1);encoded=net.context(h,src_key_padding_mask=padding);selected=nn.functional.layer_norm(encoded[:,1:][mask],(96,));logits=nn.functional.linear(selected,net.word.weight);logits[:,0]=-1e4;mlm=nn.functional.cross_entropy(logits,original[mask])if mask.any()else encoded.sum()*0;mse=nn.functional.mse_loss(distill(encoded[:,0]),targets[index[ids]]);loss=mlm+.2*mse;opt.zero_grad();loss.backward();nn.utils.clip_grad_norm_(list(net.parameters())+list(distill.parameters()),3);opt.step();losses.append((float(mlm.detach()),float(mse.detach())))
 torch.save({k:v.detach().cpu().clone()for k,v in net.state_dict().items()},p/'language.pt');records.append(dict(epoch=epoch,mlm_loss=float(np.mean([v[0]for v in losses])),teacher_mse=float(np.mean([v[1]for v in losses])),seconds=time.time()-start));Path('mlm_records.json').write_text(json.dumps(dict(records=records,device=torch.cuda.get_device_name(0),peak_gpu_bytes=torch.cuda.max_memory_allocated(),seed=3600),indent=2));print(records[-1],flush=True)
