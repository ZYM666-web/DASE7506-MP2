import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='4'
import json,time
from pathlib import Path
import numpy as np
from catboost import CatBoostRanker,Pool
from common import load_inputs,read_jsonl,DATA,parse_answer
from rich_features import rich_features,hard_mask
from submission import aggregate
from operation_profiles import meta_features
from verify_arithmetic import arithmetic_evidence
p=Path('profile_bundle');start=time.time();old=Path('../runs/v2');base=np.load('base_validation_scores.npy');profiles=np.load('expected_profiles.npz');candidates=np.load('candidate_profiles.npz');bs=[];ys=[];hs=[];xs=[];prior=[]
for j,split in enumerate(['train','validation']):
 b,a=load_inputs(split);bs.append(b);hs.append(hard_mask(b));e,f=rich_features(b,a);s=np.load(old/('oof_stack_train.npy'if j==0 else'finalval_raw.npy'));s=s-s.mean(1,keepdims=True);s=s/s.std(1,keepdims=True).clip(.05);prior.append(s);vf=arithmetic_evidence(b);prof=meta_features(profiles[split],candidates[split]);x=np.concatenate([s[:,:,None],vf,f,f-f.mean(1,keepdims=True),prof],-1);xs.append(np.round(x,4).reshape(len(b)*4,-1));g=read_jsonl(DATA/f'gsm8k_{split}.jsonl');ys.append(np.array([[parse_answer(c['text'])is not None and parse_answer(c['text'])==parse_answer(q['answer'])for c in r['candidates']]for r,q in zip(b,g)],dtype=np.float32));print('ready',split,xs[-1].shape,flush=True)
tr=np.repeat(hs[0],4);train=Pool(data=xs[0][tr],label=ys[0][hs[0]].flatten(),group_id=np.repeat(np.arange(hs[0].sum()),4),thread_count=4);val=Pool(data=xs[1],label=ys[1].flatten(),group_id=np.repeat(np.arange(len(bs[1])),4),thread_count=4);records=[];searches=[]
for seed,depth in [(2100,4),(2101,5),(2102,6)]:
 model=CatBoostRanker(iterations=1800,depth=depth,learning_rate=.025,l2_leaf_reg=20,thread_count=4,random_seed=seed,border_count=32,loss_function='YetiRank',eval_metric='NDCG:top=1',allow_writing_files=False)
 model.fit(train,eval_set=val,verbose=400,use_best_model=False);best=-1
 for nt in range(50,model.tree_count_+1,25):
  lp=model.predict(xs[1],ntree_end=nt,thread_count=4).reshape(-1,4);lp=aggregate(lp,bs[1],.5);scale=max(float(np.mean([row[[parse_answer(c['text'])is not None for c in question['candidates']]].std()for row,question,hard in zip(lp,bs[1],hs[1])if hard])),.01)
  for weight in [0,.1,.25,.5,1,2]:
   pp=(base+weight*lp/scale).argmax(1);v=ys[1][np.arange(len(pp)),pp];acc=float(v[hs[1]].mean());searches.append(dict(seed=seed,trees=nt,weight=weight,hard=acc,all=float(v.mean())))
   if acc>best:best=acc;bp=lp.copy();bn=nt;bw=weight;bscl=scale;allacc=float(v.mean())
 model.shrink(bn);model.save_model(str(p/f'profile_rank{seed}.cbm'));np.save(f'profile_rank{seed}_validation.npy',bp);r=dict(seed=seed,depth=depth,trees=bn,weight=bw,scale=bscl,hard=best,all=allacc);records.append(r);print('BEST',r,flush=True);Path('profile_rank_records.json').write_text(json.dumps(dict(records=records,seconds=time.time()-start),indent=2));Path('profile_rank_search.json').write_text(json.dumps(searches,indent=2))

