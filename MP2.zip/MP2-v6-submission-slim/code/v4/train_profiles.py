import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='4'
from pathlib import Path
import json,time
import numpy as np
from scipy.sparse import hstack,csr_matrix
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import Ridge
from sklearn.model_selection import KFold
from common import load_inputs,read_jsonl,DATA
from programs import question_values
from operation_profiles import reference_profiles,candidate_profiles
p=Path('profile_bundle');p.mkdir(exist_ok=True);start=time.time();b=[];raw=[];texts=[]
for split in ['train','validation']:
 bank,a=load_inputs(split);b.append(bank);raw.append(a['embeddings'].mean(1));texts.append([question_values(r['question'])[1]for r in bank])
y,valid=reference_profiles(read_jsonl(DATA/'gsm8k_train.jsonl'));np.savez('gold_profiles.npz',profiles=y,valid=valid);c=[candidate_profiles(rows)for rows in b];np.savez('candidate_profiles.npz',train=c[0],validation=c[1]);print('profile coverage',valid.sum(),[(v[:,:,29]>0).mean()for v in c],flush=True)
vec=TfidfVectorizer(max_features=3000,ngram_range=(1,2),sublinear_tf=True);q=[vec.fit_transform(texts[0]),vec.transform(texts[1])];em=raw[0].mean(0);sd=raw[0].std(0).clip(.1);x=[hstack([qq*5,csr_matrix((ee-em)/sd)],format='csr')for qq,ee in zip(q,raw)];oof=np.zeros_like(y)
for fold,(tr,ho)in enumerate(KFold(4,shuffle=True,random_state=2000).split(np.arange(len(y)))):
 model=Ridge(alpha=30,solver='lsqr',tol=.001,max_iter=150);model.fit(x[0][tr[valid[tr]]],y[tr[valid[tr]]]);oof[ho]=model.predict(x[0][ho]);print('fold',fold,flush=True)
model=Ridge(alpha=30,solver='lsqr',tol=.001,max_iter=150);model.fit(x[0][valid],y[valid]);vp=model.predict(x[1]);np.savez(p/'profile_model.npz',coef=model.coef_.astype('float32'),intercept=model.intercept_.astype('float32'),embedding_mean=em,embedding_std=sd,idf=vec.idf_.astype('float32'));(p/'vocabulary.json').write_text(json.dumps({k:int(v)for k,v in vec.vocabulary_.items()}));np.savez('expected_profiles.npz',train=oof,validation=vp);Path('profile_records.json').write_text(json.dumps(dict(reference_coverage=int(valid.sum()),candidate_coverage=[float((v[:,:,29]>0).mean())for v in c],seconds=time.time()-start,seed=2000,ridge_alpha=30,folds=4),indent=2));print('DONE',flush=True)
