import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='4'
import itertools,json,time
from pathlib import Path
import numpy as np,torch
from sklearn.model_selection import StratifiedKFold
from common import load_inputs,read_jsonl,DATA,parse_answer
from submission import aggregate
from rich_features import hard_mask
from quality_features import prepare,fit_transform,transform
from quality_model import QualityNet
assert torch.cuda.is_available();device=torch.device('cuda:0');torch.set_num_threads(4);start=time.time();p=Path('quality_bundle');p.mkdir(exist_ok=True);bank,arrays=load_inputs('train');raw=prepare(bank,arrays);gold=read_jsonl(DATA/'gsm8k_train.jsonl');yy=np.array([[parse_answer(c['text'])is not None and parse_answer(c['text'])==parse_answer(q['answer'])for c in r['candidates']]for r,q in zip(bank,gold)],dtype=np.float32);hard=hard_mask(bank);hard_ids=np.where(hard)[0];splits=list(StratifiedKFold(4,shuffle=True,random_state=3400).split(hard_ids,yy[hard_ids].sum(1)));epochs=[5,10,20,40,60];configs=list(itertools.product([False,True],[16,64],[.3,3.],['bce','mass']));results=[]

def objective(s,y,v,kind):
 pos=-(torch.nn.functional.logsigmoid(s)*y).sum(1)/y.sum(1).clamp(min=1);neg=-(torch.nn.functional.logsigmoid(-s)*(v-y)).sum(1)/(v-y).sum(1).clamp(min=1);bce=(pos+neg)/2
 if kind=='mass':loss=torch.logsumexp(s.masked_fill(~v.bool(),-1e4),1)-torch.logsumexp(s.masked_fill(y==0,-1e4),1)+.2*bce
 else:loss=bce
 return (loss*torch.where(y.sum(1)==1,2.,1.)).mean()

for ci,(quadratic,hidden,decay,kind)in enumerate(configs):
 predictions={ep:np.zeros((len(bank),4),dtype=np.float32)for ep in epochs}
 for fold,(tr0,ho0)in enumerate(splits):
  tr,ho=hard_ids[tr0],hard_ids[ho0];z=fit_transform(raw,tr,quadratic);xx=torch.tensor(transform(raw,z),device=device);vv=torch.tensor(raw[3],device=device);y=torch.tensor(yy,device=device);torch.manual_seed(3400+fold);net=QualityNet(xx.shape[-1],hidden).to(device);opt=torch.optim.AdamW(net.parameters(),lr=.001,weight_decay=decay);tt=torch.tensor(tr,device=device);hh=torch.tensor(ho,device=device)
  for ep in range(1,61):
   net.train();perm=tt[torch.randperm(len(tt),device=device)]
   for ids in perm.split(128):
    s=net(xx[ids],vv[ids]);loss=objective(s,y[ids],vv[ids].float(),kind);opt.zero_grad();loss.backward();opt.step()
   if ep in epochs:
    net.eval()
    with torch.no_grad():predictions[ep][ho]=net(xx[hh],vv[hh]).cpu().numpy()
 for ep,lp in predictions.items():
  rows=[bank[i]for i in hard_ids];pp=aggregate(lp[hard_ids],rows,.5).argmax(1);correct=yy[hard_ids][np.arange(len(pp)),pp];single=yy[hard_ids].sum(1)==1;results.append(dict(quadratic=quadratic,hidden=hidden,weight_decay=decay,loss=kind,epochs=ep,hard=float(correct.mean()),singleton=float(correct[single].mean())))
 print('CV',ci,'/',len(configs),max(results[-len(epochs):],key=lambda r:(r['singleton'],r['hard'])),round(time.time()-start,1),'s',flush=True);Path('quality_cv.json').write_text(json.dumps(dict(records=results,seed=3400,folds=4,seconds=time.time()-start),indent=2))
chosen=max(results,key=lambda r:(r['singleton'],r['hard'],-r['hidden']));print('CV CHOSEN',chosen,flush=True);z=fit_transform(raw,hard_ids,chosen['quadratic']);np.savez(p/'stats.npz',**z);xx=torch.tensor(transform(raw,z),device=device);vv=torch.tensor(raw[3],device=device);y=torch.tensor(yy,device=device);vb,va=load_inputs('validation');vraw=prepare(vb,va);vx=torch.tensor(transform(vraw,z),device=device);vm=torch.tensor(vraw[3],device=device);tt=torch.tensor(hard_ids,device=device);members=[]
for seed in [3500,3501,3502,3503]:
 torch.manual_seed(seed);net=QualityNet(xx.shape[-1],chosen['hidden']).to(device);opt=torch.optim.AdamW(net.parameters(),lr=.001,weight_decay=chosen['weight_decay'])
 for ep in range(chosen['epochs']):
  net.train();perm=tt[torch.randperm(len(tt),device=device)]
  for ids in perm.split(128):
   s=net(xx[ids],vv[ids]);loss=objective(s,y[ids],vv[ids].float(),chosen['loss']);opt.zero_grad();loss.backward();opt.step()
 net.eval()
 with torch.no_grad():lp=net(vx,vm).cpu().numpy()
 name=f'quality{seed}.pt';torch.save({k:v.detach().cpu()for k,v in net.state_dict().items()},p/name);np.save(f'quality{seed}_validation.npy',lp);members.append(name);print('FULL',seed,flush=True)
(p/'config.json').write_text(json.dumps(dict(chosen=chosen,models=members,seed=3400,training_device=torch.cuda.get_device_name(0),peak_gpu_bytes=torch.cuda.max_memory_allocated(),seconds=time.time()-start),indent=2))
