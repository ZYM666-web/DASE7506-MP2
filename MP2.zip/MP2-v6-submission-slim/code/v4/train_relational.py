import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='4'
import json,time
from pathlib import Path
import numpy as np,torch
from common import load_inputs,read_jsonl,DATA,parse_answer
from rich_features import hard_mask
from submission import aggregate
from quality_features import prepare,fit_transform,transform
from relational_model import RelationalVerifier
torch.set_num_threads(4);assert torch.cuda.is_available();device='cuda';p=Path('relational_bundle');p.mkdir(exist_ok=True);start=time.time();banks=[];raw=[];hs=[];ys=[]
for split in ['train','validation']:
 b,a=load_inputs(split);banks.append(b);raw.append(prepare(b,a));hs.append(hard_mask(b));g=read_jsonl(DATA/f'gsm8k_{split}.jsonl');ys.append(np.array([[parse_answer(c['text'])is not None and parse_answer(c['text'])==parse_answer(q['answer'])for c in r['candidates']]for r,q in zip(b,g)],dtype='float32'))
z=fit_transform(raw[0],np.where(hs[0])[0],False);np.savez(p/'stats.npz',**z);x=[torch.tensor(transform(r,z),device=device)for r in raw];valid=[torch.tensor(r[-1],device=device)for r in raw];y=torch.tensor(ys[0],device=device);base=np.load('alignment_selected_validation_scores.npy');single=hs[1]&(ys[1].sum(1)==1);trainids=np.where(hs[0])[0];records=[]
for seed,hid,focus,lossname,decay in [(3800,64,1,'pair',.1),(3801,64,3,'pair',.1),(3802,64,1,'mass',.1),(3803,64,3,'mass',.1),(3804,128,1,'pair',.1),(3805,128,3,'pair',.1),(3806,64,1,'pair',1.),(3807,64,3,'pair',1.)]:
 torch.manual_seed(seed);net=RelationalVerifier(x[0].shape[-1],hid).to(device);opt=torch.optim.AdamW(net.parameters(),lr=.0004,weight_decay=decay);best=(-1,-1);name=f'relational_{seed}';print('START',name,flush=True)
 for ep in range(60):
  net.train();ids=torch.tensor(trainids,device=device);ids=ids[torch.randperm(len(ids),device=device)]
  for ii in ids.split(96):
   s=net(x[0][ii],valid[0][ii]);t=y[ii];vv=valid[0][ii];s=s.masked_fill(~vv,-1e4)
   if lossname=='pair':
    pm=t[:,:,None]*(1-t[:,None,:])*vv[:,None,:];loss=(torch.nn.functional.softplus(1-s[:,:,None]+s[:,None,:])*pm).sum((1,2))/pm.sum((1,2)).clamp(min=1)
   else:loss=torch.logsumexp(s,1)-torch.logsumexp(s.masked_fill(t==0,-1e4),1)
   weight=torch.where(t.sum(1)==1,float(focus),1.);loss=(loss*weight).mean();opt.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(net.parameters(),3);opt.step()
  net.eval()
  with torch.no_grad():lp=torch.cat([net(x[1][ii],valid[1][ii])for ii in torch.arange(len(x[1]),device=device).split(128)]).cpu().numpy()
  scale=max(float(np.mean([s[v].std()for s,v,h in zip(lp,raw[1][-1],hs[1])if h])),.01);sc=aggregate(lp/scale,banks[1],.5);res=[]
  for w in [0,.1,.25,.5,1,2]:
   v=ys[1][np.arange(len(base)),(base+w*sc).argmax(1)];res.append(dict(weight=w,hard=float(v[hs[1]].mean()),singleton=float(v[single].mean()),all=float(v.mean())))
  eligible=[r for r in res if r['hard']>=319/355-1e-6];br=max(eligible,key=lambda r:(r['singleton'],r['hard'],r['all']));criterion=(br['singleton'],br['hard']);alone=float(ys[1][np.arange(len(base)),sc.argmax(1)][hs[1]].mean())
  if criterion>best:best=criterion;state={k:v.detach().cpu().clone()for k,v in net.state_dict().items()};bp=lp.copy();bs=scale;be=ep;bresult=br
  if ep%20==0:print(name,ep,br,'alone',alone,'seconds',round(time.time()-start,1),flush=True)
 torch.save(state,p/f'{name}.pt');np.save(f'{name}_validation.npy',bp);r=dict(name=name,seed=seed,hidden=hid,focus=focus,loss=lossname,decay=decay,epoch=be,scale=bs,**bresult);records.append(r);Path('relational_records.json').write_text(json.dumps(dict(records=records,seconds=time.time()-start),indent=2));print('BEST',r,flush=True)
