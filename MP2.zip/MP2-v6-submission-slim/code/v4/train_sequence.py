import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='4'
import json,time
from pathlib import Path
import numpy as np,torch
from common import load_inputs,parse_answer
from rich_features import hard_mask
from sequence_model import SequenceVerifier
p=Path('sequence_bundle');torch.set_num_threads(4);start=time.time();d=np.load('sequence_data.npz');q=torch.tensor(d['train_q']);gold=torch.tensor(d['train_gold']);programs=torch.tensor(d['train_programs']);y=torch.tensor(d['train_labels']);vq=torch.tensor(d['validation_q']);vp=torch.tensor(d['validation_programs']);vy=d['validation_labels'];base=np.load('base_validation_scores.npy');b,_=load_inputs('validation');h=hard_mask(b);has=vp[:,:,0].numpy()!=0;can_compare=np.array([len(set(parse_answer(c['text'])for c,ok in zip(row['candidates'],available)if ok))>=2 for row,available in zip(b,has)]);valid_train=(gold[:,0]!=0).nonzero().flatten();torch.manual_seed(2700);net=SequenceVerifier(len(json.loads((p/'vocabulary.json').read_text())),len(json.loads((p/'program_vocabulary.json').read_text())));opt=torch.optim.AdamW(net.parameters(),lr=.0006,weight_decay=.02);records=[];best=-1
for epoch in range(35):
 net.train();order=valid_train[torch.randperm(len(valid_train))];losses=[]
 for ids in order.split(48):
  out=net(q[ids],gold[ids]);target=gold[ids,1:];loss=torch.nn.functional.cross_entropy(out.reshape(-1,out.shape[-1]),target.reshape(-1),ignore_index=0);opt.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(net.parameters(),2);opt.step();losses.append(float(loss))
 if epoch>=15:
  order=torch.randperm(len(q))
  for ids in order.split(32):
   available=programs[ids,:,0]!=0;good=y[ids]*available;usable=(good.sum(1)>0)&((available.sum(1)-good.sum(1))>0)
   if not usable.any():continue
   ids=ids[usable];available=programs[ids,:,0]!=0;score=net.scores(q[ids],programs[ids]);target=y[ids]*available;score=(score*8).masked_fill(~available,-1e4);loss=-(score.log_softmax(1)*target/target.sum(1,keepdim=True)).sum(1).mean();opt.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(net.parameters(),2);opt.step()
 net.eval();scores=[]
 with torch.no_grad():
  for ids in torch.arange(len(vq)).split(32):scores.append(net.scores(vq[ids],vp[ids]).numpy())
 sc=np.concatenate(scores);assert np.isfinite(sc).all();center=(sc*has).sum(1,keepdims=True)/has.sum(1,keepdims=True).clip(1);sc=(sc-center)*has;sc[~can_compare]=0;results=[]
 for weight in [0,.1,.25,.5,1,2,4]:
  pp=(base+weight*sc).argmax(1);v=vy[np.arange(len(pp)),pp];results.append(dict(weight=weight,hard=float(v[h].mean()),all=float(v.mean())))
 r=max(results,key=lambda z:z['hard']);records.append(dict(epoch=epoch,loss=float(np.mean(losses)),seconds=time.time()-start,**r));print(records[-1],flush=True)
 if r['hard']>best:best=r['hard'];torch.save(net.state_dict(),p/'sequence.pt');np.save('sequence_validation.npy',sc);(p/'selection.json').write_text(json.dumps(dict(epoch=epoch,**r),indent=2))
 Path('sequence_records.json').write_text(json.dumps(records,indent=2))
