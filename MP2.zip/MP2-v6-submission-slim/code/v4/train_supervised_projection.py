import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='4'
import json,time
from pathlib import Path
import numpy as np
from sklearn.cross_decomposition import PLSRegression
from catboost import CatBoostRanker,Pool
from common import load_inputs,read_jsonl,DATA,parse_answer
from rich_features import rich_features,hard_mask
from submission import aggregate
from baseline_features import baseline_features
p=Path('supervised_projection_bundle');p.mkdir(exist_ok=True);start=time.time();banks=[];es=[];fs=[];hs=[];ys=[];valid=[];base=[np.load('v3_oof_scores.npy'),np.load('complementary_validation_scores.npy')];cp=np.load('candidate_profiles.npz')
for split in ['train','validation']:
 b,a=load_inputs(split);banks.append(b);e,f=rich_features(b,a);es.append(e);fs.append(f);hs.append(hard_mask(b));valid.append(np.array([[parse_answer(c['text'])is not None for c in row['candidates']]for row in b]));g=read_jsonl(DATA/f'gsm8k_{split}.jsonl');ys.append(np.array([[parse_answer(c['text'])is not None and parse_answer(c['text'])==parse_answer(q['answer'])for c in r['candidates']]for r,q in zip(b,g)],dtype='float32'))
delta=[e-e.mean(1,keepdims=True)for e in es];mask=hs[0][:,None]&valid[0];target=ys[0]-(ys[0]*valid[0]).sum(1,keepdims=True)/valid[0].sum(1,keepdims=True);pls=PLSRegression(n_components=32);pls.fit(delta[0][mask],target[mask]);np.savez(p/'projection.npz',mean=pls._x_mean,std=pls._x_std,rotation=pls.x_rotations_);xx=[]
for j in range(2):
 e=es[j];f=fs[j];pr=pls.transform(delta[j].reshape(-1,1024)).reshape(-1,4,32);bf=baseline_features(banks[j],base[j]);xx.append(np.round(np.concatenate([bf,cp[['train','validation'][j]],f,f-f.mean(1,keepdims=True),pr],-1),4))
single=hs[1]&(ys[1].sum(1)==1);records=[]
for seed,dimension,lossname in [(4300,16,'PairLogit'),(4301,32,'PairLogit'),(4302,16,'YetiRank'),(4303,32,'YetiRank')]:
 sx=[a[:,:,:446+dimension]for a in xx];mask=hs[0];weights=np.where(ys[0][mask].sum(1)==1,3.,1.);pool=Pool(data=sx[0][mask].reshape(-1,sx[0].shape[-1]),label=ys[0][mask].flatten(),group_id=np.repeat(np.arange(mask.sum()),4),group_weight=np.repeat(weights,4),thread_count=4);net=CatBoostRanker(iterations=125,depth=5,learning_rate=.025,l2_leaf_reg=30,thread_count=4,random_seed=seed,border_count=32,loss_function=lossname,allow_writing_files=False,task_type='GPU',devices='0');net.fit(pool,verbose=False);lp=net.predict(sx[1].reshape(-1,sx[1].shape[-1]),thread_count=4).reshape(-1,4);scale=max(float(np.mean([r[v].std()for r,v,h in zip(lp,valid[1],hs[1])if h])),.01);sc=aggregate(lp/scale,banks[1],.5);results=[]
 for w in [0,.1,.25,.5,1,2]:
  v=ys[1][np.arange(len(base[1])),(base[1]+w*sc).argmax(1)];results.append(dict(weight=w,hard=float(v[hs[1]].mean()),singleton=float(v[single].mean()),all=float(v.mean())))
 best=max([r for r in results if r['hard']>=319/355-1e-6],key=lambda r:(r['singleton'],r['hard'],r['all'],-r['weight']));name=f'pls{dimension}_{lossname}_{seed}';net.save_model(str(p/(name+'.cbm')));np.save(name+'_validation.npy',lp);r=dict(name=name,dimension=dimension,seed=seed,loss=lossname,scale=scale,**best);records.append(r);Path('supervised_projection_records.json').write_text(json.dumps(dict(records=records,seconds=time.time()-start,projection='PLS32 fit train hard valid candidates only; no validation fitting'),indent=2));print(r,flush=True)
