import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from pathlib import Path
p=Path('train_sequence_memory.py');s=p.read_text(encoding='utf-8-sig');s=s.replace("base=np.load('base_validation_scores.npy')","base=np.load('alignment_selected_validation_scores.npy')");s=s.replace("for epoch in range(35):", "answer_values=[[parse_answer(c['text'])for c in row['candidates']]for row in b]\nbase_gap=[]\nfor values,row in zip(answer_values,base):\n groups={}\n for value,score in zip(values,row):\n  if value is not None:groups[value]=max(groups.get(value,-1e9),float(score))\n ranked=sorted(groups.values(),reverse=True);base_gap.append(ranked[0]-ranked[1]if len(ranked)>1 else 1e9)\nbase_gap=np.array(base_gap)\nfor epoch in range(35):")
start=s.index('results=[]\n for weight in');end=s.index(" r=max(results",start)
replacement="""results=[]
 critic_gap=[]
 for values,row,available in zip(answer_values,sc,has):
  groups={}
  for value,score,ok in zip(values,row,available):
   if ok and value is not None:groups[value]=max(groups.get(value,-1e9),float(score))
  ranked=sorted(groups.values(),reverse=True);critic_gap.append(ranked[0]-ranked[1]if len(ranked)>1 else 0.)
 critic_gap=np.array(critic_gap)
 for mode in ['raw','guarded']:
  delta=sc.copy()
  if mode=='guarded':
   delta/=np.sqrt((delta**2).sum(1,keepdims=True)/has.sum(1,keepdims=True).clip(1)).clip(.05);delta[~((base_gap<1)&(critic_gap>.25))]=0
  for weight in [0,.25,.5,1,2,4]:
   pp=(base+weight*delta).argmax(1);v=vy[np.arange(len(pp)),pp];results.append(dict(mode=mode,weight=weight,hard=float(v[h].mean()),all=float(v.mean())))
"""
s=s[:start]+replacement+s[end:];s=s.replace("records.append(dict(epoch=epoch", "torch.save(net.state_dict(),p/'last.pt');np.save('sequence_memory_last_validation.npy',sc);\n if epoch%5==0:torch.save(net.state_dict(),p/f'epoch{epoch}.pt')\n records.append(dict(epoch=epoch")
p.write_text(s,encoding='utf-8')
