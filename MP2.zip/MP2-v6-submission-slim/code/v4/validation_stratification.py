import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import json
from pathlib import Path
import numpy as np
from common import load_inputs,read_jsonl,DATA,parse_answer
from rich_features import hard_mask
b,_=load_inputs('validation');g=read_jsonl(DATA/'gsm8k_validation.jsonl');y=np.array([[parse_answer(c['text'])is not None and parse_answer(c['text'])==parse_answer(q['answer'])for c in r['candidates']]for r,q in zip(b,g)]);h=hard_mask(b);s3=np.load('base_validation_scores.npy');s4=np.load('alignment_selected_validation_scores.npy');v3=y[np.arange(len(y)),s3.argmax(1)];v4=y[np.arange(len(y)),s4.argmax(1)];valid=np.array([[parse_answer(c['text'])is not None for c in r['candidates']]for r in b]);out={}
for k in [1,2,3]:
 m=h&(y.sum(1)==k);out[f'hard_correct_count_{k}']=dict(n=int(m.sum()),v3_accuracy=float(v3[m].mean()),v4_accuracy=float(v4[m].mean()))
for k in [2,3,4]:
 m=h&(valid.sum(1)==k)
 if m.any():out[f'hard_valid_count_{k}']=dict(n=int(m.sum()),v3_accuracy=float(v3[m].mean()),v4_accuracy=float(v4[m].mean()))
Path('validation_stratification.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
