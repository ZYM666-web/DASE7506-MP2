"""Conservative arithmetic verification using a restricted AST, never eval/exec."""
import ast,re,math
import numpy as np
from fractions import Fraction
from common import parse_answer

def clean(s):
 s=s.replace('−','-').replace('–','-').replace('×','*').replace('÷','/').replace('\\times','*').replace('\\cdot','*').replace('\\div','/').replace('\\,','').replace('\\!','')
 s=re.sub(r'\\(?:text|mathrm|operatorname)\{[^{}]*\}', '',s)
 for _ in range(5):s=re.sub(r'\\[dt]?frac\s*\{([^{}]+)\}\s*\{([^{}]+)\}',r'((\1)/(\2))',s)
 for _ in range(3):s=re.sub(r'\\boxed\s*\{([^{}]*)\}',r'(\1)',s)
 s=s.replace('\\left','').replace('\\right','').replace('\\$','').replace('$','').replace('**','').replace('\\(','').replace('\\)','').replace('\\[','').replace('\\]','').replace('\\\\',' ')
 s=re.sub(r'(?<=\d),(?=\d{3}(?:\D|$))','',s)
 s=s.replace('{','(').replace('}',')').replace('^','**')
 return s.strip()

def evaluate(s,repair=None):
 s=s.strip().rstrip('.,;:')
 if not s or len(s)>250 or re.search(r'[^\d.\s()+*/\-]',s):return None
 try:
  tree=ast.parse(s,mode='eval')
  def ev(n):
   if isinstance(n,ast.Expression):return ev(n.body)
   if isinstance(n,ast.Constant) and type(n.value) in [int,float]:v=float(n.value)
   elif isinstance(n,ast.UnaryOp) and isinstance(n.op,(ast.UAdd,ast.USub)):v=ev(n.operand)*(1 if isinstance(n.op,ast.UAdd) else -1)
   elif isinstance(n,ast.BinOp):
    l,r=ev(n.left),ev(n.right)
    if isinstance(n.op,ast.Add):v=l+r
    elif isinstance(n.op,ast.Sub):v=l-r
    elif isinstance(n.op,ast.Mult):v=l*r
    elif isinstance(n.op,ast.Div):v=l/r
    elif isinstance(n.op,ast.Pow) and abs(r)<=6 and abs(l)<1e6:v=l**r
    else:raise ValueError()
   else:raise ValueError()
   if not math.isfinite(v) or abs(v)>1e15:raise ValueError()
   if repair:
    for before,after in reversed(repair):
     if abs(v-before)<=1e-7*(1+abs(before)):return after
   return v
  return ev(tree)
 except (ValueError,TypeError,SyntaxError,ZeroDivisionError,OverflowError):return None

def eqs(text):
 # Math chunks first, then plain lines; suppress duplicate equations.
 chunks=re.findall(r'\$\$(.*?)\$\$|(?<!\$)\$(?!\$)(.*?)(?<!\$)\$(?!\$)',text,re.S)
 segments=[a or b for a,b in chunks]+text.splitlines();seen=set();out=[]
 for segment in segments:
  s=clean(segment)
  if '=' not in s:continue
  # Preserve chains but split lines/LaTeX row breaks.
  for line in s.splitlines():
   parts=line.split('=')
   for left,right in zip(parts,parts[1:]):
    left=left.strip();right=right.strip()
    # Bare units after a numeric RHS are harmless; keep mathematical variables out.
    right=re.split(r'\s+(?:dollars?|miles?|hours?|minutes?|days?|weeks?|years?|students?|apples?|items?|pairs?|snails?|feet|gallons?|paperclips?)\b',right,flags=re.I)[0].strip()
    left=left.lstrip('-• ').strip() if left.lstrip().startswith('•') else left
    a,b=evaluate(left),evaluate(right)
    if a is None or b is None:continue
    key=(left,right)
    if key in seen:continue
    seen.add(key);out.append((left,right,a,b))
 return out

def arithmetic_evidence(bank):
 out=[]
 for row in bank:
  ans=[parse_answer(c['text']) for c in row['candidates']];vals=[float(Fraction(a)) if a else None for a in ans];records=[]
  for i,c in enumerate(row['candidates']):
   equations=eqs(c['text']);good=bad=0;repairs=[];direct=[];err=[]
   for left,right,a,b in equations:
    tol=.001*(1+abs(b));ok=abs(a-b)<=tol;good+=ok;bad+=not ok
    if not ok:err.append(min(abs(a-b)/(1+abs(b)),10));direct.append((a,b))
    ca=evaluate(left,repairs)
    if ca is not None and abs(ca-b)>.001*(1+abs(b)) and abs(b)>1e-8:
     repairs.append((b,ca))
   proposed=None
   if vals[i] is not None and repairs:
    v=vals[i]
    for before,after in reversed(repairs):
     if abs(v-before)<1e-5*(1+abs(v)):proposed=after;break
   records.append((good,bad,proposed,direct,err,len(equations)))
  fs=[]
  for i,(good,bad,proposed,direct,err,n) in enumerate(records):
   v=vals[i];support=contradict=directsupport=0
   for j,(_,_,proposal,dd,_,_) in enumerate(records):
    if proposal is not None and v is not None and abs(proposal-v)<1e-4*(1+abs(v)) and vals[j] is not None and abs(vals[j]-v)>1e-4*(1+abs(v)):support+=1
    if proposal is not None and v is not None and vals[j] is not None and abs(vals[j]-v)<1e-4*(1+abs(v)) and abs(proposal-v)>1e-4*(1+abs(v)):contradict+=1
    for a,b in dd:
     if v is not None and abs(v-a)<1e-4*(1+abs(v)) and vals[j] is not None and abs(vals[j]-b)<1e-4*(1+abs(b)):directsupport+=1
   fs.append([good,bad,good/(1+good+bad),sum(err),max(err,default=0),support,contradict,directsupport,n])
  out.append(fs)
 return np.array(out,dtype=np.float32)
