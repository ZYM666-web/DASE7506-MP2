import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[k]='4'
import copy,json,hashlib
from pathlib import Path
import numpy as np
from common import load_inputs,parse_answer,check_data
from submission_v6 import predict
p=Path('runs/final');freeze=json.loads(Path('runs/frozen_v6.json').read_text())
for f,v in freeze['files'].items():assert hashlib.sha256((p/f).read_bytes()).hexdigest()==v['sha256'],f
for f,sha in freeze['sources'].items():assert hashlib.sha256(Path(f).read_bytes()).hexdigest()==sha,f
check_data();b,a=load_inputs('validation');saved=json.loads(Path('runs/v6-validation-predictions.json').read_text())['selected'];assert np.array_equal(saved,predict(b,a,p))
ids=np.linspace(0,len(b)-1,11,dtype=int);bb=[copy.deepcopy(b[j])for j in ids];aa={k:v[ids].copy()for k,v in a.items()};original=predict(bb,aa,p);rng=np.random.default_rng(4500);perms=[]
for j,row in enumerate(bb):
 row['id']='new-bank-item-'+str(j);perm=rng.permutation(4);perms.append(perm);row['candidates']=[row['candidates'][k]for k in perm]
 for i,c in enumerate(row['candidates']):c['index']=i
 for k in aa:aa[k][j]=aa[k][j,perm]
changed=predict(bb,aa,p);assert all(parse_answer(b[ids[j]]['candidates'][original[j]]['text'])==parse_answer(bb[j]['candidates'][changed[j]]['text'])for j in range(len(ids)))
out=dict(all_data_hashes_pass=True,frozen_hashes_pass=True,validation_matches_selection=True,new_ids_and_candidate_permutation_n=11,all_pass=True);Path('runs/v6-checks.json').write_text(json.dumps(out,indent=2));print(out)
